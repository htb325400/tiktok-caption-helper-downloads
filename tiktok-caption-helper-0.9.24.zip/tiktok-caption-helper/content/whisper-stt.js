// content/whisper-stt.js
// ============================================================
// Pipeline orchestrator — 串联 音频采集 → STT → 翻译 → 渲染。
// 依赖: main-world.js (API拦截)  state.js  api-interceptor.js  translate-google.js  panel-ui.js
// ============================================================
(function () {
  'use strict';

  let requestId = 0;
  let activeAbortController = null;

  // F4：content script 里 fetch 视频原声轨（speechUrl，us.tiktok.com），带页面 cookie 绕过反盗链。
  // 返回 base64 dataURL 交给 SW handleWhisperData。尺寸超 25MB（Groq free tier）直接放弃。
  async function normalizeSpeechBlob(blob, signal) {
    var maxBytes = 25 * 1024 * 1024;
    if (blob.size > 64 * 1024 * 1024 || typeof AudioContext !== 'function') {
      throw new Error('TOO_LARGE(' + (blob.size / 1024 / 1024).toFixed(1) + 'MB)');
    }
    function checkCancelled() {
      if (signal && signal.aborted) throw new Error('音频处理已取消');
    }
    checkCancelled();
    var context = new AudioContext({ sampleRate: 16000 });
    try {
      var buffer = await blob.arrayBuffer();
      checkCancelled();
      var decoded = await context.decodeAudioData(buffer);
      checkCancelled();
      if (decoded.sampleRate !== 16000 || !Number.isInteger(decoded.length) || decoded.length <= 0 ||
          !Number.isInteger(decoded.numberOfChannels) || decoded.numberOfChannels < 1) {
        throw new Error('原声音频解码格式无效');
      }
      var byteLength = 44 + decoded.length * 2;
      if (byteLength > maxBytes) throw new Error('TOO_LARGE(normalized WAV)');
      var bytes = new Uint8Array(byteLength);
      var view = new DataView(bytes.buffer);
      function writeAscii(offset, value) {
        for (var index = 0; index < value.length; index++) bytes[offset + index] = value.charCodeAt(index);
      }
      writeAscii(0, 'RIFF'); view.setUint32(4, byteLength - 8, true); writeAscii(8, 'WAVE');
      writeAscii(12, 'fmt '); view.setUint32(16, 16, true); view.setUint16(20, 1, true);
      view.setUint16(22, 1, true); view.setUint32(24, 16000, true); view.setUint32(28, 32000, true);
      view.setUint16(32, 2, true); view.setUint16(34, 16, true); writeAscii(36, 'data');
      view.setUint32(40, byteLength - 44, true);
      var channels = [];
      for (var channel = 0; channel < decoded.numberOfChannels; channel++) channels.push(decoded.getChannelData(channel));
      for (var frame = 0; frame < decoded.length; frame++) {
        var total = 0;
        for (var channel = 0; channel < channels.length; channel++) total += channels[channel][frame];
        var sample = Math.max(-1, Math.min(1, total / channels.length));
        view.setInt16(44 + frame * 2, sample < 0 ? sample * 32768 : sample * 32767, true);
      }
      checkCancelled();
      return new Blob([bytes], { type: 'audio/wav' });
    } finally {
      try { await context.close(); } catch (_) {}
    }
  }

  async function fetchSpeechAsDataUrl(url, signal, allowNormalization) {
    try {
      var fetchOptions = { credentials: 'include', redirect: 'follow' };
      if (signal) fetchOptions.signal = signal;
      var r = await fetch(url, fetchOptions);
      if (!r.ok) return { ok: false, error: 'HTTP ' + r.status };
      var blob = await r.blob();
      if (blob.size === 0) return { ok: false, error: 'EMPTY_BODY' };
      if (blob.size > 25 * 1024 * 1024) {
        if (!allowNormalization) return { ok: false, error: 'TOO_LARGE(' + (blob.size / 1024 / 1024).toFixed(1) + 'MB)' };
        blob = await normalizeSpeechBlob(blob, signal);
      }
      var dataUrl = await new Promise(function (resolve, reject) {
        var fr = new FileReader();
        fr.onload = function () { resolve(fr.result); };
        fr.onerror = function () { reject(new Error('FileReader failed')); };
        fr.readAsDataURL(blob);
      });
      return { ok: true, dataUrl: dataUrl, bytes: blob.size };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  // 语言码规范化：zh-CN/zh-TW → zh，en-US/en-GB → en，避免复检比较时假矛盾。
  // 按 -/_ 分段取首段再精确比较，避免 indexOf('zh')===0 把 zho/zhx 误归为 zh。
  function normalizeLangCode(lang) {
    if (!lang) return null;
    var s = String(lang).toLowerCase().split(/[-_]/)[0];
    if (s === 'zh') return 'zh';
    if (s === 'en') return 'en';
    return s;
  }

  function classifySttCandidate(result) {
    function classifyText(value) {
      var text = String(value || '').replace(/\s+/g, ' ').trim();
      if (!text) return 'empty';
      var normalized = text.replace(/[.!?,;:。！？、；：]+$/, '').trim();
      if (/^(?:(?:\[\s*(?:music|instrumental)\s*\]|(?:intro|outro|background|instrumental|theme|opening|closing)\s+music|music|instrumental)|[\s.\-~♪♫♬♩🎵🎶#*!()[\]{}|&%$@"'\/\\:;+=?¿¡…·•`^]+)$/i.test(normalized || text)) {
        return 'label_only';
      }
      return 'transcript';
    }

    var segmentParts = [];
    if (result && Array.isArray(result.segments)) {
      segmentParts = result.segments.map(function (segment) { return segment && segment.text; }).filter(Boolean);
    }
    var segmentText = segmentParts.join(' ').replace(/\s+/g, ' ').trim();
    if (segmentText && classifyText(segmentText) === 'transcript') return 'transcript';
    if (result && typeof result.text === 'string' && result.text.trim()) return classifyText(result.text);
    return segmentText ? classifyText(segmentText) : 'empty';
  }

  function selectSttCandidate(initial, recovered) {
    var initialKind = classifySttCandidate(initial);
    var recoveredKind = classifySttCandidate(recovered);
    if ((initialKind === 'empty' || initialKind === 'label_only') && recoveredKind === 'transcript') {
      return { result: recovered, selected: 'recovered', reason: 'initial_' + initialKind + '_recovered_transcript' };
    }
    return { result: initial, selected: 'initial', reason: 'initial_' + initialKind + '_preferred' };
  }

  function chooseLanguageRecheck(initial, rechecked) {
    var recheckedKind = classifySttCandidate(rechecked);
    if (recheckedKind !== 'transcript') {
      return {
        result: initial,
        selected: 'initial',
        reason: 'language_recheck_' + recheckedKind + '_ignored'
      };
    }
    return { result: rechecked, selected: 'recheck', reason: 'language_recheck_transcript' };
  }

  /**
   * @param {boolean} [isAuto] - true = auto-triggered (don't cancel on re-entry, silent errors)
   */
  async function startWhisper(isAuto, forceLang) {
    var st = window.__TikTokCaptionHelper?.state;
    if (st && st.isProcessing()) {
      if (isAuto) return;     // Auto: silently skip, don't interrupt manual
      stopWhisper();          // Manual: toggle off
      return;
    }
    if (st) st.startSTT();
    if (activeAbortController && typeof activeAbortController.abort === 'function') {
      activeAbortController.abort();
    }
    activeAbortController = typeof AbortController === 'function' ? new AbortController() : null;
    var abortSignal = activeAbortController ? activeAbortController.signal : null;
    requestId++;
    let myId = requestId;
      var pipelineStartedAt = Date.now();
      var sttRequestCount = 0;
      var candidateReadyAt = null;
    function logPipelineTiming(label, extra) {
      var payload = { elapsedMs: Date.now() - pipelineStartedAt };
      if (extra && typeof extra === 'object') {
        Object.keys(extra).forEach(function (key) { payload[key] = extra[key]; });
      }
      console.log('[Pipeline] timing ' + label + ':', payload);
    }
    if (!isAuto) updateButton();

    try {
      // ============================================================
      // Step 1: Try URL-based Whisper FIRST (CDN download, no recording)
      // ============================================================
      let stored = await chrome.storage.local.get(['groqKey', 'geminiSttKey', 'geminiModel', 'groqModel', 'sttLang', 'sttEngine']);
      let apiKey = stored.groqKey;
      let geminiKey = stored.sttEngine === 'groq' ? null : stored.geminiSttKey;
      let geminiModel = stored.geminiModel || 'gemini-3.6-flash';
      let model = stored.groqModel || 'whisper-large-v3-turbo';
      let sttLang = forceLang || stored.sttLang || 'auto';
      logPipelineTiming('识别配置读取完成', { engine: geminiKey ? 'Gemini' : 'Groq', language: sttLang });
      // Gemini 模式：配置了 geminiSttKey 就用 Gemini（中英混合更准），无时间轴。
      // 跳过 PATH S/A（视频源），只走 PATH B/C 拿 audioUrl（音乐/原声轨音频）。
      var geminiMode = !!geminiKey;
      console.log('[Pipeline] STT 引擎:', geminiMode ? 'Gemini' : 'Groq', '| 语言:', sttLang, forceLang ? '(forced)' : '(auto)');
      if (!apiKey && !geminiKey) {
        if (isAuto) {
          // Auto mode: no API key — hide status, leave subtitles as-is
          console.log('[Pipeline] Auto-Whisper skipped: no API key');
          let panel = window.__TikTokCaptionHelper?.panel;
          if (panel) panel.hideAutoWhisperStatus();
          return;
        }
        throw new Error('请先设置 API Key。\n\nGroq（whisper）或 Gemini（中英混合更准）二选一：\n点击扩展图标 → 粘贴 Key → 保存。');
      }

      let panel = window.__TikTokCaptionHelper?.panel;

      // ============================================================
      // Step 1: Try URL-based Whisper FIRST (no recording needed)
      // ============================================================
      async function callWhisper(msg) {
        if (!isBindingCurrent()) throw Object.assign(new Error('Stale STT binding'), { code: 'STT_STALE' });
        var sttStartedAt = Date.now();
        var sttRequestNo = ++sttRequestCount;
        // Gemini 模式：自动带上 engine + key，让 background 路由到 handleGeminiTranscribe。
        // 同时带上 groqKey，供 background 在 Gemini 失败时回退 Groq。
        if (geminiMode) {
          msg.engine = 'gemini';
          msg.geminiKey = geminiKey;
          msg.geminiModel = geminiModel;
          msg.groqKey = apiKey || null;
        }
        return new Promise(function (resolve, reject) {
          chrome.runtime.sendMessage(msg, function (r) {
            if (!isBindingCurrent()) reject(Object.assign(new Error('Stale STT binding'), { code: 'STT_STALE' }));
            else if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else {
              logPipelineTiming('STT request returned', {
                request: sttRequestNo,
                requestMs: Date.now() - sttStartedAt,
                hasText: !!(r && r.text),
                segments: r && Array.isArray(r.segments) ? r.segments.length : 0
              });
              resolve(r);
            }
          });
        });
      }

      async function callWhisperFromUrl(url, route) {
        var snapshot = await fetchSpeechAsDataUrl(url, abortSignal);
        if (!snapshot.ok) throw new Error(snapshot.error || '媒体下载失败');
        if (!isBindingCurrent()) throw Object.assign(new Error('Stale STT binding'), { code: 'STT_STALE' });
        var result = await callWhisper({
          action: 'startWhisper',
          audioData: snapshot.dataUrl,
          apiKey: apiKey,
          model: model,
          language: sttLang
        });
        return {
          result: result,
          dataUrl: snapshot.dataUrl,
          bytes: snapshot.bytes,
          audioSnapshot: makeAudioSnapshot(url, route)
        };
      }

      let resp = null;
      let usedURL = false;
      var sourceRoute = 'unknown';
      var mediaMatchStatus = 'unknown';
      var stability = 'candidate';
      var candidateWarning = '音频来源或媒体匹配尚未完全确认，结果仅作候选';
      var audioEvidence = '音频内容未独立验证';
      var recognizedModel = geminiMode ? geminiModel : model;
      var pathTrace = []; // 记录每个 PATH 的尝试结果，用于诊断
      // 语言复检（L2）：记住本次成功的音频源，复检重识别时复用。
      // PATH S 存 base64 dataUrl（内存里，无需二次下载）；PATH A/B/C 存 URL（重识别=二次下载）。
      var recheckAudioData = null;
      var recheckAudioUrl = null;
      var speechAudioSnapshotData = null;
      var speechAudioSnapshot = null;
      var cachedAudioRole = 'unknown';
      var musicRouteAbstained = false;
      var oversizedSpeechSource = false;
      var recoveryAttempted = false;
      var candidateSelection = null;
      var audioSnapshot = null;

      function makeAudioSnapshot(url, route) {
        var currentTime = video && Number.isFinite(video.currentTime) ? video.currentTime : null;
        return {
          videoId: recognitionVideoId || null,
          wrapperId: recognitionBinding.wrapperId || null,
          routeEpoch: recognitionBinding.routeEpoch,
          sessionEpoch: recognitionBinding.sessionEpoch,
          sourceRoute: route || 'unknown',
          sourceUrl: String(url || '').split(/[?#]/)[0],
          capturedAt: Date.now(),
          currentTime: currentTime,
          currentTimeAtCapture: currentTime,
          inputKind: 'audioData'
        };
      }

      function abstainMusicRoute(route) {
        musicRouteAbstained = true;
        sourceRoute = 'music_candidate';
        mediaMatchStatus = 'unverified';
        stability = 'candidate';
        candidateWarning = '当前只能确认到歌曲或背景音乐，暂未确认到人物口播';
        audioEvidence = '来自 music.play_url 音乐轨，未确认是人物原声';
        pathTrace.push(route + ': music role → abstain speech route');
        console.log('[Pipeline] STT music route abstained:', {
          route: route,
          reason: 'music_candidate_in_speech_mode'
        });
      }

      // 找到当前播放的视频 — FYP 多视频预加载下取最大可见面积的
      let video = findCurrentVideo();
      const routeApi = window.__TikTokCaptionHelper?.apiInterceptor;
      const initialRouteState = routeApi && routeApi.getCurrentRouteState
        ? routeApi.getCurrentRouteState()
        : null;
      const recognitionVideoId = (location.href.match(/\/video\/(\d+)/) || [])[1] ||
        (initialRouteState && initialRouteState.videoId) || getFypVideoId();
      const recognitionBinding = Object.freeze({
        videoId: recognitionVideoId || null,
        wrapperId: (initialRouteState && initialRouteState.wrapperId) || getVideoWrapperId(video),
        mediaKey: (initialRouteState && initialRouteState.mediaKey) ||
          (video ? (video.currentSrc || video.src || '') : ''),
        videoElement: video,
        sessionEpoch: myId,
        routeEpoch: initialRouteState && Number.isInteger(initialRouteState.epoch)
          ? initialRouteState.epoch : 0,
        mediaSrc: video ? (video.currentSrc || video.src || '') : ''
      });
      logPipelineTiming('当前媒体绑定完成', {
        videoId: recognitionVideoId || null,
        wrapperId: recognitionBinding.wrapperId || null,
        hasVideo: !!video,
        mediaType: recognitionBinding.mediaSrc ? (recognitionBinding.mediaSrc.indexOf('blob:') === 0 ? 'blob' : 'url') : 'none'
      });
      const hasVerifiedMediaBinding = !!video && (
        !!recognitionBinding.wrapperId ||
        /^https?:\/\//.test(video.currentSrc || video.src || '')
      );
      function isBindingCurrent() {
        if (myId !== requestId) return false;
        if (!/\/video\/\d+/.test(location.href) && routeApi && routeApi.getCurrentRouteState) {
          var currentRouteState = routeApi.getCurrentRouteState();
          if (!currentRouteState || currentRouteState.epoch !== recognitionBinding.routeEpoch) return false;
          if (recognitionBinding.videoId && currentRouteState.videoId &&
              String(currentRouteState.videoId) !== String(recognitionBinding.videoId)) return false;
        }
        if (findCurrentVideo() !== recognitionBinding.videoElement) return false;
        if (getVideoWrapperId(video) !== recognitionBinding.wrapperId) return false;
        if (video && (video.currentSrc || video.src || '') !== recognitionBinding.mediaSrc) {
          console.warn('[Pipeline] STT binding invalidated: media source changed');
          return false;
        }
        var pageVideoId = (location.href.match(/\/video\/(\d+)/) || [])[1];
        if (pageVideoId && String(pageVideoId) !== String(recognitionBinding.videoId)) return false;
        if (recognitionBinding.videoId && !/\/video\/\d+/.test(location.href)) {
          var currentVideoId = getFypVideoId();
          if (currentVideoId && String(currentVideoId) !== String(recognitionBinding.videoId)) return false;
        }
        return true;
      }
      console.log('[Pipeline] Selected video:', video ? (video.src || video.currentSrc || 'no src').slice(0,60) : 'none');
      if (!video) pathTrace.push('PATH_A: no <video> element found');

      // ============================================================
      // PATH S（新增，F4）: speechUrl = 视频原声轨（video-cdn/us.tiktok.com）
      // 这才是含人声的音频。旧的 PATH_A/B/C 最终都落到 music.play_url（音乐轨），
      // 音乐/伴奏重的视频会转写出歌曲而不是人声。这里在 content script 里
      // fetch(credentials:'include') 带页面 cookie 绕过反盗链，字节走 handleWhisperData。
      // 失败/超限 → 回退旧路径，不影响原声视频。
      // 抽成函数：PATH C 的 detail 预取会二次填 speechUrl，需重试一次（修 P1）。
      // ============================================================
      function getSpeechUrlForCurrentVideo() {
        const apiS = window.__TikTokCaptionHelper?.apiInterceptor;
        if (!apiS || !apiS.getSpeechUrl) return null;
        if (!recognitionVideoId) return null;
        return apiS.getSpeechUrl(recognitionVideoId) || null;
      }

      async function attemptPathS() {
        if (usedURL || (resp && classifySttCandidate(resp) === 'transcript') || !isBindingCurrent()) return;
        const speechUrl = getSpeechUrlForCurrentVideo();
        if (!speechUrl) { pathTrace.push('PATH_S: no speechUrl'); return; }

        if (panel) panel.showSpeechStatus('正在识别（原声）...');
        console.log('[Pipeline] Trying speech URL:', speechUrl.slice(0, 100) + '...');
        var speechFetch = await fetchSpeechAsDataUrl(speechUrl, abortSignal, true);
        if (!isBindingCurrent()) return;
        if (speechFetch.ok) {
          speechAudioSnapshotData = speechFetch.dataUrl;
          audioSnapshot = makeAudioSnapshot(speechUrl, 'speech_url');
          speechAudioSnapshot = audioSnapshot;
          try {
            resp = await callWhisper({ action: 'startWhisper', audioData: speechFetch.dataUrl, apiKey: apiKey, model: model, language: sttLang });
            if (!isBindingCurrent()) { resp = null; return; }
            if (resp && resp.error) throw new Error(resp.error);
            var speechCandidateKind = classifySttCandidate(resp);
            console.log('[Pipeline] STT candidate:', { selected: 'initial', reason: 'initial_' + speechCandidateKind + '_pending' });
            if (speechCandidateKind === 'transcript') {
              usedURL = true;
              sourceRoute = 'speech_url';
              mediaMatchStatus = 'wrapper_bound';
              stability = 'final';
              candidateWarning = '结果为 final，但不代表原文正确；不代表音频内容已确认';
              audioEvidence = { type: 'speech_url', binding: 'wrapper', note: 'speechUrl 已绑定当前视频；声学内容未独立验证，不代表音频内容已确认' };
              recheckAudioData = speechFetch.dataUrl; // 复检复用字节，避免二次下载/反盗链
              pathTrace.push('PATH_S(speechUrl): OK');
              console.log('[Pipeline] speechUrl success (' + (speechFetch.bytes / 1024).toFixed(0) + 'KB)');
            } else {
              pathTrace.push('PATH_S(speechUrl): candidate ' + speechCandidateKind);
              console.log('[Pipeline] speechUrl returned non-transcript candidate:', speechCandidateKind);
            }
          } catch (e) {
            pathTrace.push('PATH_S(speechUrl): ' + (e.message || 'unknown'));
            console.warn('[Pipeline] speechUrl Whisper failed:', e.message);
            resp = null;
          }
        } else {
          if (String(speechFetch.error || '').indexOf('TOO_LARGE(') === 0) {
            oversizedSpeechSource = true;
          }
          pathTrace.push('PATH_S(speechUrl): fetch failed - ' + speechFetch.error);
          console.warn('[Pipeline] speechUrl fetch failed:', speechFetch.error);
        }
      }

      // Provider 只决定如何识别，不改变已绑定当前视频的媒体来源。
      // 无法建立视频身份时保留旧路径兼容行为，避免把未知媒体误归属到当前视频。
      if (!geminiMode || hasVerifiedMediaBinding) {
        await attemptPathS();
      }

      async function retryGroqWithSpeechUrl() {
        if (!apiKey || recoveryAttempted || !isBindingCurrent()) return false;
        recoveryAttempted = true;
        const speechAudioUrl = speechAudioSnapshotData ? null : getSpeechUrlForCurrentVideo();
        if (!speechAudioSnapshotData && !speechAudioUrl) {
          console.warn('[Pipeline] Groq 原声重试跳过: 当前视频无 speechUrl', recognitionVideoId);
          return false;
        }
        try {
          console.log('[Pipeline] Gemini fallback: retrying Groq with speechUrl');
          if (panel) panel.showSpeechStatus('Gemini 不可用，正在重试视频原声...');
          const speechFetch = speechAudioSnapshotData
            ? { ok: true, dataUrl: speechAudioSnapshotData }
            : await fetchSpeechAsDataUrl(speechAudioUrl, abortSignal, true);
          if (!isBindingCurrent()) return false;
          if (!speechFetch.ok) throw new Error(speechFetch.error);
          const fallbackResp = await new Promise(function (resolve, reject) {
            chrome.runtime.sendMessage({
              action: 'startWhisper', audioData: speechFetch.dataUrl, apiKey: apiKey,
              model: model, language: sttLang
            }, function (r) {
              if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
              else resolve(r);
            });
          });
          if (!isBindingCurrent()) return false;
          if (fallbackResp && fallbackResp.error) throw new Error(fallbackResp.error);
          var initialKind = classifySttCandidate(resp);
          var recoveredKind = classifySttCandidate(fallbackResp);
          var selectedCandidate = selectSttCandidate(resp, fallbackResp);
          candidateSelection = selectedCandidate;
          console.log('[Pipeline] STT candidate:', {
            selected: selectedCandidate.selected,
            reason: selectedCandidate.reason,
            initial: initialKind,
            recovered: recoveredKind
          });
          if (fallbackResp && !fallbackResp.error && recoveredKind === 'transcript' && selectedCandidate.selected === 'recovered') {
            fallbackResp.geminiFallbackReason = resp && resp.geminiFallbackReason;
            resp = selectedCandidate.result;
            usedURL = true;
            sourceRoute = fallbackResp.sourceRoute || 'verified_media_no_caption';
            mediaMatchStatus = 'unverified';
            stability = 'final';
            candidateWarning = 'AI 识别候选，原文可能有误';
            audioEvidence = { type: 'speech_url', binding: 'wrapper', note: 'Gemini 失败后使用 speechUrl 重试；声学内容未独立验证' };
            recognizedModel = fallbackResp.model || model;
            recheckAudioData = speechFetch.dataUrl;
            recheckAudioUrl = null;
            audioSnapshot = speechAudioSnapshot || makeAudioSnapshot(speechAudioUrl, 'speech_url');
            pathTrace.push('GEMINI-FALLBACK(speechUrl): OK');
            console.log('[Pipeline] GEMINI-FALLBACK(speechUrl): OK');
            return true;
          }
        } catch (e) {
          console.warn('[Pipeline] Groq speechUrl fallback failed:', e.message);
        }
        return false;
      }

      // PATH A: <video> currentSrc — 浏览器正在播放，无需额外认证
      if ((!resp || classifySttCandidate(resp) !== 'transcript') && !usedURL && isBindingCurrent() && (!geminiMode || hasVerifiedMediaBinding)) {
      let videoSrc = video ? (video.currentSrc || video.src || '') : '';
      if (videoSrc && /^https?:\/\//.test(videoSrc)) {
        if (panel) panel.showSpeechStatus('正在识别（CDN）...');
        console.log('[Pipeline] Trying video.currentSrc:', videoSrc.slice(0, 100) + '...');
        try {
          var videoSnapshot = await callWhisperFromUrl(videoSrc, 'verified_media_no_caption');
          resp = videoSnapshot.result;
          audioSnapshot = videoSnapshot.audioSnapshot;
          if (!isBindingCurrent()) { resp = null; }
          if (resp && resp.error) throw new Error(resp.error);
          if (classifySttCandidate(resp) === 'transcript') usedURL = true;
          sourceRoute = 'verified_media_no_caption';
          mediaMatchStatus = hasVerifiedMediaBinding ? 'wrapper_bound' : 'unknown';
          stability = 'final';
          candidateWarning = hasVerifiedMediaBinding ? 'AI 识别候选，原文可能有误' : '媒体未完全绑定，结果仅作候选';
          audioEvidence = hasVerifiedMediaBinding ? '当前 video 元素已绑定；声学内容未独立验证' : '仅获得 video URL，媒体绑定未确认';
          recheckAudioData = videoSnapshot.dataUrl;
          recheckAudioUrl = null;
          pathTrace.push('PATH_A(video.src): OK');
          console.log('[Pipeline] video.src success');
        } catch (e) {
          pathTrace.push('PATH_A(video.src): ' + (e.message || 'unknown'));
          console.warn('[Pipeline] video.src failed:', e.message);
          resp = null;
        }
      } else if (videoSrc) {
        console.log('[Pipeline] video.src is blob/data URI, trying alternate sources.');
        var sources = video ? video.querySelectorAll('source') : [];
        var sourceFound = false;
        for (var si = 0; si < sources.length; si++) {
          var src = sources[si].src;
          if (src && /^https?:\/\//.test(src)) {
            console.log('[Pipeline] Found <source> URL:', src.slice(0, 100) + '...');
            sourceFound = true;
            try {
              var sourceSnapshot = await callWhisperFromUrl(src, 'verified_media_no_caption');
              resp = sourceSnapshot.result;
              audioSnapshot = sourceSnapshot.audioSnapshot;
              if (resp && resp.error) throw new Error(resp.error);
              if (classifySttCandidate(resp) === 'transcript') usedURL = true;
              sourceRoute = 'verified_media_no_caption';
              mediaMatchStatus = hasVerifiedMediaBinding ? 'wrapper_bound' : 'unknown';
              stability = 'final';
              candidateWarning = hasVerifiedMediaBinding ? 'AI 识别候选，原文可能有误' : '媒体未完全绑定，结果仅作候选';
              audioEvidence = hasVerifiedMediaBinding ? '当前 video 元素已绑定；声学内容未独立验证' : '仅获得 source URL，媒体绑定未确认';
              recheckAudioData = sourceSnapshot.dataUrl;
              recheckAudioUrl = null;
              pathTrace.push('PATH_A(<source>): OK');
              console.log('[Pipeline] <source> URL success');
              break;
            } catch (e) {
              pathTrace.push('PATH_A(<source>): ' + (e.message || 'unknown'));
              console.warn('[Pipeline] <source> URL failed:', e.message);
              resp = null;
            }
          }
        }
        if (!sourceFound) {
          pathTrace.push('PATH_A: blob src, no HTTP <source> tags');
        } else if (!usedURL) {
          pathTrace.push('PATH_A(<source>): all HTTP sources failed');
        }
      }
      } // end PATH A guard

      // PATH B: 详情页 — 按 videoId 从 urlCache 取
      if ((!resp || classifySttCandidate(resp) !== 'transcript') && !usedURL && isBindingCurrent()) {
        let api = window.__TikTokCaptionHelper?.apiInterceptor;
        let pageMatch = location.href.match(/\/video\/(\d+)/);
        if (api && pageMatch && api.getCachedUrl) {
          let cachedUrl = api.getCachedUrl(pageMatch[1]);
          cachedAudioRole = api.getCachedAudioRole ? api.getCachedAudioRole(pageMatch[1]) : 'unknown';
          if (cachedUrl && cachedAudioRole === 'music') {
            abstainMusicRoute('PATH_B(urlCache)');
          } else if (cachedUrl) {
            if (panel) panel.showSpeechStatus('正在识别（CDN）...');
            console.log('[Pipeline] Trying cached CDN URL:', cachedUrl.slice(0, 100) + '...');
            try {
              var cachedSnapshot = await callWhisperFromUrl(cachedUrl, cachedAudioRole === 'music' ? 'music_candidate' : 'cached_audio_url');
              resp = cachedSnapshot.result;
              audioSnapshot = cachedSnapshot.audioSnapshot;
              if (resp && resp.error) throw new Error(resp.error);
              if (classifySttCandidate(resp) === 'transcript') usedURL = true;
              sourceRoute = cachedAudioRole === 'music' ? 'music_candidate' : 'cached_audio_url';
              mediaMatchStatus = 'unverified';
              stability = 'candidate';
              candidateWarning = cachedAudioRole === 'music' ? '当前音频可能是歌曲或背景音乐，歌词识别和翻译可能不准确' : '缓存音频来源未确认是当前视频原声，结果仅作候选';
              audioEvidence = cachedAudioRole === 'music' ? '来自 music.play_url 音乐轨，未确认是人物原声' : '来自音频 URL 缓存，未完成当前视频媒体匹配';
              recheckAudioData = cachedSnapshot.dataUrl;
              recheckAudioUrl = null;
              pathTrace.push('PATH_B(urlCache): OK');
              console.log('[Pipeline] Cached CDN URL success');
            } catch (e) {
              pathTrace.push('PATH_B(urlCache): ' + (e.message || 'unknown'));
              console.warn('[Pipeline] Cached CDN URL failed:', e.message);
              resp = null;
            }
          }
        }
      }

      // PATH C: FYP — videoId精确匹配 → urlCache → 过期自动重试API
      if ((!resp || classifySttCandidate(resp) !== 'transcript') && !usedURL && isBindingCurrent()) {
        var isFyp = !/\/video\/\d+/.test(location.href);
        if (isFyp) {
          var api2 = window.__TikTokCaptionHelper?.apiInterceptor;
          var vid = getFypVideoId();
          console.log('[Pipeline] FYP videoId:', vid);

          if (!vid) {
            pathTrace.push('PATH_C: getFypVideoId() returned null');
          } else {
            // ── 层0: urlCache 未命中 → 轮询等待 feed API 填充（3s内）─
            // FYP feed API 通常在 200-3000ms 内返回并填充 urlCache。
            // 如果用户在上滑后立即点🎤，缓存可能还是空的。给 feed API
            // 一点时间响应，避免不必要的 HTTP fetch。
            if (api2 && api2.getCachedUrl && !api2.getCachedUrl(vid)) {
              if (panel) panel.showSpeechStatus('正在等待音频链接...');
              var cacheWaitMs = 0;
              var CACHE_POLL_INTERVAL = 500;
              var CACHE_WAIT_MAX = 3000;
              while (cacheWaitMs < CACHE_WAIT_MAX && !api2.getCachedUrl(vid) && myId === requestId) {
                await new Promise(function (r) { setTimeout(r, CACHE_POLL_INTERVAL); });
                cacheWaitMs += CACHE_POLL_INTERVAL;
              }
              if (api2.getCachedUrl(vid)) {
                pathTrace.push('PATH_C(wait-cache): hit after ' + cacheWaitMs + 'ms');
                console.log('[Pipeline] urlCache populated by feed API after ' + cacheWaitMs + 'ms');
              } else {
                pathTrace.push('PATH_C(wait-cache): still empty after ' + cacheWaitMs + 'ms');
              }
            }

            // ── 层1: 轮询后仍无缓存 → 预取详情 API 填充 urlCache ──
            if (api2 && api2.getCachedUrl && !api2.getCachedUrl(vid)) {
              if (panel) panel.showSpeechStatus('正在获取音频链接...');
              var apiResult = '';
              try {
                var prefetchedUrl = await fetchDetailPageAudio(vid);
                if (prefetchedUrl) {
                  pathTrace.push('PATH_C(prefetch): OK');
                  apiResult = 'prefetch-ok';
                  console.log('[Pipeline] Prefetch populated urlCache for video', vid);
                } else {
                  pathTrace.push('PATH_C(prefetch): no URL returned');
                  apiResult = 'prefetch-empty';
                }
              } catch (e0) {
                pathTrace.push('PATH_C(prefetch): ' + (e0.message || 'unknown'));
                apiResult = 'prefetch-fail: ' + (e0.message || '');
                console.warn('[Pipeline] Prefetch failed:', e0.message);
              }

              // 预取成功后 speechUrl 可能刚被填入 urlCache —— 重试 PATH S（修 P1）。
              // attemptPathS 内部有 guard（usedURL/resp/myId），已成功则直接返回。
              if (apiResult === 'prefetch-ok' || apiResult === 'prefetch-empty') {
                await attemptPathS();
              }
            }

            // ── 层2: urlCache 命中 → 试缓存的 URL ──
            var cachedUrl = api2 && api2.getCachedUrl ? api2.getCachedUrl(vid) : null;
            cachedAudioRole = api2 && api2.getCachedAudioRole ? api2.getCachedAudioRole(vid) : 'unknown';
            if (cachedUrl && !usedURL && (!resp || classifySttCandidate(resp) !== 'transcript') && isBindingCurrent()) {
              if (cachedAudioRole === 'music') {
                abstainMusicRoute('PATH_C(urlCache)');
              } else {
              if (panel) panel.showSpeechStatus('正在识别（缓存）...');
              console.log('[Pipeline] FYP cached URL:', cachedUrl.slice(0, 100) + '...');
              try {
                var fypSnapshot = await callWhisperFromUrl(cachedUrl, cachedAudioRole === 'music' ? 'music_candidate' : 'cached_audio_url');
                resp = fypSnapshot.result;
                audioSnapshot = fypSnapshot.audioSnapshot;
                if (resp && resp.error) throw new Error(resp.error);
                usedURL = classifySttCandidate(resp) === 'transcript';
                sourceRoute = cachedAudioRole === 'music' ? 'music_candidate' : 'cached_audio_url';
                mediaMatchStatus = 'unverified';
                stability = 'candidate';
                candidateWarning = cachedAudioRole === 'music' ? '当前音频可能是歌曲或背景音乐，歌词识别和翻译可能不准确' : '缓存音频来源未确认是当前视频原声，结果仅作候选';
                audioEvidence = cachedAudioRole === 'music' ? '来自 music.play_url 音乐轨，未确认是人物原声' : '来自 FYP 音频 URL 缓存，未完成当前视频媒体匹配';
                recheckAudioData = fypSnapshot.dataUrl;
                recheckAudioUrl = null;
                pathTrace.push('PATH_C(urlCache): OK');
                console.log('[Pipeline] FYP cached URL success');
              } catch (e) {
                pathTrace.push('PATH_C(urlCache): ' + (e.message || 'unknown'));
                console.warn('[Pipeline] FYP urlCache Whisper failed:', e.message);
                resp = null;
              }
              }
            } else {
              pathTrace.push('PATH_C(urlCache): miss for ' + vid + (apiResult ? ' after ' + apiResult : ''));
            }

            // ── 层3: 仅在层1未尝试或层1成功但 Whisper 失败时才重试 API ──
            // 如果层1 already timed out / failed, 重试同一个 API 没意义
            var prefetchFailed = /prefetch-fail/.test(apiResult || '');
            if ((!resp || classifySttCandidate(resp) !== 'transcript') && !usedURL && !musicRouteAbstained && myId === requestId && !prefetchFailed) {
              if (panel) panel.showSpeechStatus('正在识别（API）...');
              var freshUrl;
              try {
                freshUrl = await fetchDetailPageAudio(vid);
              } catch (e3) {
                pathTrace.push('PATH_C(API): ' + (e3.message || 'unknown'));
                console.warn('[Pipeline] API fetch failed:', e3.message);
              }
            if (freshUrl && isBindingCurrent()) {
                console.log('[Pipeline] Fresh API URL:', freshUrl.slice(0, 100) + '...');
                pathTrace.push('PATH_C(API): URL obtained');
                cachedAudioRole = api2 && api2.getCachedAudioRole ? api2.getCachedAudioRole(vid) : cachedAudioRole;
                if (cachedAudioRole === 'music') {
                  abstainMusicRoute('PATH_C(API-fresh)');
                } else try {
                  var freshSnapshot = await callWhisperFromUrl(freshUrl, cachedAudioRole === 'music' ? 'music_candidate' : 'cached_audio_url');
                  resp = freshSnapshot.result;
                  audioSnapshot = freshSnapshot.audioSnapshot;
                  if (!isBindingCurrent()) { resp = null; }
                  if (resp && resp.error) throw new Error(resp.error);
                  if (classifySttCandidate(resp) === 'transcript') usedURL = true;
                  cachedAudioRole = api2 && api2.getCachedAudioRole ? api2.getCachedAudioRole(vid) : 'unknown';
                  sourceRoute = cachedAudioRole === 'music' ? 'music_candidate' : 'cached_audio_url';
                  mediaMatchStatus = recognitionVideoId ? 'unverified' : 'unknown';
                  stability = 'candidate';
                  candidateWarning = cachedAudioRole === 'music' ? '当前音频可能是歌曲或背景音乐，歌词识别和翻译可能不准确' : '详情 API 音频来源未完成当前媒体声学匹配，结果仅作候选';
                  audioEvidence = cachedAudioRole === 'music' ? '来自详情 API 的 music.play_url 音乐轨，未确认是人物原声' : '来自详情 API 音频 URL，未完成声学内容验证';
                  recheckAudioData = freshSnapshot.dataUrl;
                  recheckAudioUrl = null;
                  pathTrace.push('PATH_C(API-fresh): OK');
                  console.log('[Pipeline] Fresh API URL Whisper success');
                } catch (e2) {
                  pathTrace.push('PATH_C(API-fresh): Whisper failed — ' + (e2.message || 'unknown'));
                  console.warn('[Pipeline] Whisper failed with fresh API URL:', e2.message);
                  resp = null;
                }
              } else if (!freshUrl) {
                pathTrace.push('PATH_C(API): no URL returned');
              }
            }
          }
        }
      }

      // ============================================================
      // URL 都失败了 → 给用户精确提示 + 可操作的解决方案
      // ============================================================
      if (!isBindingCurrent()) return;
      if (oversizedSpeechSource && !usedURL && (!resp || classifySttCandidate(resp) !== 'transcript')) {
        throw new Error('已获取当前视频原声，但文件超过当前识别传输上限（25 MiB），尚未完成语音识别。\n\n这不代表视频没有人物口播，也不会把音乐轨误当作人物对白。请先使用较短视频，或等待后续分片识别支持。');
      }
      if (resp && classifySttCandidate(resp) !== 'transcript') {
        await retryGroqWithSpeechUrl();
        if (!isBindingCurrent()) return;
      }
      if (musicRouteAbstained && (!resp || classifySttCandidate(resp) !== 'transcript')) {
        throw new Error('当前只能确认到歌曲或背景音乐，暂未确认到人物口播。\n\n口播模式不会把音乐轨当作人物对白翻译。\n如果视频确实有人说话，请稍后重试，或打开视频详情页后再次识别。');
      }
      if (resp && classifySttCandidate(resp) === 'label_only') {
        if (isAuto) {
          if (panel) panel.hideAutoWhisperStatus();
          return;
        }
        sourceRoute = sourceRoute === 'unknown' ? 'music_candidate' : sourceRoute;
        cachedAudioRole = cachedAudioRole === 'unknown' ? 'music' : cachedAudioRole;
        mediaMatchStatus = mediaMatchStatus === 'unknown' ? 'unverified' : mediaMatchStatus;
        stability = 'candidate';
        candidateWarning = '识别结果可能是歌曲或背景音乐标签；原文和翻译仅供参考，不代表视频没有人物对白';
        audioEvidence = audioEvidence || '识别服务仅返回音乐标签，未确认音频内容类型';
        console.warn('[Pipeline] STT label-only candidate retained for source/translation display');
      }
      var retainedLabelCandidate = resp && classifySttCandidate(resp) === 'label_only';
      if (!resp || (classifySttCandidate(resp) !== 'transcript' && !retainedLabelCandidate)) {
        if (isAuto) {
          if (panel) panel.hideAutoWhisperStatus();
          console.log('[Pipeline] Auto-Whisper failed. Trace: ' + pathTrace.join(' → '));
          return;
        }
        var errVid = getFypVideoId();
        var traceStr = pathTrace.join(' → ');
        var failReason = '';

        // Figure out what actually happened from pathTrace
        var hadApiUrl = /prefetch-ok|API.*URL obtained/.test(traceStr);
        var hadWhisperAttempt = /Whisper failed|Whisper:/.test(traceStr);
        var hadCacheMiss = /urlCache.*miss/.test(traceStr);
        var feedApiMaybeSlow = /wait-cache.*still empty/.test(traceStr);

        if (!usedURL) {
          if (isFyp) {
            if (hadApiUrl && hadWhisperAttempt) {
              // Got CDN URL but Whisper/Groq failed to process it
              failReason = '✅ 已获取音频链接，但识别失败。\n\n' +
                'Groq Whisper 无法处理该音频。\n' +
                '可能原因：CDN 链接已过期 或 音频格式不兼容。\n\n' +
                '解决方法：\n1) 重试一次（链接可能已刷新）\n' +
                '2) 如仍失败，复制链接在新标签页打开后重试\n\n' +
                '诊断: ' + traceStr + '\n视频ID: ' + (errVid || 'unknown');
            } else if (hadApiUrl) {
              // Got CDN URL but no Whisper attempt (canceled?)
              failReason = '✅ 已获取音频链接，但识别未完成。\n\n' +
                '可能原因：请求被取消 或 超时。\n\n' +
                '请重试一次。\n\n' +
                '诊断: ' + traceStr + '\n视频ID: ' + (errVid || 'unknown');
            } else if (feedApiMaybeSlow && !hadApiUrl) {
              // wait-cache timed out, but prefetch/API also failed —
              // feed API didn't return in 3s AND the explicit detail API also failed
              failReason = '⏳ 等待 3 秒后仍未获取到音频链接。\n\n' +
                'FYP feed API 可能较慢或该视频未返回音频数据。\n\n' +
                '诊断: ' + traceStr + '\n\n' +
                '解决方法（按推荐顺序）：\n' +
                '1) 稍等 2-3 秒后重试 — feed API 可能即将返回\n' +
                '2) 点击"分享"→"复制链接"→新标签页打开→点 🎤\n\n' +
                '视频ID: ' + (errVid || 'unknown');
            } else {
              // Could not get CDN URL at all
              failReason = '无法获取此视频的音频链接。\n\n' +
                '诊断: ' + traceStr + '\n\n' +
                '解决方法（按推荐顺序）：\n' +
                '1) 稍等 2-3 秒后重试 — FYP feed API 可能需要更长时间\n' +
                '2) 点击"分享"→"复制链接"→新标签页打开→点 🎤\n\n' +
                '视频ID: ' + (errVid || 'unknown');
            }
          } else {
            failReason = 'CDN 音频链接未获取到。\n\n请稍等 1-2 秒后重试（等待页面 API 响应完成）。\n如仍失败：刷新页面后立即点击 🎤 按钮。\n\n诊断: ' + traceStr;
          }
        } else if (resp) {
          failReason = '音频中未检测到语音内容。\n\n可能原因：\n1) 该视频没有对白（纯音乐/无声）\n2) 语音音量过低或被背景音盖过\n\n请切换到有语音的视频重试。';
        } else {
          failReason = 'CDN 音频链接已过期。\n\n请稍等 1-2 秒后重试。\n如仍失败：刷新页面后立即点击 🎤 按钮。';
        }
        console.log('[Pipeline] Failure trace: ' + traceStr);
        throw new Error(failReason);
      }

      if (!isBindingCurrent()) {
        if (isAuto && panel) panel.hideAutoWhisperStatus();
        return;
      }

      let segments = resp.segments || [];
      let language = resp.language || 'auto';
      var isGeminiResult = resp.source === 'gemini';
      if (resp.sourceRoute) sourceRoute = resp.sourceRoute;
      recognizedModel = resp.model || (isGeminiResult ? geminiModel : model);
      var initialCandidateKind = classifySttCandidate(resp);
      var resultContentClass = initialCandidateKind === 'label_only'
        ? 'label_only'
        : (cachedAudioRole === 'music'
          ? 'lyric'
          : (initialCandidateKind === 'transcript' && sourceRoute === 'speech_url' ? 'speech' : 'unknown'));
      var transcriptContract = null;
      console.log('[Pipeline] STT candidate:', {
        selected: candidateSelection ? candidateSelection.selected : 'initial',
        reason: candidateSelection ? candidateSelection.reason : 'initial_' + initialCandidateKind + '_preferred'
      });
      // 诊断：Gemini 模式下若结果是 Groq（回退了），在页面 console 打印失败原因
      if (geminiMode && !isGeminiResult && resp.geminiFallbackReason) {
        console.warn('[Pipeline] ⚠ Gemini 失败已回退 Groq，原因: ' + resp.geminiFallbackReason);
        geminiMode = false;
      }
      console.log('[Pipeline] STT 音频诊断:', {
        videoId: recognitionVideoId,
        videoDuration: video && video.duration,
        audioDuration: resp.duration,
        segmentCount: segments.length,
        firstStart: segments.length ? segments[0].start : null,
        lastEnd: segments.length ? segments[segments.length - 1].end : null,
        speechRetry: !!recheckAudioData
      });
      if (isGeminiResult) {
        // Gemini 无单一语言（中英混合），用文本主导语言供翻译层判断（否则 'auto' 会让翻译逻辑异常）
        var _dl = window.__TikTokCaptionHelper && window.__TikTokCaptionHelper.langDetect;
        var _dom = (_dl && _dl.detectDominantLang) ? _dl.detectDominantLang(segments.map(function (s) { return s.text; })) : null;
        language = _dom || 'en';
      }
      console.log('[Pipeline] STT done: ' + language + ', ' + segments.length + ' segments' + (isGeminiResult ? ' (Gemini)' : ''));

      // ============================================================
      // 语言复检（L2）：只在 auto 且返回 zh/en 且文本主导语言矛盾时，
      // 用同一音频源 + 主导语言重识别一次。绝不覆盖用户手动设的语言。
      // 这是「带验证的修复」——日志记录请求/返回语言 + 首次/重识别文本，
      // 用于证实或证伪「检测成中文导致英文识别错」这个假设。
      // ============================================================
      if (sttLang === 'auto') {
        var normLang = normalizeLangCode(language);
        if (normLang === 'zh' || normLang === 'en') {
          var langDetect = window.__TikTokCaptionHelper && window.__TikTokCaptionHelper.langDetect;
          if (langDetect && langDetect.detectDominantLang) {
            // segments 优先；segments 空但 resp.text 有值时回退到整体文本，否则复检永远不触发
            var textsForDetect = segments.map(function (s) { return s.text; }).filter(Boolean);
            if (textsForDetect.length === 0 && resp.text) textsForDetect = [resp.text];
            var dominantLang = langDetect.detectDominantLang(textsForDetect);
            if (dominantLang && dominantLang !== normLang) {
              console.log('[Pipeline] 语言复检: 请求=auto, 返回=' + normLang + ', 文本主导=' + dominantLang + ' → 重识别');
              var recheckResp = null;
              try {
                if (recheckAudioData) {
                  recheckResp = await callWhisper({ action: 'startWhisper', audioData: recheckAudioData, apiKey: apiKey, model: model, language: dominantLang });
                } else if (recheckAudioUrl) {
                  recheckResp = await callWhisper({ action: 'startWhisper', audioUrl: recheckAudioUrl, apiKey: apiKey, model: model, language: dominantLang });
                }
                // 竞态守卫：重识别 await 期间用户可能取消/重新识别，旧请求不得覆盖新结果
                if (myId !== requestId) {
                  console.log('[Pipeline] 重识别期间请求已变化，丢弃旧结果');
                  return;
                }
                if (recheckResp && !recheckResp.error && recheckResp.text) {
                  var recheckSelection = chooseLanguageRecheck(resp, recheckResp);
                  if (recheckSelection.selected === 'recheck') {
                    console.log('[Pipeline] 重识别成功 → ' + dominantLang);
                    resp = recheckSelection.result;
                    segments = resp.segments || [];
                    language = resp.language || language;
                    pathTrace.push('LANG-RECHECK: ' + normLang + ' → ' + dominantLang + ' OK');
                  } else {
                    console.warn('[Pipeline] 重识别结果不是有效转写，保留首次:', recheckSelection.reason);
                    pathTrace.push('LANG-RECHECK: ignored ' + recheckSelection.reason);
                  }
                } else {
                  console.warn('[Pipeline] 重识别无有效结果，保留首次');
                  pathTrace.push('LANG-RECHECK: no valid result, keep original');
                }
              } catch (e) {
                console.warn('[Pipeline] 重识别失败，保留首次:', e.message);
                pathTrace.push('LANG-RECHECK: failed, keep original');
              }
            }
          }
        }
      }

      // 裁剪超出视频时长的片段（CDN 音频可能包含完整歌曲，但 TikTok 只播放片段）
      // Gemini 结果无 start/end 时间戳，跳过裁剪（isGeminiResult）。
      if (!isBindingCurrent()) return;
      var currentVideo = recognitionBinding.videoElement;
      if (!isGeminiResult && currentVideo && currentVideo.duration && isFinite(currentVideo.duration)) {
        var maxDuration = currentVideo.duration;
        var clippedSegments = [];
        for (var si = 0; si < segments.length; si++) {
          if (segments[si].start < maxDuration) {
            var cs = Object.assign({}, segments[si]);
            if (cs.end > maxDuration) cs.end = maxDuration;
            clippedSegments.push(cs);
          }
        }
        if (clippedSegments.length < segments.length) {
          console.log('[Pipeline] ✂ Clipped ' + (segments.length - clippedSegments.length) +
            ' segments beyond video duration (' + maxDuration.toFixed(1) + 's). ' +
            'Kept ' + clippedSegments.length + '/' + segments.length);
        }
        if (!clippedSegments.length && segments.length && segments.every(function (segment) {
          return Number.isFinite(segment.start) && Number.isFinite(segment.end);
        })) {
          throw new Error('识别片段全部超出当前视频的时间范围，未展示或翻译这些文本。请重新识别当前视频。');
        }
        segments = clippedSegments;
      }

      if (window.TranscriptContract && window.TranscriptContract.normalizeTranscript) {
        transcriptContract = window.TranscriptContract.normalizeTranscript(Object.assign({}, resp, {
          language: language,
          segments: segments,
          text: segments.length ? segments.map(function (segment) { return segment.text || ''; }).filter(Boolean).join(' ') : (resp.text || '')
        }), {
          sessionId: String(recognitionBinding.sessionEpoch),
          videoId: recognitionVideoId || null,
          routeEpoch: recognitionBinding.routeEpoch,
          requestId: myId,
          sourceRoute: sourceRoute,
          contentClass: resultContentClass,
          contentTypeSource: resultContentClass === 'lyric' ? 'stt_label' : 'unknown',
          stability: 'final',
          revision: 0,
          sequence: null
        });
      }

      // Build segment list in the format renderBilingualResult expects
      var sttSegments = [];
      for (var si = 0; si < segments.length; si++) {
        var s = segments[si];
        if (!s.text) continue;
        sttSegments.push({
          // Gemini 无时间戳：time 为空字符串，渲染层省略时间栏
          time: isGeminiResult ? '' : (fmtDuration(s.start) + ' - ' + fmtDuration(s.end)),
          text: s.text
        });
        var segmentDiagnostics = {};
        ['temperature', 'avg_logprob', 'compression_ratio', 'no_speech_prob'].forEach(function (field) {
          if (typeof s[field] === 'number' && Number.isFinite(s[field])) {
            segmentDiagnostics[field] = s[field];
          }
        });
        if (Object.keys(segmentDiagnostics).length) {
          sttSegments[sttSegments.length - 1].diagnostics = segmentDiagnostics;
        }
      }
      if (!sttSegments.length) {
        sttSegments.push({ time: '0:00', text: resp.text || '' });
      }
      var mediaContract = window.MediaContract;
      if (mediaContract) {
        var contractOwnership = mediaMatchStatus === 'verified'
          ? 'exact_player'
          : (mediaMatchStatus === 'wrapper_bound'
            ? 'video_id_only'
            : (recognitionVideoId ? 'video_id_only' : 'unverified'));
        // Existing `verified` means DOM/player identity only. It does not prove
        // downloaded bytes are the exact current media, so keep it below media_bound.
        var contractEvidence = mediaMatchStatus === 'verified' || mediaMatchStatus === 'wrapper_bound'
          ? 'identity_bound'
          : 'unknown';
        var contractAudioRole = cachedAudioRole === 'music'
          ? 'music'
          : (sourceRoute === 'speech_url' ? 'speech' : 'unknown');
        var contractClass = resultContentClass;
        var contractWarning = contractClass === 'lyric'
          ? '可能为歌曲或背景音乐，识别与翻译可能不准确'
          : (contractClass === 'unknown' ? '音频内容类型未确认，原文仅作候选' : null);
        var contractSegments = segments.map(function (segment) {
          return {
            start: Number.isFinite(segment.start) ? segment.start : null,
            end: Number.isFinite(segment.end) ? segment.end : null,
            text: typeof segment.text === 'string' ? segment.text : '',
            role: contractClass === 'lyric' ? 'singing' : (contractClass === 'speech' ? 'dialogue' : 'unknown'),
            translate: contractClass !== 'label_only',
            warning: contractWarning
          };
        });
        try {
          var sidecarBinding = mediaContract.createMediaBinding({
            videoId: recognitionVideoId,
            wrapperId: recognitionBinding.wrapperId,
          sessionId: String(recognitionBinding.sessionEpoch),
          routeEpoch: recognitionBinding.routeEpoch,
          mediaSrc: recognitionBinding.mediaSrc,
            sourceRoute: sourceRoute,
            ownership: contractOwnership,
            audioRole: contractAudioRole,
            evidenceStatus: contractEvidence
          });
          var sidecarCandidate = mediaContract.createCandidate({
            binding: sidecarBinding,
            textState: 'final',
            contentClass: contractClass,
            segments: contractSegments,
            model: recognizedModel,
            language: language,
            timing: {
              requestStartedMs: null,
              firstPartialMs: null,
              firstStableMs: null,
              finalMs: Date.now() - pipelineStartedAt,
              firstTranslationMs: null
            }
          });
          var evidenceStore = window.__TikTokCaptionHelper && window.__TikTokCaptionHelper.mediaEvidence;
          if (evidenceStore && evidenceStore.record) {
            evidenceStore.record({
              sampleId: String(recognitionVideoId || 'unknown') + ':' + String(recognitionBinding.sessionEpoch),
          videoId: recognitionVideoId || null,
          routeEpoch: recognitionBinding.routeEpoch,
          requestId: myId,
            source: resp.source || (isGeminiResult ? 'gemini' : 'groq'),
              provider: resp.provider || (isGeminiResult ? 'gemini' : null),
              inputSource: resp.inputSource || null,
              candidate: sidecarCandidate
            });
          }
          console.log('[Pipeline] Media contract sidecar:', {
            binding: sidecarCandidate.binding,
            contentClass: sidecarCandidate.contentClass,
            segmentCount: sidecarCandidate.segments.length,
            dialogueEligible: mediaContract.isDialogueCandidate(sidecarCandidate),
            translationEligible: mediaContract.isTranslationEligible(sidecarCandidate)
          });
        } catch (contractError) {
          console.warn('[Pipeline] Media contract sidecar failed:', contractError.message);
        }
      }
      logPipelineTiming('原文候选处理完成', {
        sourceRoute: sourceRoute,
        model: recognizedModel,
        segments: sttSegments.length,
        candidate: classifySttCandidate(resp)
      });
      candidateReadyAt = Date.now();

      // Delegate to the proven bilingual renderer (same as subtitle path)
      if (panel) {
        if (isAuto) panel.hideAutoWhisperStatus();
        var stored2 = await chrome.storage.local.get(['targetLang']);
        // 渲染前竞态守卫：await storage 期间用户可能已取消/重新识别，旧结果不得覆盖新结果
        if (!isBindingCurrent()) {
          console.log('[Pipeline] 渲染前请求已变化，丢弃旧结果');
          return;
        }
        var targetLang = stored2.targetLang || 'zh';
        var state = window.__TikTokCaptionHelper?.state;
        if (state) { state.reset(recognitionVideoId); state.startSubtitleLoad(recognitionVideoId); }
        var myReqId = state ? state.getRenderReqId() : 0;
        try {
          await panel.renderBilingualResult({
            segments: sttSegments,
            actualLang: language,
            sourceLang: language,
            isSTT: true,
            isMediaBindingCurrent: isBindingCurrent,
            videoId: recognitionVideoId,
            sessionEpoch: recognitionBinding.sessionEpoch,
            routeEpoch: recognitionBinding.routeEpoch,
            wrapperId: recognitionBinding.wrapperId,
            mediaKey: recognitionBinding.mediaKey || recognitionBinding.mediaSrc || null,
            sourceRoute: sourceRoute,
            source: resp.source || (isGeminiResult ? 'gemini' : 'groq'),
            provider: resp.provider || (isGeminiResult ? 'gemini' : null),
            inputSource: resp.inputSource || null,
            mediaMatchStatus: mediaMatchStatus,
            stability: stability,
            candidateWarning: candidateWarning,
            contentClass: resultContentClass,
            transcriptContract: transcriptContract,
            audioEvidence: audioEvidence,
            audioSnapshot: audioSnapshot,
            model: recognizedModel,
            timing: {
              pipelineMs: Date.now() - pipelineStartedAt,
              candidateMs: candidateReadyAt ? candidateReadyAt - pipelineStartedAt : null,
              sttRequests: sttRequestCount
            }
          }, targetLang, myReqId, recognitionVideoId);
          logPipelineTiming('双语翻译与渲染完成', {
            sourceSegments: sttSegments.length,
            sourceRoute: sourceRoute,
            model: recognizedModel
          });
        } catch (e) {
          console.error('[Pipeline] Bilingual render failed:', e);
          if (panel) panel.showSpeechResult('❌ 识别失败\n\n' + (e.message || '翻译服务异常'));
        }
      }

    } catch (e) {
      console.error('[Pipeline] Error:', e.message);
      let panel = window.__TikTokCaptionHelper?.panel;
      let msg = e.message || '';

      if (isAuto) {
        // Auto mode: silent failure — hide status bar, leave Chinese subtitles
        if (panel) panel.hideAutoWhisperStatus();
        console.log('[Pipeline] Auto-Whisper failed silently:', msg);
      } else {
        // Manual mode: show user-friendly error in panel
        if (/chrome\.runtime|extension context|disconnected|receiving end/i.test(msg)) {
          if (panel) panel.showSpeechResult('⚠️ 与服务通信失败\n\n扩展 Service Worker 可能已休眠。\n请刷新页面后重试。');
        } else if (/API Key|401|unauthorized/i.test(msg)) {
          if (panel) panel.showSpeechResult('🔑 API Key 无效\n\n请点击扩展图标 → 重新设置 Groq API Key。');
        } else if (/quota|429|过于频繁/i.test(msg)) {
          if (panel) panel.showSpeechResult('⏳ 请求过于频繁\n\nGroq 免费额度有限，请稍后重试。');
        } else {
          if (panel) panel.showSpeechResult('❌ 识别失败\n\n' + msg);
        }
      }
    }

    if (!isAuto) updateButton();
  }

  // FYP页面: 从DOM和SSR数据提取当前播放视频的ID
  // FYP: 从所有可用的来源提取当前视频ID
  function getFypVideoId() {
    // 来源1: xgplayer wrapper ID — 最可靠，精确匹配当前播放视频
    // TikTok 的 xgplayer 会把 aweme_id 写入容器 id: "xgwrapper-0-7671237043959254292"
    var video = findCurrentVideo();
    if (video) {
      var p = video.parentElement;
      for (var i = 0; i < 6 && p; i++) {
        var m = p.id && p.id.match(/^xgwrapper-\d+-(\d+)$/);
        if (m) {
          console.log('[Pipeline] FYP videoId from xgplayer wrapper: ' + m[1]);
          return m[1];
        }
        p = p.parentElement;
      }
    }

    // 来源2: SSR initial data (仅首页第一个视频有效)
    try {
      var el = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
      if (el && el.textContent) {
        var json = JSON.parse(el.textContent);
        if (json.__DEFAULT_SCOPE__) json = json.__DEFAULT_SCOPE__;
        if (json.itemList && json.itemList[0] && json.itemList[0].id)
          return json.itemList[0].id;
      }
    } catch(e) {}

    // 来源3: api-interceptor 追踪的最后拦截 videoId
    var api = window.__TikTokCaptionHelper?.apiInterceptor;
    if (api && api.lastVideoId) return api.lastVideoId;

    // 来源4: 页面内 /video/ID 链接（TikTok SEO 链接，可能在隐藏元素中）
    var links = document.querySelectorAll('a[href*="/video/"]');
    var best = null, bestDist = Infinity, cy = window.innerHeight / 2;
    for (var i = 0; i < links.length; i++) {
      var r = links[i].getBoundingClientRect();
      var d = Math.abs(r.top + r.height/2 - cy);
      if (d < bestDist && d < window.innerHeight) {
        bestDist = d;
        var m2 = links[i].href.match(/\/video\/(\d+)/);
        if (m2) best = m2[1];
      }
    }
    return best;
  }

  function getVideoWrapperId(video) {
    var p = video && video.parentElement;
    for (var i = 0; i < 6 && p; i++) {
      if (p.id) return p.id;
      p = p.parentElement;
    }
    return null;
  }

  // 找到当前真正在播放的视频（FYP 页面上有多个预加载视频）
  function findCurrentVideo() {
    var videos = document.querySelectorAll('video');
    if (videos.length === 0) return null;
    if (videos.length === 1) return videos[0];

    // 多个视频 → 取离视口中心最近的（FYP 每屏一个）
    var centerX = window.innerWidth / 2;
    var centerY = window.innerHeight / 2;
    var best = videos[0];
    var bestDist = Infinity;

    for (var i = 0; i < videos.length; i++) {
      var v = videos[i];
      var rect = v.getBoundingClientRect();
      var vx = rect.left + rect.width / 2;
      var vy = rect.top + rect.height / 2;
      var dist = (vx - centerX) * (vx - centerX) + (vy - centerY) * (vy - centerY);
      // 不可见的视频排除（display:none, visible=false 等）
      if (rect.width === 0 || rect.height === 0) continue;
      if (dist < bestDist) {
        bestDist = dist;
        best = v;
      }
    }
    return best;
  }


  // FYP: urlCache MISS 时，通过详情页 SSR fetch 获取 CDN audio URL。
  //      dispatch tc-fetch-subtitles → main-world 抓取详情页 HTML
  //      → 提取 SSR JSON → processResponse 写入 urlCache
  //      → tc-fetch-detail-done 事件携带 audioUrl 返回
  function fetchDetailPageAudio(videoId) {
    // 埋点：记录 detail API 实际耗时，用于调参 ABORT_TIMEOUT（暂保持 12s）
    var fetchStartMs = Date.now();
    return new Promise(function (resolve, reject) {
      var timeout = setTimeout(function () {
        cleanup();
        reject(new Error('SSR fetch timeout (12s)'));
      }, 12000);

      function onDone(e) {
        if (e.detail && String(e.detail.videoId) === String(videoId)) {
          cleanup();
          var fetchElapsedMs = Date.now() - fetchStartMs;
          // 修 P1：main-world 的 success 判据已放宽到 audioUrl||speechUrl。
          // 这里只要 success 就 resolve（audioUrl 可能为 null，speech-only 时 PATH C 会跳过，
          // 但 speechUrl 已通过 processResponse→notifyAudio 写入 urlCache，PATH S 重试能取到）。
          if (e.detail.success) {
            console.log('[Pipeline] detail API 耗时 ' + fetchElapsedMs + 'ms（成功, videoId=' + videoId + ', ' + (e.detail.audioUrl ? 'audio' : 'speech') + '）');
            resolve(e.detail.audioUrl || null);
          } else {
            console.warn('[Pipeline] detail API 耗时 ' + fetchElapsedMs + 'ms（失败: ' + (e.detail.error || 'unknown') + '）');
            reject(new Error(e.detail.error || 'SSR fetch failed'));
          }
        }
      }

      function cleanup() {
        clearTimeout(timeout);
        window.removeEventListener('tc-fetch-detail-done', onDone);
      }

      window.addEventListener('tc-fetch-detail-done', onDone);
      window.dispatchEvent(new CustomEvent('tc-fetch-subtitles', {
        detail: { videoId: videoId }
      }));
    });
  }

  function stopWhisper() {
    if (activeAbortController && typeof activeAbortController.abort === 'function') {
      activeAbortController.abort();
    }
    activeAbortController = null;
    requestId++;
    var st = window.__TikTokCaptionHelper?.state;
    if (st) st.reset(null);
    updateButton();
    // Clear spinner from panel — user should see cancellation immediately
    var panel = window.__TikTokCaptionHelper?.panel;
    if (panel && panel.clearSpeechStatus) panel.clearSpeechStatus();
    console.log('[Pipeline] Cancelled');
  }

  function updateButton() {
    let host = document.getElementById('tc-caption-panel-host');
    if (!host || !host.shadowRoot) return;
    let btn = host.shadowRoot.querySelector('#tc-btn-speech');
    if (!btn) return;
    var processing = window.__TikTokCaptionHelper?.state?.isProcessing() || false;
    btn.textContent = processing ? '⏹ 取消' : '🎤 语音识别';
    btn.style.background = processing ? '#e8254a' : '';
  }

  function fmtDuration(sec) {
    let m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
  }

  // Public API
  window.__TikTokCaptionHelper = window.__TikTokCaptionHelper || {};
  window.__TikTokCaptionHelper.whisperSTT = {
    startWhisper: startWhisper,
    stopWhisper: stopWhisper,
    get isProcessing() { return window.__TikTokCaptionHelper?.state?.isProcessing() || false; },
  };

  console.log('[字幕助手] Pipeline loaded');
})();
