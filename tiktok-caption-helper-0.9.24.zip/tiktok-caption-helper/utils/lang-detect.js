// utils/lang-detect.js
// ============================================================
// 语言主导检测 — 用于 STT 语言复检（detected-language recheck）。
//
// 输入识别文本数组，统计拉丁字母 vs CJK 汉字比例，返回主导语言。
// 只在 zh/en 二选一内判定；遇到日语假名/韩文/无法判定 → null（不触发复检）。
//
// UMD-lite：node 可 require 单测；浏览器挂 window.__TikTokCaptionHelper.langDetect
// ============================================================

(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.__TikTokCaptionHelper = root.__TikTokCaptionHelper || {};
    root.__TikTokCaptionHelper.langDetect = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // 主导语言判定阈值：一方字符数是另一方 1.5 倍以上才判为主导。
  // 初始值，需真机样本校准。
  var RATIO = 1.5;

  // 用 Unicode 范围，避免「぀-ヿ」这种把 CJK 标点（、。〈〉「」等 U+3000-U+303F）误当假名。
  var LATIN_RE = /[A-Za-zＡ-Ｚａ-ｚ]/g; // ASCII + 全角拉丁（用 .match，需要 /g）
  var CJK_RE = /[一-鿿㐀-䶿豈-﫿]/g;                 // 基本 + 扩展A + 兼容汉字（用 .match，需要 /g）
  // 这两个用 .test()，不能带 /g —— 否则 lastIndex 跨调用残留，造成漏检。
  var KANA_RE = /[぀-ヿ]/;   // 平假名 U+3040-309F + 片假名 U+30A0-30FF（不含 CJK 标点）
  var HANGUL_RE = /[가-힯ᄀ-ᇿ㄰-㆏]/; // 韩文音节 + 谚文字母

  /**
   * 判断单个文本是否已经是目标语言（翻译层逐句跳过用）。
   * 中英混合视频里，en→zh 翻译时中文句应跳过（否则"走远点"被当英文翻成"跑点"）。
   * 仅支持 en/zh 目标；其他目标语言返回 false（照常翻译，安全默认）。
   * @param {string} text
   * @param {'en'|'zh'} targetBase
   * @returns {boolean} true = 已是目标语言，应跳过翻译
   */
  function isAlreadyTargetLang(text, targetBase) {
    if (targetBase !== 'en' && targetBase !== 'zh') return false;
    var segLang = detectDominantLang([text]);
    if (segLang === null) return false; // 混合/假名/韩文/空 → 照常翻译（安全默认）
    return segLang === targetBase;
  }

  /**
   * 判断文本数组的主导语言。
   * @param {string[]} texts
   * @returns {'en' | 'zh' | null}  null = 无法可靠判定（混合/含假名/含韩文/样本不足）
   */
  function detectDominantLang(texts) {
    if (!Array.isArray(texts) || texts.length === 0) return null;

    var en = 0, zh = 0;
    for (var i = 0; i < texts.length; i++) {
      var t = String(texts[i] == null ? '' : texts[i]);
      // 出现日语假名或韩文 → 超出 zh/en 判定范围，直接放弃，避免中日/中韩混淆
      if (KANA_RE.test(t) || HANGUL_RE.test(t)) return null;
      en += (t.match(LATIN_RE) || []).length;
      zh += (t.match(CJK_RE) || []).length;
    }

    if (en === 0 && zh === 0) return null; // 纯数字/符号/emoji，无法判定
    if (en > zh * RATIO) return 'en';
    if (zh > en * RATIO) return 'zh';
    return null; // 中英比例接近，混合，保持检测结果
  }

  return { detectDominantLang: detectDominantLang, isAlreadyTargetLang: isAlreadyTargetLang, RATIO: RATIO };
});
