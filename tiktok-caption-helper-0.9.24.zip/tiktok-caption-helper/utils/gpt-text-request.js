(function (root) {
  'use strict';

  function isTikTokSender(sender) {
    try {
      var url = new URL(sender && sender.tab && sender.tab.url || '');
      return url.protocol === 'https:' && (url.hostname === 'www.tiktok.com' || url.hostname.endsWith('.tiktok.com'));
    } catch (_) { return false; }
  }

  function endpointFor(value, allowInsecure) {
    var url;
    try { url = new URL(String(value || '')); } catch (_) { return null; }
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) return null;
    if (url.protocol === 'http:' && !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname) && !allowInsecure) return null;
    if (!url.pathname.endsWith('/chat/completions')) return null;
    return url.href;
  }

  function hasAudioPart(value) {
    if (!value || typeof value !== 'object') return false;
    if (Array.isArray(value)) return value.some(hasAudioPart);
    if (value.type === 'input_audio' || value.type === 'audio' || value.input_audio || value.audio_url) return true;
    return Object.keys(value).some(function (key) { return hasAudioPart(value[key]); });
  }

  async function request(message, sender) {
    if (!isTikTokSender(sender)) return { error: 'GPT 请求来源不是 TikTok 页面', errorType: 'config' };
    var stored = await new Promise(function (resolve) {
      chrome.storage.local.get(['aiTranslateKey', 'aiTranslateEndpoint', 'aiTranslateModel', 'aiTranslateAllowInsecure'], resolve);
    });
    var endpoint = endpointFor(stored.aiTranslateEndpoint, stored.aiTranslateAllowInsecure === true);
    if (!endpoint || !stored.aiTranslateKey) return { error: 'GPT 网关或 Key 未配置，或 HTTP 网关未确认；请点击保存完整配置', errorType: 'config' };
    var body = message && message.body;
    if (!body || typeof body !== 'object' || hasAudioPart(body) || !Array.isArray(body.messages) ||
        body.messages.some(function (entry) { return !entry || !['system', 'user'].includes(entry.role) || typeof entry.content !== 'string' || /data:(?:audio|video)\//i.test(entry.content); }) ||
        JSON.stringify(body).length > 200000) return { error: 'GPT 文本接口拒绝无效或音频输入', errorType: 'param' };
    var permitted = await new Promise(function (resolve) {
      chrome.permissions.contains({ origins: [new URL(endpoint).origin + '/*'] }, resolve);
    });
    if (!permitted) return { error: 'GPT 网关缺少主机权限；请重新保存完整配置并允许访问该地址', errorType: 'config' };
    var payload = Object.assign({}, body);
    if (stored.aiTranslateModel) payload.model = stored.aiTranslateModel;
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 45000);
    try {
      var response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + stored.aiTranslateKey },
        body: JSON.stringify(payload),
        redirect: 'error',
        signal: controller.signal,
        credentials: 'omit'
      });
      var json = null;
      try { json = await response.json(); } catch (_) {}
      return { ok: response.ok, status: response.status, json: json };
    } catch (error) {
      return controller.signal.aborted
        ? { error: 'GPT 网关请求超过 45 秒，已停止；请检查网关连通性或尝试较快模型', errorType: 'timeout' }
        : { error: 'GPT 网关连接失败；请检查网关是否可达、TLS 证书及是否发生重定向', errorType: 'network' };
    } finally { clearTimeout(timer); }
  }

  root.GptTextRequest = { request: request, endpointFor: endpointFor, hasAudioPart: hasAudioPart };
})(typeof self === 'object' ? self : globalThis);
