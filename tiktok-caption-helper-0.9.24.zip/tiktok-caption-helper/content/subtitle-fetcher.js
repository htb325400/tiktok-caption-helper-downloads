// content/subtitle-fetcher.js
// ============================================================
// Subtitle content fetcher + VTT/SRT parser.
// Pure data layer — no DOM, no UI. Extracted from panel-ui.js
// to keep the panel focused on rendering.
// ============================================================

(function () {
  'use strict';

  /**
   * Fetch and parse subtitle content from TikTok subtitle URLs.
   * TikTok subtitles are typically WebVTT (.vtt) or SRT format.
   * @param {Array<{url: string, lang: string}>} subtitleData
   * @param {string} targetLang - Preferred output language, used only to choose a source track.
   * @returns {Promise<{status: string, reason: string, attempts: Array, segments: Array, sourceLang: string|null, trackId: string|null, url: string|null, format: string|null}>}
   */
  async function fetchSubtitleContent(subtitleData, targetLang) {
    let empty = { status: 'missing', reason: 'no-tracks', attempts: [], segments: [], sourceLang: null, trackId: null, url: null, format: null };
    let tracks = selectSubtitleTracks(Array.isArray(subtitleData) ? subtitleData : [], targetLang);
    if (!tracks.length) return empty;
    let attempts = [];
    let labelResult = null;
    for (let i = 0; i < tracks.length; i++) {
      let track = tracks[i];
      try {
        let response = await fetchWithTimeout(track.url, 10000);
        if (!response.ok) {
          attempts.push({ status: 'error', reason: 'http-error', httpStatus: response.status, url: track.url });
          console.warn('[字幕助手] Subtitle fetch failed:', track.lang, response.status);
          continue;
        }
        let segments = parseVttOrSrt(response.text);
        if (!segments.length) {
          let body = String(response.text || '').trim();
          let isEmptyVtt = /^WEBVTT[^\r\n]*(?:\r?\n\s*)?$/i.test(body) && !body.includes('-->');
          attempts.push({ status: isEmptyVtt ? 'missing' : 'error', reason: isEmptyVtt ? 'empty-track' : 'parse-error', url: track.url });
          console.warn('[字幕助手] Subtitle parse returned no cues:', track.lang);
          continue;
        }
        if (!hasTranscriptCues(segments)) {
          attempts.push({ status: 'label_only', reason: 'no-transcript-cues', url: track.url });
          if (!labelResult) labelResult = {
            status: 'label_only', reason: 'no-transcript-cues', segments: segments,
            sourceLang: normalizeLang(track.lang), trackId: track.id || null,
            url: track.url, format: track.format || null, source: track.source || null
          };
          continue;
        }
        attempts.push({ status: 'ready', reason: 'cues', url: track.url });
        return {
          status: 'ready',
          reason: 'cues',
          attempts: attempts,
          segments: segments,
          sourceLang: normalizeLang(track.lang),
          trackId: track.id || null,
          url: track.url,
          format: track.format || null,
          source: track.source || null,
        };
      } catch (e) {
        attempts.push({ status: 'error', reason: 'fetch-error', message: e.message, url: track.url });
        console.warn('[字幕助手] Subtitle fetch error:', track.lang, e.message);
      }
    }
    let hasError = attempts.some(function (attempt) { return attempt.status === 'error'; });
    if (labelResult) return Object.assign({}, labelResult, { attempts: attempts });
    return {
      status: hasError ? 'error' : 'missing',
      reason: hasError ? 'track-errors' : 'empty-tracks',
      attempts: attempts,
      segments: [], sourceLang: null, trackId: null, url: null, format: null, source: null
    };
  }

  function hasTranscriptCues(segments) {
    return (segments || []).some(function (segment) {
      let text = String(segment.text || '').trim().replace(/[.!?,;:。！？、；：]+$/, '').trim().replace(/\s+/g, ' ');
      if (!text) return false;
      if (/^(?:music|\[\s*music\s*\]|(?:intro|outro|background|instrumental|theme|opening|closing)\s+music)$/i.test(text)) return false;
      return /[\p{L}\p{N}]/u.test(text);
    });
  }

  async function fetchWithTimeout(url, timeoutMs) {
    let controller = typeof AbortController === 'function' ? new AbortController() : null;
    let timer = controller ? setTimeout(function () { controller.abort(); }, timeoutMs) : null;
    let options = { credentials: 'include' };
    if (controller) options.signal = controller.signal;
    try {
      let response = await fetch(url, options);
      let text = response.ok ? await response.text() : '';
      return { ok: response.ok, status: response.status, text: text };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  function normalizeLang(lang) {
    let value = String(lang || '').trim().toLowerCase().replace(/_/g, '-');
    if (!value) return null;
    let base = value.split('-')[0];
    if (base === 'eng') return 'en';
    if (base === 'zho' || base === 'chi') return 'zh';
    if (base === 'jpn') return 'ja';
    if (base === 'kor') return 'ko';
    if (base === 'cmn' || base === 'yue' || base === 'zh-cn' || base === 'zh-sg' || base === 'zh-tw') return 'zh';
    return base;
  }

  function selectSubtitleTracks(tracks, targetLang) {
    let usable = tracks.filter(function (track) { return track && track.url; });
    if (!usable.length) return [];
    let target = normalizeLang(targetLang);
    return usable.slice().sort(function (left, right) {
      return trackPriority(right, target) - trackPriority(left, target);
    });
  }

  function trackPriority(track, target) {
    let source = String(track.source || '').toLowerCase();
    let lang = normalizeLang(track.lang);
    if (source === 'asr') return lang === target ? 400 : 300;
    if (lang === target) return 200;
    return 100;
  }

  /**
   * Parse WebVTT or SRT formatted subtitle text.
   *
   * WebVTT:
   *   WEBVTT
   *   00:00:01.000 --> 00:00:03.000
   *   Hello world
   *
   * SRT:
   *   1
   *   00:00:01,000 --> 00:00:03,000
   *   Hello world
   *
   * @param {string} text
   * @returns {Array<{time: string, text: string}>}
   */
  function parseVttOrSrt(text) {
    let segments = [];
    let lines = String(text || '').replace(/^\uFEFF/, '').replace(/\r/g, '').split('\n');

    // Skip WebVTT header
    let startIdx = 0;
    if (lines[0] && lines[0].trim().startsWith('WEBVTT')) {
      startIdx = 1;
    }

    let i = startIdx;
    while (i < lines.length) {
      let line = lines[i].trim();

      if (!line) {
        i++;
        continue;
      }
      if (/^(NOTE|STYLE|REGION)(?:\s|$)/.test(line)) {
        i++;
        while (i < lines.length && lines[i].trim() !== '') i++;
        continue;
      }

      // Skip SRT sequence numbers (pure digits)
      if (/^\d+$/.test(line)) {
        i++;
        continue;
      }

      // Match timestamp: 00:00:01.000 --> 00:00:03.000 (or with comma)
      let timeMatch = line.match(
        /((?:\d{2}:)?\d{2}:\d{2}[.,]\d{2,3}|\d{2}:\d{2}[.,]\d{2,3})\s*-->\s*((?:\d{2}:)?\d{2}:\d{2}[.,]\d{2,3}|\d{2}:\d{2}[.,]\d{2,3})/
      );

      if (timeMatch) {
        let startTime = timeMatch[1].replace(',', '.');

        // Collect text until blank line or next timestamp
        i++;
        let textLines = [];
        while (i < lines.length && lines[i].trim() !== '' &&
               !/((?:\d{2}:)?\d{2}:\d{2}[.,]\d{2,3}|\d{2}:\d{2}[.,]\d{2,3})\s*-->/.test(lines[i])) {
          let t = cleanCueText(lines[i].trim());
          if (t) textLines.push(t);
          i++;
        }

        if (textLines.length > 0) {
          let startMs = parseTimestamp(timeMatch[1]);
          let endMs = parseTimestamp(timeMatch[2]);
          segments.push({
            time: formatTime(startTime),
            startMs: startMs,
            endMs: endMs,
            text: textLines.join(' '),
          });
        }
      } else {
        i++;
      }
    }

    return segments;
  }

  function parseTimestamp(value) {
    let normalized = String(value).replace(',', '.').split(':');
    let seconds = parseFloat(normalized.pop());
    let minutes = parseInt(normalized.pop() || '0', 10);
    let hours = parseInt(normalized.pop() || '0', 10);
    return Math.round((hours * 3600 + minutes * 60 + seconds) * 1000);
  }

  function cleanCueText(text) {
    return String(text || '')
      .replace(/<[^>]*>/g, '')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Format VTT timestamp (HH:MM:SS.mmm) to display time (M:SS).
   */
  function formatTime(vttTime) {
    let parts = vttTime.split(':');
    let seconds = parseFloat(parts.pop());
    let minutes = parseInt(parts.pop() || '0', 10);
    let hours = parseInt(parts.pop() || '0', 10);
    if (hours > 0) {
      return hours + ':' + pad(minutes) + ':' + pad(Math.floor(seconds));
    }
    return minutes + ':' + pad(Math.floor(seconds));
  }

  function pad(n) {
    return n < 10 ? '0' + n : '' + n;
  }

  // ============================================================
  // Public API
  // ============================================================
  window.__TikTokCaptionHelper = window.__TikTokCaptionHelper || {};
  window.__TikTokCaptionHelper.subtitleFetcher = {
    fetchSubtitleContent: fetchSubtitleContent,
    parseVttOrSrt: parseVttOrSrt,
    hasTranscriptCues: hasTranscriptCues,
  };

  console.log('[字幕助手] Subtitle fetcher loaded');
})();
