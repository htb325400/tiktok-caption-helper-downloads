// content/index.js
// ============================================================
// TikTok 字幕助手 — Content Script Entry
//
// Boot sequence:
//   1. Wait for DOM / SPA navigation
//   2. Mount the UI panel
//   3. Subscribe API interceptor → panel
//
// main-world.js runs natively via manifest "world": "MAIN".
// No <script> injection or re-injection needed.
// ============================================================

(function () {
  'use strict';

  var lastPlayerBindingKey = null;

  // ============================================================
  // Bootstrap — called on initial load and after each SPA nav
  // ============================================================
  function bootstrap() {
    if (window.__TikTokCaptionHelper?._booted) return;
    window.__TikTokCaptionHelper = window.__TikTokCaptionHelper || {};
    window.__TikTokCaptionHelper._booted = true;

    if (!window.__TikTokCaptionHelper.mediaEvidence && window.MediaEvidence) {
      window.__TikTokCaptionHelper.mediaEvidence = window.MediaEvidence.createEvidenceStore({ maxSamples: 50 });
    }
    window.__TikTokCaptionHelper.mediaEvidenceApi = {
      snapshot: function () {
        return window.__TikTokCaptionHelper.mediaEvidence
          ? window.__TikTokCaptionHelper.mediaEvidence.snapshot()
          : [];
      },
      clear: function () {
        if (window.__TikTokCaptionHelper.mediaEvidence) {
          window.__TikTokCaptionHelper.mediaEvidence.clear();
        }
      }
    };

    console.log('[字幕助手] Bootstrapping...');

    // Step 1: Mount the panel
    let panel = window.__TikTokCaptionHelper?.panel;
    if (panel && !panel.isMounted) {
      panel.mount();
      console.log('[字幕助手] Panel mounted');
    }

    // Step 2: Subscribe to API interceptor for subtitle data
    let interceptor = window.__TikTokCaptionHelper?.apiInterceptor;
    if (interceptor && panel) {
      if (typeof window.__TikTokCaptionHelper.videoChangeUnsubscribe === 'function') {
        window.__TikTokCaptionHelper.videoChangeUnsubscribe();
      }
      if (typeof interceptor.onVideoChange === 'function') {
        window.__TikTokCaptionHelper.videoChangeUnsubscribe = interceptor.onVideoChange(function (packet) {
          var bindingKey = JSON.stringify([packet.videoId || null, packet.wrapperId || null,
            packet.mediaKey || null, packet.epoch]);
          if (bindingKey === lastPlayerBindingKey) return;
          lastPlayerBindingKey = bindingKey;
          var stt = window.__TikTokCaptionHelper?.whisperSTT;
          if (stt && stt.stopWhisper) stt.stopWhisper();
          if (panel.reset) panel.reset(packet.videoId || null);
        });
      }
      if (typeof window.__TikTokCaptionHelper.subtitleUnsubscribe === 'function') {
        window.__TikTokCaptionHelper.subtitleUnsubscribe();
      }
      window.__TikTokCaptionHelper.subtitleUnsubscribe = interceptor.onSubtitles(function (packet) {
        var subtitles = packet.subtitles;
        console.log('[字幕助手] Subtitle update:', subtitles ? subtitles.length + ' entries' : 'none');
        var videoId = packet.videoId;
        panel.renderSubtitles(subtitles, videoId, {
          wrapperId: packet.wrapperId || null,
          mediaKey: packet.mediaKey || null,
          routeEpoch: packet.routeEpoch !== undefined ? packet.routeEpoch : packet.epoch,
          subtitleStatus: packet.subtitleStatus,
          subtitleReason: packet.subtitleReason
        });
      });
      console.log('[字幕助手] Subscribed to API interceptor');
    }
  }

  // ============================================================
  // Initial boot
  // ============================================================
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
  } else {
    bootstrap();
  }

  // ============================================================
  // SPA navigation — re-bootstrap on URL change
  // main-world.js persists natively (no re-injection needed)
  // Debounced (100ms) to avoid firing during rapid DOM churn.
  // Data arrives via pub/sub whenever ready — no fixed wait.
  // ============================================================
  let lastUrl = location.href;
  let lastVideoId = (location.pathname.match(/\/video\/(\d+)/) || [])[1] || null;
  let lastAuthor = (location.pathname.match(/\/@([^\/]+)/) || [])[1] || null;
  let pendingBootstrap = null;

  new MutationObserver(function () {
    let currentUrl = location.href;
    if (currentUrl !== lastUrl) {
      var currentVideoId = (location.pathname.match(/\/video\/(\d+)/) || [])[1] || null;
      var currentAuthor = (location.pathname.match(/\/@([^\/]+)/) || [])[1] || null;
      var videoChanged = currentVideoId !== lastVideoId;
      var authorChanged = currentAuthor !== lastAuthor;
      lastUrl = currentUrl;

      // 忽略 URL 参数微调；但 videoId 或作者 handle 任一变化都算导航。
      // 修复 B-01：旧逻辑只看 videoId，/@a → /@b 时两边都是 null 会被跳过，
      // 导致新作者页不重新 bootstrap（未来批量 UI 会挂错作者）。
      if (!videoChanged && !authorChanged) {
        console.log('[字幕助手] URL changed but same route (video ' + currentVideoId + ' / author ' + currentAuthor + '), skipping reset');
        return;
      }
      lastVideoId = currentVideoId;
      lastAuthor = currentAuthor;

      console.log('[字幕助手] SPA navigation detected → ' +
        (currentUrl.includes('/video/') ? 'video page (new video)' : (currentAuthor ? 'author page (' + currentAuthor + ')' : 'other page')));

      window.__TikTokCaptionHelper._booted = false;

      if (videoChanged) {
        // Reset panel state（允许新视频的字幕/STT渲染）
        // Pass currentVideoId so state.js can do a full cache clear for the old video
        let panel = window.__TikTokCaptionHelper?.panel;
        if (panel && panel.reset) panel.reset(currentVideoId);

        // Reset rendered video tracking — new video needs fresh render
        let api = window.__TikTokCaptionHelper?.apiInterceptor;
        if (api && api.resetRendered) api.resetRendered();

        // Stop any in-flight recognition
        let stt = window.__TikTokCaptionHelper?.whisperSTT;
        if (stt && stt.stopWhisper) stt.stopWhisper();

        // Try cache first (URLs captured from feed API responses)
        let match = currentUrl.match(/\/video\/(\d+)/);
        if (match) {
          let api = window.__TikTokCaptionHelper?.apiInterceptor;
          if (api && api.lookupCachedUrl) api.lookupCachedUrl(match[1]);
        }

        // Trigger page re-fetch for fresh CDN URLs (SSR stale after SPA)
        window.dispatchEvent(new CustomEvent('tc-refresh-data'));
      }

      // 无论 video 还是 author 变化，都重新 bootstrap（未来批量 UI 按作者挂载）
      // Debounce: clear previous pending bootstrap, schedule new one
      clearTimeout(pendingBootstrap);
      pendingBootstrap = setTimeout(bootstrap, 100);
    }
  }).observe(document, { subtree: true, childList: true });

  console.log('[字幕助手] Content script entry loaded');
})();
