// content/panel-ui.js
// ============================================================
// TikTok 字幕助手 — Sidebar Panel (Shadow DOM)
//
// Responsibilities: Shadow DOM creation, UI events, result display.
// CSS is inlined (CSS_TEXT constant) to eliminate FOUC.
// content/panel.css is kept for syntax-highlighting reference.
// Subtitle fetching/parsing delegated to subtitle-fetcher.js.
// ============================================================

(function () {
  'use strict';

  // Target translation language — change here or via chrome.storage
  const LANG_MAP = { zh: '中文', ja: '日本語', en: 'English', ko: '한국어', fr: 'Français', de: 'Deutsch', es: 'Español', pt: 'Português', th: 'ไทย', vi: 'Tiếng Việt', ar: 'العربية', ru: 'Русский', id: 'Bahasa', tr: 'Türkçe', it: 'Italiano', ms: 'Melayu' };

  // STT 语言纠正：识别后若语言误判，可在语言栏一键切换重新识别
  const STT_LANGS = [
    { code: 'fr', name: '🇫🇷 Français' },
    { code: 'en', name: '🇺🇸 English' },
    { code: 'zh', name: '🇨🇳 中文' },
    { code: 'ko', name: '🇰🇷 한국어' },
    { code: 'ja', name: '🇯🇵 日本語' },
    { code: 'es', name: '🇪🇸 Español' },
    { code: 'de', name: '🇩🇪 Deutsch' },
    { code: 'pt', name: '🇵🇹 Português' },
    { code: 'it', name: '🇮🇹 Italiano' },
    { code: 'ru', name: '🇷🇺 Русский' },
  ];

  // ============================================================
  // Styles — inlined to prevent FOUC (flash of unstyled content)
  // content/panel.css is kept as syntax-highlighting reference.
  // ============================================================
  const CSS_TEXT = ':host{--tc-bg:#1a1a2e;--tc-surface:#16213e;--tc-text:#e0e0e0;--tc-text-secondary:#a0a0b0;--tc-accent:#fe2c55;--tc-accent-hover:#e8254a;--tc-border:#2a2a3e;--tc-radius:8px;--tc-font:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;all:initial}.tc-panel{position:fixed;top:80px;right:16px;width:380px;max-height:calc(100vh - 120px);background:var(--tc-bg);border:1px solid var(--tc-border);border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.4);font-family:var(--tc-font);color:var(--tc-text);z-index:99999;display:flex;flex-direction:column;overflow:hidden;transition:transform 0.3s ease,opacity 0.3s ease}.tc-panel.tc-collapsed .tc-content,.tc-panel.tc-collapsed .tc-resize-handle,.tc-panel.tc-collapsed .tc-action-bar{display:none}.tc-panel.tc-collapsed{max-height:none;border-radius:8px}.tc-panel.tc-closed{position:fixed!important;bottom:24px!important;right:24px!important;left:auto!important;top:auto!important;width:auto!important;min-width:unset!important;max-height:none!important;padding:10px 18px!important;border-radius:22px!important;background:var(--tc-accent)!important;box-shadow:0 4px 20px rgba(254,44,85,0.6)!important;cursor:pointer!important;transition:all 0.3s ease!important}.tc-panel.tc-closed .tc-content,.tc-panel.tc-closed .tc-resize-handle,.tc-panel.tc-closed .tc-action-bar,.tc-panel.tc-closed .tc-header-actions,.tc-panel.tc-closed .tc-header span{display:none!important}.tc-panel.tc-closed .tc-header{border-bottom:none!important;padding:0!important}.tc-panel.tc-closed .tc-header h3{color:#fff!important;font-size:14px!important}.tc-panel.tc-closed:hover{transform:scale(1.05)!important}.tc-header{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid var(--tc-border);flex-shrink:0;cursor:grab;user-select:none}.tc-header h3{margin:0;font-size:16px;font-weight:600}.tc-header-actions{display:flex;gap:8px}.tc-btn{padding:6px 12px;border:1px solid var(--tc-border);border-radius:var(--tc-radius);background:var(--tc-surface);color:var(--tc-text);font-size:12px;cursor:pointer;white-space:nowrap}.tc-btn:hover{background:#2a2a4e}.tc-btn.tc-primary{background:var(--tc-accent);border-color:var(--tc-accent);color:#fff}.tc-btn.tc-primary:hover{background:var(--tc-accent-hover)}.tc-btn.tc-btn-full{width:100%;padding:10px 16px;font-size:14px;font-weight:600;border-radius:8px}.tc-action-bar{padding:8px 16px;border-bottom:1px solid var(--tc-border);flex-shrink:0}.tc-action-row{display:flex;gap:8px;margin-top:6px}.tc-content{flex:1;overflow-y:auto;padding:16px;font-size:14px;line-height:1.6}.tc-subtitle-segment{margin-bottom:8px;padding:8px 12px;background:var(--tc-surface);border-radius:6px}.tc-subtitle-time{font-size:11px;color:var(--tc-accent);margin-bottom:2px}.tc-subtitle-text{font-size:15px}.tc-subtitle-translation{font-size:13px;color:var(--tc-text-secondary);margin-top:4px;padding-top:4px;border-top:1px solid var(--tc-border)}.tc-empty{text-align:center;color:var(--tc-text-secondary);padding:40px 16px}.tc-empty p{margin:8px 0}.tc-loading{display:flex;align-items:center;justify-content:center;gap:8px;padding:40px 16px;color:var(--tc-text-secondary)}.tc-spinner{width:20px;height:20px;border:2px solid var(--tc-border);border-top-color:var(--tc-accent);border-radius:50%;animation:tc-spin 0.8s linear infinite}@keyframes tc-spin{to{transform:rotate(360deg)}}.tc-resize-handle{position:absolute;bottom:0;right:0;width:18px;height:18px;cursor:nwse-resize;background:linear-gradient(135deg,transparent 50%,var(--tc-border) 50%);border-radius:0 0 11px 0;z-index:10}.tc-dragging{user-select:none!important}';

  // ============================================================
  // State — delegated to content/state.js (single source of truth)
  // panel-ui keeps local references for convenience in hot paths
  var state = null; // set on mount → window.__TikTokCaptionHelper.state
  var subtitleSegments = [];
  var currentTranslationSource = null;
  var retranslationTimer = null;
  var translationSettingsRevision = 0;
  var panelRoot = null;

  // DOM lock — MutationObserver that detects external overwrites
  // (SSR refresh) and restores the bilingual render instantly.
  var contentObserver = null;
  var lockedHTML = '';

  // No-subtitle video state — when a video has no built-in subtitles,
  // we show a guide that updates once pre-buffer has audio data.
  var noSubtitlesVideo = false;
  var subtitleTask = null;
  var translationAttempt = null;
  var automaticFallbackKey = null;

  function currentSourceBinding() {
    var api = window.__TikTokCaptionHelper?.apiInterceptor;
    var route = api && api.getCurrentRouteState ? api.getCurrentRouteState() : {};
    return {
      videoId: (location.pathname.match(/\/video\/(\d+)/) || [])[1] || route.videoId || null,
      routeEpoch: route.epoch == null ? null : route.epoch,
      wrapperId: route.wrapperId || null,
      mediaKey: route.mediaKey || null
    };
  }

  function sourceBindingKey(binding) {
    return JSON.stringify(['videoId', 'routeEpoch', 'wrapperId', 'mediaKey'].map(function (key) {
      return binding && binding[key] != null ? String(binding[key]) : '';
    }));
  }

  async function requestVideoTranslation(options) {
    options = options || {};
    var whisper = window.__TikTokCaptionHelper?.whisperSTT;
    if (options.force || (state && state.getState() === 'loading_stt')) {
      if (!whisper) return { status: 'error', reason: 'stt-unavailable' };
      if (translationAttempt && translationAttempt.wake) translationAttempt.wake();
      translationAttempt = null;
      if (options.force) {
        subtitleTask = null;
        if (state && state.getState() === 'loading_subs') state.reset(currentSourceBinding().videoId);
      }
      return whisper.startWhisper(!!options.isAuto, options.forceLang);
    }
    var binding = currentSourceBinding();
    var key = sourceBindingKey(binding);
    if (!binding.videoId) return { status: 'error', reason: 'unknown-video' };
    if (translationAttempt && translationAttempt.key === key) return translationAttempt.promise;
    var attempt = { key: key };
    translationAttempt = attempt;
    attempt.promise = (async function () {
      if (!subtitleTask || subtitleTask.key !== key) {
        var api = window.__TikTokCaptionHelper?.apiInterceptor;
        var packet = api && api.getCurrentSubtitlePacket ? api.getCurrentSubtitlePacket() : null;
        if (packet) {
          renderSubtitles(packet.subtitles, packet.videoId, binding, {
            status: packet.subtitleStatus,
            reason: packet.subtitleReason
          });
        } else {
          var startedReqId = state && state.getRenderReqId();
          var content = getContentEl();
          if (content) content.innerHTML = '<div class="tc-loading"><span class="tc-spinner"></span>正在检查平台字幕...</div>';
          await new Promise(function (resolve) {
            var timer = setTimeout(function () { attempt.wake = null; resolve(); }, 1500);
            attempt.wake = function () { clearTimeout(timer); attempt.wake = null; resolve(); };
            var isDetail = /\/video\/\d+/.test(location.pathname);
            window.dispatchEvent(new CustomEvent(isDetail ? 'tc-fetch-subtitles' : 'tc-request-fyp-subtitles', { detail: { videoId: binding.videoId } }));
          });
          if (sourceBindingKey(currentSourceBinding()) !== key || translationAttempt !== attempt) return { status: 'stale' };
          if ((!subtitleTask || subtitleTask.key !== key) && state && state.getRenderReqId() !== startedReqId) return { status: 'stale' };
        }
      }
      var task = subtitleTask && subtitleTask.key === key ? subtitleTask : null;
      var outcome = task ? await task.promise : { status: 'error', reason: 'discovery-timeout' };
      if (translationAttempt !== attempt || sourceBindingKey(currentSourceBinding()) !== key || (task && subtitleTask !== task)) return { status: 'stale' };
      console.log('[Pipeline] subtitle-first decision:', { videoId: binding.videoId, status: outcome.status, reason: outcome.reason });
      if (outcome.status === 'ready' || outcome.status === 'stale' || outcome.status === 'blocked') return outcome;
      if (options.isAuto && outcome.status !== 'missing') return outcome;
      if (options.isAuto && automaticFallbackKey === key) return { status: 'blocked', reason: 'automatic-attempt-used' };
      if (!whisper) return { status: 'error', reason: 'stt-unavailable' };
      if (options.isAuto) automaticFallbackKey = key;
      await whisper.startWhisper(!!options.isAuto);
      return { status: 'asr', subtitleStatus: outcome.status };
    })();
    try { return await attempt.promise; }
    finally { if (translationAttempt === attempt) translationAttempt = null; }
  }

  // ============================================================
  // Mount — create Shadow DOM and inject panel into page
  // ============================================================
  function mount() {
    unmount();

    state = window.__TikTokCaptionHelper?.state || null;

    let host = document.createElement('div');
    host.id = 'tc-caption-panel-host';
    document.body.appendChild(host);

    panelRoot = host.attachShadow({ mode: 'open' });

    // Inject styles (inlined — no FOUC)
    const style = document.createElement('style');
    style.textContent = CSS_TEXT;
    panelRoot.appendChild(style);

    // Build panel structure
    let panel = document.createElement('div');
    // 默认折叠为 header 条，减少对视频页的遮挡；用户点 🔍− 或双击 header 展开
    panel.className = 'tc-panel tc-collapsed';
    panel.innerHTML =
      '<div class="tc-header">' +
      '  <h3>📝 字幕助手 <span style="font-size:11px;color:var(--tc-text-secondary);font-weight:400;" id="tc-translate-target">翻译→中文</span></h3>' +
      '  <div class="tc-header-actions">' +
      '    <button class="tc-btn" id="tc-btn-minimize" title="折叠面板">🔍−</button>' +
      '    <button class="tc-btn" id="tc-btn-close" title="关闭面板">✕</button>' +
      '  </div>' +
      '</div>' +
      '<div class="tc-action-bar">' +
      '  <button class="tc-btn tc-primary tc-btn-full" id="tc-btn-speech">🎤 识别</button>' +
      '  <div class="tc-action-row">' +
      '    <button class="tc-btn" id="tc-btn-translate">翻译</button>' +
      '    <button class="tc-btn" id="tc-btn-copy">📋 复制</button>' +
      '    <button class="tc-btn" id="tc-btn-download">⬇ 下载</button>' +
      '  </div>' +
      '</div>' +
      '<div class="tc-content" id="tc-content">' +
      '  <div class="tc-empty"></div>' +
      '</div>' +
      '<div class="tc-resize-handle"></div>';
    panelRoot.appendChild(panel);

    bindEvents(panel);

    // Load target translation language
    chrome.storage.local.get(['targetLang'], function (r) {
      let lang = r.targetLang || 'zh';
      let label = panelRoot.querySelector('#tc-translate-target');
      if (label) label.textContent = '翻译→' + (LANG_MAP[lang] || lang);
    });

    console.log('[字幕助手] Panel mounted');
  }

  function unmount() {
    clearTimeout(retranslationTimer);
    currentTranslationSource = null;
    subtitleTask = null;
    automaticFallbackKey = null;
    if (translationAttempt && translationAttempt.wake) translationAttempt.wake();
    translationAttempt = null;
    unlockContentDOM();
    let host = document.getElementById('tc-caption-panel-host');
    if (host) host.remove();
    panelRoot = null;
    subtitleSegments = [];
    if (state) state.reset(null);
  }

  // ============================================================
  // Event handlers
  // ============================================================
  function bindEvents(panel) {
    // ✕ → close to floating pill
    panel.querySelector('#tc-btn-close').addEventListener('click', function () {
      panel.classList.remove('tc-collapsed');
      panel.classList.add('tc-closed');
    });

    // Click pill → restore panel
    panel.addEventListener('click', function (e) {
      if (panel.classList.contains('tc-closed') && !e.target.closest('button')) {
        panel.classList.remove('tc-closed');
      }
    });

    // 🔍− → collapse to header
    panel.querySelector('#tc-btn-minimize').addEventListener('click', function () {
      panel.classList.remove('tc-closed');
      if (panel.classList.contains('tc-collapsed')) {
        panel.classList.remove('tc-collapsed');
      } else {
        panel.classList.add('tc-collapsed');
      }
    });

    // Double-click header → restore from collapsed
    panel.querySelector('.tc-header').addEventListener('dblclick', function () {
      panel.classList.remove('tc-collapsed');
      panel.classList.remove('tc-closed');
    });

    // Download — 直接下载最高清档位
    // triggerDownload 现在是 async，且只在真正写盘完成后才 ok（A2）
    let downloadTimer = null;
    let downloadToken = 0; // 递增 token：旧下载的 setTimeout 不得覆盖新下载的按钮状态
    panel.querySelector('#tc-btn-download').addEventListener('click', async function () {
      let dl = window.__TikTokCaptionHelper?.downloader;
      if (!dl) { alert('下载模块未就绪'); return; }
      const btn = this;
      if (btn.disabled) return;
      const original = btn.textContent;
      const token = ++downloadToken;
      if (downloadTimer) { clearTimeout(downloadTimer); downloadTimer = null; }
      btn.disabled = true;
      btn.textContent = '⏳ 下载中';
      const scheduleRestore = function (text, delay) {
        if (token !== downloadToken) return; // 已被更新的下载取代
        downloadTimer = setTimeout(function () {
          downloadTimer = null;
          if (token === downloadToken) btn.textContent = original;
        }, delay);
      };
      try {
        const r = await dl.triggerDownload(function (s) {
          if (token === downloadToken && s.phase === 'downloading') {
            btn.textContent = '⏳ ' + (s.detail || '下载中');
          }
        });
        if (r.ok) {
          btn.textContent = '✅ 已保存';
          scheduleRestore(original, 2500);
        } else if (r.code === 'USER_CANCELLED') {
          btn.textContent = original;
        } else {
          btn.textContent = '❌ 失败';
          alert('下载失败: ' + (r.message || r.code || '未知原因'));
          scheduleRestore(original, 2500);
        }
      } catch (e) {
        btn.textContent = '❌ 失败';
        alert('下载失败: ' + e.message);
        scheduleRestore(original, 2500);
      } finally {
        btn.disabled = false;
      }
    });

    // Copy
    panel.querySelector('#tc-btn-copy').addEventListener('click', copySubtitles);

    panel.querySelector('#tc-btn-translate').addEventListener('click', function () {
      startManualTranslation().catch(function (error) { console.error('[字幕助手] 翻译失败:', error.message); });
    });

    // Speech recognition
    panel.querySelector('#tc-btn-speech').addEventListener('click', function () {
      let whisper = window.__TikTokCaptionHelper?.whisperSTT;
      if (whisper) { requestVideoTranslation({ force: true }).catch(function (error) { console.error('[Pipeline] forced STT failed:', error.message); }); }
      else { alert('语音识别模块未就绪'); }
    });

    // FYP fetch subtitles button (delegated — button created dynamically)
    panel.querySelector('#tc-content').addEventListener('click', function (e) {
      if (e.target && e.target.id === 'tc-btn-fetch-subtitles') {
        e.target.textContent = '⏳ 正在获取...';
        e.target.disabled = true;
        window.dispatchEvent(new CustomEvent('tc-request-fyp-subtitles'));
      }
    });

    // 语言纠正：点击源语言标签 → 弹出语言选择（toggle）
    panel.querySelector('#tc-content').addEventListener('click', function (e) {
      var btn = e.target && e.target.closest ? e.target.closest('#tc-src-lang-btn') : null;
      if (!btn) return;
      var existing = getContentEl() && getContentEl().querySelector('.tc-lang-picker');
      if (existing) { existing.remove(); return; }
      showLangPicker();
    });

    // Drag (header)
    initDrag(panel);
    // Resize (bottom-right handle)
    initResize(panel);
  }

  // ============================================================
  // 语言纠正 — 识别后一键切换语言重新识别（针对音乐视频误判）
  // ============================================================
  function showLangPicker() {
    var content = getContentEl();
    var langBar = content ? content.querySelector('#tc-lang-bar') : null;
    if (!content || !langBar) return;

    // 解除 DOM 锁，允许插入 picker（重新识别会重新锁定）
    unlockContentDOM();

    var picker = document.createElement('div');
    picker.className = 'tc-lang-picker';
    picker.style.cssText = 'margin-bottom:10px;padding:8px;background:var(--tc-surface);border:1px solid var(--tc-border);border-radius:8px;display:flex;flex-wrap:wrap;gap:6px;';
    picker.innerHTML = '<span style="width:100%;font-size:11px;color:var(--tc-text-secondary);margin-bottom:2px;">选择识别语言，立即重新识别：</span>';

    for (var i = 0; i < STT_LANGS.length; i++) {
      (function (lang) {
        var b = document.createElement('button');
        b.className = 'tc-btn';
        b.textContent = lang.name;
        b.style.cssText = 'padding:4px 8px;font-size:12px;';
        b.addEventListener('click', function () {
          picker.remove();
          var whisper = window.__TikTokCaptionHelper?.whisperSTT;
          if (whisper && whisper.startWhisper) requestVideoTranslation({ force: true, forceLang: lang.code });
        });
        picker.appendChild(b);
      })(STT_LANGS[i]);
    }

    // 插入到语言栏下方
    if (langBar.nextSibling) {
      content.insertBefore(picker, langBar.nextSibling);
    } else {
      content.appendChild(picker);
    }
  }

  // ============================================================
  // Render subtitle data into the panel
  // ============================================================
  function renderSubtitles(subtitleData, videoId, binding, discovery) {
    if (!discovery && binding && binding.subtitleStatus) {
      discovery = { status: binding.subtitleStatus, reason: binding.subtitleReason };
    }
    var taskBinding = binding || currentSourceBinding();
    taskBinding = Object.assign({}, taskBinding, { videoId: videoId || taskBinding.videoId });
    var key = sourceBindingKey(taskBinding);
    var api = window.__TikTokCaptionHelper?.apiInterceptor;
    if (api && api.getCurrentRouteState && key !== sourceBindingKey(currentSourceBinding())) return Promise.resolve({ status: 'stale' });
    if (subtitleTask && subtitleTask.key === key && (subtitleTask.status === 'checking' || subtitleTask.status === 'ready') && state && !state.canStartSubtitle(videoId)) return subtitleTask.promise;
    var task = { key: key, status: 'checking' };
    subtitleTask = task;
    task.promise = renderSubtitleTask(subtitleData, videoId, binding, discovery).then(function (outcome) {
      task.status = outcome.status;
      return outcome;
    });
    if (translationAttempt && translationAttempt.key === key && translationAttempt.wake) translationAttempt.wake();
    return task.promise;
  }

  async function renderSubtitleTask(subtitleData, videoId, binding, discovery) {
    var content = getContentEl();
    if (!content) return { status: 'error', reason: 'panel-unavailable' };
    if (!state) { console.warn('[字幕助手] State not available'); return { status: 'error', reason: 'state-unavailable' }; }
    if (binding) binding = Object.freeze(Object.assign({}, binding));

    function isBindingStillCurrent() {
      var currentPageVideoId = (location.pathname.match(/\/video\/(\d+)/) || [])[1] || null;
      if (currentPageVideoId && videoId && String(videoId) !== String(currentPageVideoId)) return false;
      if (!binding || !window.__TikTokCaptionHelper?.apiInterceptor ||
          typeof window.__TikTokCaptionHelper.apiInterceptor.getCurrentRouteState !== 'function') return true;
      var currentRoute = window.__TikTokCaptionHelper.apiInterceptor.getCurrentRouteState();
      if (currentPageVideoId && !binding.mediaKey && !binding.wrapperId) return true;
      var epochMatches = binding.routeEpoch === undefined || binding.routeEpoch === null ||
        String(binding.routeEpoch) === String(currentRoute.epoch);
      var wrapperMatches = !binding.wrapperId || binding.wrapperId === currentRoute.wrapperId;
      var mediaMatches = !binding.mediaKey || binding.mediaKey === currentRoute.mediaKey;
      var videoMatches = !videoId || !currentRoute.videoId || String(videoId) === String(currentRoute.videoId);
      return epochMatches && wrapperMatches && mediaMatches && videoMatches;
    }

    // ── videoId 校验：拒绝不属于当前页面的数据 ──
    // SPA 导航时 onSubtitles replay 可能推送上一个视频的 subtitleData
    var pageVideoId = (location.pathname.match(/\/video\/(\d+)/) || [])[1] || null;
    if (pageVideoId && videoId && String(videoId) !== String(pageVideoId)) {
      console.warn('[字幕助手] ⏭ renderSubtitles rejected: videoId mismatch. ' +
        'data=' + videoId + ' page=' + pageVideoId);
      return { status: 'stale' };
    }

    // FYP subtitle packets must still match the active player binding. A videoId
    // alone is insufficient because preload/advertisement/media revisions can
    // share the same page route or ID.
    if (!isBindingStillCurrent()) {
      console.warn('[字幕助手] ⏭ renderSubtitles rejected: stale FYP media binding');
      return { status: 'stale' };
    }

    // 状态检查：非 idle 时拒绝新渲染（由 state.js 统一管理）
    if (!state.canStartSubtitle(videoId)) {
      console.log('[字幕助手] renderSubtitles skipped: state=' + state.getState() +
        ' videoId=' + (videoId || 'none') + ' debug=' + JSON.stringify(state.debugSnapshot()));
      return { status: 'blocked', reason: 'render-owned' };
    }

    if (videoId) {
      var cachedRender = state.getCachedRenderResult(videoId, binding);
      if (cachedRender && cachedRender.html) {
        var cachedReqId = state.startSubtitleLoad(videoId);
        if (cachedReqId < 0) return { status: 'blocked' };
        unlockContentDOM();
        content.innerHTML = cachedRender.html;
        subtitleSegments = cachedRender.segments || [];
        state.completeBilingualRender(videoId, cachedRender.html, cachedRender.segments, binding);
        lockContentDOM();
        console.log('[字幕助手] Render restored from cache for video ' + videoId);
        return { status: 'ready', reason: 'render-cache' };
      }
    }

    if (discovery && discovery.status === 'unknown') {
      unlockContentDOM();
      noSubtitlesVideo = false;
      content.innerHTML = '<div class="tc-empty" id="tc-subtitle-unknown-guide"><p>⏳ 尚未确认平台字幕状态</p><p style="font-size:13px;margin-top:10px;color:var(--tc-text-secondary);">视频数据仍在加载，请稍后重试；也可以手动点击 🎤 识别。</p></div>';
      return { status: 'unknown', reason: discovery.reason || 'unknown' };
    }
    if (discovery && discovery.status === 'error') {
      unlockContentDOM();
      noSubtitlesVideo = false;
      content.innerHTML = '<div class="tc-empty" id="tc-subtitle-error-guide"><p>❌ 字幕信息获取失败</p><p style="font-size:13px;margin-top:10px;color:var(--tc-text-secondary);">' + escapeHtml(discovery.reason || 'unknown error') + '；可以重试或手动点击 🎤 识别。</p></div>';
      return { status: 'error', reason: discovery.reason || 'subtitle-discovery-error' };
    }
    if (!subtitleData || subtitleData.length === 0) {
      unlockContentDOM();
      noSubtitlesVideo = true;
      content.innerHTML =
        '<div class="tc-empty" id="tc-no-subtitle-guide">' +
        '  <p style="font-size:16px;">🎬 该视频没有内置字幕</p>' +
        '  <p style="font-size:13px;margin-top:10px;color:var(--tc-text-secondary);">' +
        '  播放视频后，点击顶部 <span style="color:var(--tc-accent);font-weight:600;">🍪 识别</span> 使用 AI 语音转文字</p>' +
        '  <button class="tc-btn" id="tc-btn-fetch-subtitles" style="margin-top:8px;">🔍 尝试获取字幕</button>' +
        '</div>';
      return { status: !discovery || discovery.status === 'missing' ? 'missing' : 'unknown', reason: discovery && discovery.reason || 'no-tracks' };
    }

    // ── Segment 缓存：同一视频已解析过字幕 → 跳过 fetch，直接用缓存翻译 ──
    var cachedSegments = videoId ? state.getCachedSubtitleResult(videoId, binding) : null;
    if (cachedSegments && cachedSegments.segments.length > 0) {
      var myReqId = state.startSubtitleLoad(videoId);
      if (myReqId < 0) { console.log('[字幕助手] renderSubtitles: state.startSubtitleLoad rejected (cached path)'); return { status: 'blocked' }; }
      unlockContentDOM();
      content.innerHTML = '<div class="tc-loading"><span class="tc-spinner"></span>正在翻译...</div>';
      console.log('[字幕助手] Using cached segments for video ' + videoId + ', skipping subtitle fetch');
      return new Promise(function (resolve) { chrome.storage.local.get(['targetLang'], function (stored) {
        if (myReqId !== state.getRenderReqId() || !isBindingStillCurrent()) { resolve({ status: 'stale' }); return; }
        var targetLang = stored.targetLang || 'zh';
        renderBilingualResult(cachedSegments, targetLang, myReqId, videoId, binding).catch(function (error) { console.error('[字幕助手] Translation failed:', error.message); });
        resolve({ status: 'ready', reason: 'segment-cache' });
      }); });
    }

    // 同步加锁（state.js 管理状态转换，原子操作）
    var myReqId = state.startSubtitleLoad(videoId);
    if (myReqId < 0) {
      console.log('[字幕助手] renderSubtitles: state.startSubtitleLoad rejected');
      return { status: 'blocked' };
    }

    unlockContentDOM();
    content.innerHTML = '<div class="tc-loading"><span class="tc-spinner"></span>正在加载字幕...</div>';

    var fetcher = window.__TikTokCaptionHelper?.subtitleFetcher;
    if (!fetcher) {
      content.innerHTML = '<div class="tc-empty"><p>❌ 字幕加载模块未就绪</p></div>';
      state.failSubtitleLoad();
      return { status: 'error', reason: 'fetcher-unavailable' };
    }

    // 获取目标语言，用于选择最佳字幕轨道
    return new Promise(function (resolve) { chrome.storage.local.get(['targetLang'], function (stored) {
      var targetLang = stored.targetLang || 'zh';
      fetcher.fetchSubtitleContent(subtitleData, targetLang)
        .then(function (result) {
          if (myReqId !== state.getRenderReqId() || !isBindingStillCurrent()) { resolve({ status: 'stale' }); return; }
          if (result && result.status === 'error') {
            throw new Error('字幕链接不可用或内容无法解析，请重试获取字幕；也可以手动识别当前视频原声。');
          }
          if (result && (result.status === 'missing' || result.status === 'label_only')) {
            renderBilingualResult(result, targetLang, myReqId, videoId, binding).catch(function (error) { console.error('[字幕助手] Label preview failed:', error.message); });
            resolve({ status: result.status === 'label_only' ? 'label_only' : 'missing', reason: result.reason || 'empty-tracks' });
            return;
          }
          // Cache the subtitle result so subsequent events skip fetch
          if (videoId && result && result.segments.length > 0) {
            state.cacheSubtitleResult(videoId, result, binding);
          }
          renderBilingualResult(result, targetLang, myReqId, videoId, binding).catch(function (error) { console.error('[字幕助手] Translation failed:', error.message); });
          resolve({ status: result.segments.length ? 'ready' : 'missing', reason: result.reason || (result.segments.length ? 'cues' : 'empty-tracks') });
        })
        .catch(function (err) {
          if (myReqId !== state.getRenderReqId() || !isBindingStillCurrent()) { resolve({ status: 'stale' }); return; }
          content.innerHTML =
            '<div class="tc-empty">' +
            '  <p>❌ 字幕加载失败</p>' +
            '  <p style="font-size:12px;">' + escapeHtml(err.message) + '</p>' +
            '</div>';
          state.failSubtitleLoad();
          resolve({ status: 'error', reason: 'subtitle-fetch-error' });
          console.log('[字幕助手] Bilingual render failed, lock released for retry');
        });
    }); });
  }

  // ============================================================
  // Helper: quick language detection for translation quality check
  // ============================================================
  function hasCJK(text) {
    if (!text) return false;
    var cjk = 0, total = 0;
    for (var i = 0; i < text.length; i++) {
      var c = text.charCodeAt(i);
      if (c <= 0x40 || (c >= 0x5B && c <= 0x60) || (c >= 0x7B && c <= 0x7E)) continue;
      total++;
      if ((c >= 0x4E00 && c <= 0x9FFF) || (c >= 0x3400 && c <= 0x4DBF) ||
          (c >= 0x3040 && c <= 0x30FF) || (c >= 0xAC00 && c <= 0xD7AF) ||
          (c >= 0x3000 && c <= 0x303F) || (c >= 0xFF00 && c <= 0xFFEF)) cjk++;
    }
    return total >= 2 && (cjk / total) > 0.5;
  }

  // ============================================================
  // Helper: langBase — normalizes language codes
  // ============================================================
  function langBase(l) {
    var b = (l || '').split('-')[0].toLowerCase();
    var MAP = {
      'cmn': 'zh', 'zho': 'zh', 'chi': 'zh', 'chinese': 'zh', 'mandarin': 'zh',
      'eng': 'en', 'english': 'en',
      'jpn': 'ja', 'japanese': 'ja',
      'kor': 'ko', 'korean': 'ko',
      'fre': 'fr', 'fra': 'fr', 'french': 'fr',
      'deu': 'de', 'ger': 'de', 'german': 'de',
      'spa': 'es', 'spanish': 'es',
      'por': 'pt', 'portuguese': 'pt',
      'rus': 'ru', 'russian': 'ru',
      'ara': 'ar', 'arabic': 'ar',
      'ind': 'id', 'indonesian': 'id',
      'tur': 'tr', 'turkish': 'tr',
      'ita': 'it', 'italian': 'it',
      'msa': 'ms', 'may': 'ms', 'malay': 'ms',
      'vie': 'vi', 'vietnamese': 'vi',
      'tha': 'th', 'thai': 'th',
    };
    return MAP[b] || b;
  }

  // ============================================================
  // AI 翻译统一入口：严格判据 + 错误分型 + 可恢复错误重试
  // 成功条件：所有「原文非空」的行都有「非空译文」。
  //   —— 修复截断误判：AI 只翻出部分行时，不能把 filter(Boolean)>0 当成功。
  // 可重试错误：rate_limit / server / network
  // 不可重试：auth（key 无效）/ param / parse / config
  // ============================================================
  async function translateAIWithRetry(ai, texts, targetLang, srcBase, engine, key, config) {
    var MAX_ATTEMPTS = 2;
    var RETRYABLE = { rate_limit: true, server: true, network: true };
    var lastError = { type: 'partial' };

    for (var attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
      var result = await ai.translateWithMeta(texts, targetLang, srcBase, Object.assign({}, config, { engine: engine, key: key }));
      var translations = result.translations || [];

      // 严格判据：原文非空行 → 译文也必须非空
      var complete = translations.length >= texts.length;
      for (var i = 0; complete && i < texts.length; i++) {
        if (texts[i] && String(texts[i]).trim() !== '') {
          if (!translations[i] || String(translations[i]).trim() === '') complete = false;
        }
      }

      if (complete && !result.error) {
        return { ok: true, translations: translations, corrections: result.corrections || [], engine: engine };
      }

      // error=null 但判据未通过 → AI 返回了但不完整（截断/空洞），按可重试处理
      var errType = result.error ? result.error.type : 'partial';
      lastError = result.error || { type: 'partial' };
      var retryable = !!RETRYABLE[errType] || errType === 'partial';
      if (!retryable) {
        console.warn('[字幕助手] AI 翻译失败（' + errType + '），保留原文，未自动切换到 Google');
        return { ok: false, translations: [], engine: engine, error: lastError };
      }

      if (attempt < MAX_ATTEMPTS - 1) {
        console.warn('[字幕助手] AI 翻译' + (errType === 'partial' ? '截断' : '失败') + '（' + errType + '），1s 后重试（' + (attempt + 1) + '/' + (MAX_ATTEMPTS - 1) + '）');
        await new Promise(function (r) { setTimeout(r, 1000); });
      }
    }

    console.warn('[字幕助手] AI 翻译重试后仍失败，保留原文');
    return { ok: false, translations: [], engine: engine, error: lastError };
  }

  // ============================================================
  // 一次性渲染双语字幕 — 先翻译，再渲染，消除 DOM 竞态
  // ============================================================
  async function renderBilingualResult(result, targetLang, myReqId, videoId, binding) {
    var settingsRevision = translationSettingsRevision;
    var content = getContentEl();
    if (!content) return;
    if (!binding && result && (result.mediaKey || result.routeEpoch != null || result.wrapperId)) {
      binding = {
        videoId: videoId,
        mediaKey: result.mediaKey || null,
        routeEpoch: result.routeEpoch,
        wrapperId: result.wrapperId || null
      };
    }
    if (binding) binding = Object.freeze(Object.assign({}, binding));

    function isCurrentRender() {
      if (settingsRevision !== translationSettingsRevision) return false;
      if (myReqId !== state.getRenderReqId()) return false;
      var currentVideoId = state.getVideoId && state.getVideoId();
      if (videoId && currentVideoId && String(videoId) !== String(currentVideoId)) return false;
      if (typeof result.isMediaBindingCurrent === 'function') {
        return result.isMediaBindingCurrent();
      }
      var interceptor = window.__TikTokCaptionHelper?.apiInterceptor;
      if (binding && interceptor && typeof interceptor.getCurrentRouteState === 'function') {
        var route = interceptor.getCurrentRouteState();
        if (binding.routeEpoch != null && String(binding.routeEpoch) !== String(route.epoch)) return false;
        if (binding.mediaKey && binding.mediaKey !== route.mediaKey) return false;
        if (binding.wrapperId && binding.wrapperId !== route.wrapperId) return false;
        if (videoId && route.videoId && String(videoId) !== String(route.videoId)) return false;
      }
      return true;
    }

    if (!isCurrentRender()) return;
    if (state && state.acceptTranscriptRevision && !state.acceptTranscriptRevision(result.transcriptContract)) {
      console.log('[字幕助手] 丢弃旧 transcript revision:', result.transcriptContract && {
        revision: result.transcriptContract.revision,
        sequence: result.transcriptContract.sequence,
        sessionId: result.transcriptContract.sessionId
      });
      return;
    }

    var segments = result.segments || [];
    currentTranslationSource = { result: Object.assign({}, result, { segments: segments.map(function (segment) { return Object.assign({}, segment); }) }), targetLang: targetLang, videoId: videoId, binding: binding };
    subtitleSegments = segments;
    var lowConfidenceWarning = '';
    if (result.isSTT) {
      for (var qi = 0; qi < segments.length; qi++) {
        var diagnosticSource = segments[qi] && segments[qi].diagnostics && typeof segments[qi].diagnostics === 'object'
          ? segments[qi].diagnostics
          : segments[qi];
        var avgLogprob = diagnosticSource && diagnosticSource.avg_logprob;
        if (typeof avgLogprob === 'number' && Number.isFinite(avgLogprob) && avgLogprob < -2) {
          lowConfidenceWarning = '部分原文识别置信度较低，可能存在误听；原文和翻译仅供参考。';
          break;
        }
      }
    }

    if (segments.length === 0) {
      if (!isCurrentRender()) return;
      content.innerHTML = '<div class="tc-empty"><p>📭 字幕内容为空</p></div>';
      state.failSubtitleLoad();
      console.log('[字幕助手] Bilingual render: empty segments, lock released');
      return;
    }

    // ── 音乐元标签与纯音乐检测 ──
    // 音乐视频的 VTT 文件通常只有 "."、"♪" 等占位符，无需翻译。
    // 识别候选仍然是有效输出，提示必须与候选内容并列，不能覆盖候选。
    var ALL_SYMBOLS = /^[\s\.\,\-\~\♪\♫\♬\♩\🎵\🎶\#\*\!\(\)\[\]\{\}\|\&\%\$\@\"\'\/\\\:\;\+\=\?\¿\¡\…\·\•\|\~\`\^]+$/;
    var MUSIC_METADATA = /^(?:music|\[\s*music\s*\]|(?:intro|outro|background|instrumental|theme|opening|closing)\s+music)$/i;
    function isMusicMetadata(text) {
      return MUSIC_METADATA.test(String(text || '').trim().replace(/[.!?,;:。！？、；：]+$/, '').trim());
    }
    function isMusicPlaceholder(text) {
      return ALL_SYMBOLS.test(String(text || '').trim());
    }
    var hasRealWords = false;
    for (var si = 0; si < segments.length; si++) {
      var s = (segments[si].text || '').trim();
      if (s && !isMusicPlaceholder(s) && !isMusicMetadata(s)) { hasRealWords = true; break; }
    }
    if (!hasRealWords) {
      if (!isCurrentRender()) return;
      var musicWarning =
        '<div class="tc-empty" style="padding:12px 16px 8px;">' +
        '  <p style="font-size:16px;">' + (result.isSTT ? '⚠ 未识别到有效语音' : '⚠ 平台字幕仅包含音乐标签，未提供可翻译原文') + '</p>' +
        '  <p style="font-size:13px;margin-top:8px;color:var(--tc-text-secondary);">' +
        (result.isSTT ? '  可能未获取到口播音轨，或语音被背景音盖过。请重试，或在视频详情页识别。</p>' :
          '  点击顶部 <span style="color:var(--tc-accent);font-weight:600;">🎤 识别</span> 使用 AI 语音识别（如果有原声）</p>') +
        '</div>';
      var candidateHtml = '';
      for (var ci = 0; ci < segments.length; ci++) {
        var candidate = segments[ci];
        if (!candidate.text) continue;
        candidateHtml += '<div class="tc-subtitle-segment" data-idx="' + ci + '">';
        if (candidate.time) candidateHtml += '<div class="tc-subtitle-time">⏱ ' + escapeHtml(candidate.time) + '</div>';
        candidateHtml += '<div class="tc-subtitle-text">' + escapeHtml(candidate.text) + '</div></div>';
      }
      var musicSource = result.isSTT ? '' : '<div style="color:var(--tc-text-secondary);font-size:12px;margin:0 16px 8px;">📝 平台字幕</div>';
      content.innerHTML = musicSource + musicWarning + candidateHtml;
      subtitleSegments = segments.map(function (segment) {
        return { time: segment.time || '', text: segment.text || '' };
      });
      if (result.isSTT) {
        unlockContentDOM();
        state.completeSTT(videoId, content.innerHTML, subtitleSegments, 'candidate');
      } else {
        state.failSubtitleLoad();
      }
      console.log('[字幕助手] ' + (result.isSTT ? 'STT returned no valid speech' : 'Music-only detected') + ': all ' + segments.length + ' segments are symbols, skipping translation');
      return;
    }

    function renderSourcePreview() {
      if (!isCurrentRender()) return;
      var previewAt = Date.now();
      var previewLabel = result.isSTT ? 'AI 原文候选' : '平台字幕';
      var previewRouteLabels = {
        verified_media_no_caption: '当前媒体原声',
        realtime_capture: '实时采音',
        speech_url: '缓存原声链接',
        cached_audio_url: '缓存音频',
        music_candidate: '音乐候选',
        unknown: '未确认音频'
      };
      if (result.isSTT && result.sourceRoute) {
        previewLabel += ' · 来源：' + (previewRouteLabels[result.sourceRoute] || result.sourceRoute);
      }
      var previewWarnings = [];
      if (result.isSTT && result.candidateWarning) previewWarnings.push(result.candidateWarning);
      if (lowConfidenceWarning) previewWarnings.push(lowConfidenceWarning);
      var previewWarning = previewWarnings.length
        ? '<span style="color:#f59e0b;font-size:11px;margin-left:8px;">⚠ ' + escapeHtml(previewWarnings.join(' · ')) + '</span>'
        : '';
      var previewHtml = '<div style="margin-bottom:10px;padding:6px 10px;background:var(--tc-surface);border-radius:6px;font-size:12px;">' +
        '<span style="color:var(--tc-text-secondary);">📝 ' + previewLabel + '</span>' +
        '<span style="color:var(--tc-text-secondary);font-size:11px;margin-left:8px;">正在准备翻译…</span>' + previewWarning + '</div>';
      for (var pi = 0; pi < segments.length; pi++) {
        var previewSegment = segments[pi];
        if (!previewSegment || !previewSegment.text) continue;
        previewHtml += '<div class="tc-subtitle-segment" data-idx="' + pi + '">';
        if (previewSegment.time) previewHtml += '<div class="tc-subtitle-time">⏱ ' + escapeHtml(previewSegment.time) + '</div>';
        previewHtml += '<div class="tc-subtitle-text">' + escapeHtml(previewSegment.text) + '</div></div>';
      }
      content.innerHTML = previewHtml;
      var candidateMs = result.timing && result.timing.candidateMs;
      console.log('[字幕助手] 原文预览已显示，等待翻译完成', {
        previewMs: candidateMs == null ? null : Date.now() - previewAt,
        candidateMs: candidateMs == null ? null : candidateMs,
        pipelineMs: result.timing && result.timing.pipelineMs,
        sttRequests: result.timing && result.timing.sttRequests
      });
    }

    renderSourcePreview();
    var translationStartedAt = Date.now();

    var srcLang = result.actualLang || result.sourceLang || 'unknown';
    var srcBase = langBase(srcLang);
    var tgtBase = langBase(targetLang);
    console.log('[字幕助手] renderBilingual: actualLang="' + result.actualLang + '" sourceLang="' + result.sourceLang + '" srcLang="' + srcLang + '" srcBase="' + srcBase + '" tgtBase="' + tgtBase + '"');

    var srcLangName = LANG_MAP[srcBase] || srcLang;
    var tgtLangName = LANG_MAP[tgtBase] || targetLang;
    var needsTranslation = srcBase !== tgtBase;

    var texts = segments.map(function (s) { return s.text; });
    var gt = window.__TikTokCaptionHelper?.googleTranslate;
    var ai = window.__TikTokCaptionHelper?.aiTranslate;

    // 读取翻译引擎配置
    var stored = await new Promise(function (resolve) {
      chrome.storage.local.get(['translateEngine', 'aiTranslateKey', 'aiTranslateEndpoint', 'aiTranslateModel', 'aiTranslateCorrections', 'aiTranslateAllowInsecure'], resolve);
    });
    var engine = stored.translateEngine || 'google';
    var aiKey = stored.aiTranslateKey || '';
    var aiConfig = engine === 'openai' ? { endpoint: stored.aiTranslateEndpoint, model: stored.aiTranslateModel, corrections: !!stored.aiTranslateCorrections, allowInsecure: !!stored.aiTranslateAllowInsecure } : {};
    var corrections = [];

    // ── 翻译（或反向翻译） ──
    // 策略: 使用用户选择的引擎
    var translations = [];
    var displayOriginal = texts;      // 第一行显示的文本
    var displayTranslation = [];      // 第二行显示的文本
    var displaySrcName = srcLangName;
    var usedEngine = engine;
    var aiFailure = engine !== 'google' && (!aiKey || !ai) ? { type: 'config' } : null;
    var fromCache = false;
    var translationFailed = false;
    var candidateTranslation = !!result.isSTT && (
      result.mediaMatchStatus !== 'verified' ||
      result.stability === 'candidate'
    );
    var translationCacheEligible = !candidateTranslation && engine === 'google';
    var googleGroups = null;
    var sentenceGroups = window.__TikTokCaptionHelper?.sentenceGroups;
    if (sentenceGroups) translationCacheEligible = false;

    // Compute reverse target for cache key and potential reverse translation
    var reverseTarget = srcBase === 'en' ? 'zh' : 'en';
    var transTarget = needsTranslation ? tgtBase : reverseTarget;

    // ── 逐句语言判断：中英混合时，已经是目标语言的句子跳过翻译 ──
    // 例：en→zh 混合视频里的中文句"走远点"不该被当英文翻成"跑点"。
    // langDetect.isAlreadyTargetLang 逐句判定；无检测器/非 en-zh 目标 → 全部照翻（旧行为）。
    var langDetect = window.__TikTokCaptionHelper && window.__TikTokCaptionHelper.langDetect;
    var toTranslate = [];
    var toTranslateIdx = [];
    var skippedCount = 0;
    for (var ti = 0; ti < texts.length; ti++) {
      if (isMusicMetadata(texts[ti]) || isMusicPlaceholder(texts[ti])) continue;
      var need = true;
      if (langDetect && langDetect.isAlreadyTargetLang) {
        need = !langDetect.isAlreadyTargetLang(texts[ti], transTarget);
      }
      if (need) { toTranslate.push(texts[ti]); toTranslateIdx.push(ti); }
      else { skippedCount++; }
    }
    if (skippedCount > 0) {
      console.log('[字幕助手] 逐句语言判断: ' + skippedCount + '/' + texts.length + ' 句已是目标语言(' + transTarget + ')，跳过翻译');
    }

    // 子集翻译结果还原成与 texts 等长的数组（跳过句填 ''，渲染层不显示译文行）
    function reassemble(subTranslations) {
      var out = new Array(texts.length);
      for (var oi = 0; oi < texts.length; oi++) out[oi] = '';
      for (var k = 0; k < toTranslateIdx.length; k++) {
        out[toTranslateIdx[k]] = subTranslations[k] || '';
      }
      return out;
    }

    function previewGoogleTranslation(index, text) {
      if (!isCurrentRender()) return;
      if (!Number.isInteger(index) || index < 0 || index >= toTranslateIdx.length) return;
      if (typeof text !== 'string' || !text.trim()) return;
      var segmentIndex = toTranslateIdx[index];
      var segmentNode = content.querySelector('.tc-subtitle-segment[data-idx="' + segmentIndex + '"]');
      if (!segmentNode) return;
      var translationNode = segmentNode.querySelector('.tc-subtitle-translation');
      if (!translationNode) {
        translationNode = document.createElement('div');
        translationNode.className = 'tc-subtitle-translation';
        segmentNode.appendChild(translationNode);
      }
      translationNode.textContent = text;
    }

    async function translateGoogleSentences(target, source, progressive) {
      googleGroups = sentenceGroups ? sentenceGroups.group(segments, toTranslateIdx) : toTranslateIdx.map(function (index) {
        return { indices: [index], text: texts[index] };
      });
      var groupedTexts = googleGroups.map(function (entry) { return entry.text; });
      var options = progressive ? { onProgress: function (index, text) {
        if (!Number.isInteger(index) || index < 0) return;
        if (!googleGroups[index]) return;
        var indices = googleGroups[index].indices;
        previewGoogleTranslation(toTranslateIdx.indexOf(indices[indices.length - 1]), text);
      } } : undefined;
      console.log('[Translate] sentence groups: ' + toTranslate.length + ' fragments → ' + googleGroups.length + ' groups');
      var groupedTranslations = progressive ? await gt.translate(groupedTexts, target, source, options) : await gt.translate(groupedTexts, target, source);
      var mapped = new Array(texts.length).fill('');
      googleGroups.forEach(function (entry, index) {
        mapped[entry.indices[entry.indices.length - 1]] = groupedTranslations[index] || '';
      });
      return mapped;
    }

    // ── 翻译缓存查询（优先命中，省 API 费用） ──
    if (videoId && translationCacheEligible) {
      var cachedTrans = state.getCachedTranslation(videoId, srcBase, transTarget, texts, binding);
      if (cachedTrans && cachedTrans.length === texts.length) {
        translations = cachedTrans.map(function (translation, cachedIndex) {
          return isMusicMetadata(texts[cachedIndex]) ? '' : (translation || '');
        });
        fromCache = true;
        var cachedOk = translations.filter(Boolean).length;
        console.log('[字幕助手] 🗄 Translation cache HIT for video ' + videoId + ' ' + srcBase + '→' + transTarget + '. ' + cachedOk + '/' + translations.length + ' lines.');
      }
    }
    displayTranslation = translations;

    if (!fromCache && needsTranslation) {
      // 正常翻译：源语言 → 目标语言（只翻需要的子集，已是目标语言的句子跳过）
      // 1) 先试 AI（严格判据 + 错误分型 + 可恢复错误重试）
      if (engine !== 'google' && aiKey && ai) {
        try {
          var aiRes = await translateAIWithRetry(ai, toTranslate, targetLang, srcBase, engine, aiKey, aiConfig);
          if (aiRes.ok) {
            translations = reassemble(aiRes.translations);
            usedEngine = aiRes.engine;
            corrections = reassemble(aiRes.corrections);
            // 缓存 AI 翻译结果，避免重复 API 调用
            if (videoId && translationCacheEligible && isCurrentRender()) state.cacheTranslation(videoId, srcBase, tgtBase, translations, texts, binding);
          } else {
            aiFailure = aiRes.error;
            translations = []; // AI 失败，重置
          }
        } catch (error) {
          aiFailure = { type: 'network' };
          console.warn('[字幕助手] AI translation failed:', error.message);
          translations = [];
        }
      }
      if (engine === 'google' && gt) {
        try {
          translations = await translateGoogleSentences(targetLang, undefined, true);
        } catch (error) {
          console.warn('[字幕助手] Google translation failed:', error.message);
          translations = [];
        }
        // 缓存 Google 翻译结果
        if (videoId && translationCacheEligible && translations.filter(Boolean).length > 0 && isCurrentRender()) state.cacheTranslation(videoId, srcBase, tgtBase, translations, texts, binding);
      }
      displayTranslation = translations;
      translationFailed = translations.filter(Boolean).length === 0 && toTranslate.length > 0;
      displaySrcName = srcLangName;
      var ok = translations.filter(Boolean).length;
      console.log('[字幕助手] Bilingual: ' + srcLangName + '(' + srcLang + ') → ' + tgtLangName + '(' + targetLang + ') [' + usedEngine + ']. ' + ok + '/' + texts.length + ' segments' + (skippedCount ? ' (' + skippedCount + ' skipped)' : '') + '.');
      for (var di = 0; di < Math.min(3, texts.length); di++) {
        console.log('[字幕助手]   tr[' + di + '] orig="' + texts[di].slice(0, 60) + '" → trans="' + (translations[di] || '(empty)').slice(0, 60) + '"');
      }
    } else if (!fromCache) {
      // 源语言 = 目标语言（如只有中文字幕）
      // 反向翻译到英文（或其他非目标语言）来制造双语
      // 1) 先试 AI（严格判据 + 错误分型 + 可恢复错误重试）
      if (engine !== 'google' && aiKey && ai) {
        try {
          var revAiRes = await translateAIWithRetry(ai, toTranslate, reverseTarget, srcBase, engine, aiKey, aiConfig);
          if (revAiRes.ok) {
            translations = reassemble(revAiRes.translations);
            usedEngine = revAiRes.engine;
            corrections = reassemble(revAiRes.corrections);
            // 缓存 AI 反向翻译结果
            if (videoId && translationCacheEligible && isCurrentRender()) state.cacheTranslation(videoId, srcBase, reverseTarget, translations, texts, binding);
          } else {
            aiFailure = revAiRes.error;
            translations = []; // AI 失败，重置
          }
        } catch (error) {
          aiFailure = { type: 'network' };
          console.warn('[字幕助手] AI reverse translation failed:', error.message);
          translations = [];
        }
      }
      if (engine === 'google' && gt) {
        try {
          translations = await translateGoogleSentences(reverseTarget, targetLang, false);
        } catch (error) {
          console.warn('[字幕助手] Google reverse translation failed:', error.message);
          translations = [];
        }
        // 缓存 Google 反向翻译结果
        if (videoId && translationCacheEligible && translations.filter(Boolean).length > 0 && isCurrentRender()) state.cacheTranslation(videoId, srcBase, reverseTarget, translations, texts, binding);
      }
      // 原文放第一行（用户目标语言），反译结果放第二行（参考）
      displayOriginal = texts;
      displayTranslation = translations;
      displaySrcName = srcLangName;
      var revOk = translations.filter(Boolean).length;
      translationFailed = revOk === 0 && toTranslate.length > 0;
      console.log('[字幕助手] Reverse-bilingual: ' + srcLangName + ' → ' + (LANG_MAP[reverseTarget] || reverseTarget) + ' (反译) [' + usedEngine + ']. ' + revOk + '/' + texts.length + ' segments' + (skippedCount ? ' (' + skippedCount + ' skipped)' : '') + '.');
      for (var rdi = 0; rdi < Math.min(3, texts.length); rdi++) {
        console.log('[字幕助手]   rev[' + rdi + '] orig="' + texts[rdi].slice(0, 60) + '" → trans="' + (translations[rdi] || '(empty)').slice(0, 60) + '"');
      }
      // 反译质量检查（取第一个真正翻译的句子，跳过句填 '' 不参与）
      if (revOk > 0 && toTranslateIdx.length > 0) {
        var firstIdx = toTranslateIdx[0];
        var sampleCheck = translations[firstIdx] && (hasCJK(translations[firstIdx]) === hasCJK(texts[firstIdx]));
        if (sampleCheck) {
          console.warn('[字幕助手] ⚠ Reverse translation may have failed: first result same language as source');
        }
      }
    }

    // 防竞态：stale 调用不渲染
    if (!isCurrentRender()) {
      console.log('[字幕助手] Stale render #' + myReqId + ' discarded (current #' + state.getRenderReqId() + ')');
      return;
    }

    // ── 一次性构建 HTML ──
    var isReverse = !needsTranslation;
    var isSTT = !!result.isSTT;
    var sourceLabel = isSTT ? 'AI 原文候选' : '平台字幕';
    if (isSTT) {
      var routeLabels = {
        verified_media_no_caption: '当前媒体原声',
        realtime_capture: '实时采音',
        speech_url: '缓存原声链接',
        cached_audio_url: '缓存音频',
        music_candidate: '音乐候选',
        unknown: '未确认音频'
      };
      sourceLabel += ' · 来源：' + (routeLabels[result.sourceRoute] || result.sourceRoute || '未确认');
    }
    var sourceNote = '';
    if (isSTT) {
      var contentClassLabels = {
        speech: '人物对白',
        dialogue_plus_bgm: '对白+BGM',
        lyric: '歌曲/歌词',
        singing: '演唱',
        music_only: '纯音乐',
        overlap: '重叠人声',
        label_only: '音乐标签',
        unknown: '音频类型未确认'
      };
      var contentClassLabel = contentClassLabels[result.contentClass];
      var evidenceText = typeof result.audioEvidence === 'string' ? result.audioEvidence :
        (result.audioEvidence && result.audioEvidence.note) || '音频内容未独立验证';
      var bindingText = result.audioEvidence && result.audioEvidence.binding === 'wrapper' ? 'wrapper：不代表音频内容已确认' : '';
      var matchText = result.mediaMatchStatus === 'verified' || result.mediaMatchStatus === 'wrapper_bound' ? '媒体匹配：已绑定' : '媒体匹配：未确认';
      var certaintyText = result.mediaMatchStatus === 'wrapper_bound' || result.stability === 'final' ? '不代表正确' : '';
      var stabilityText = result.stability === 'final' && certaintyText ? 'final（不代表正确）' : (result.stability || '');
      sourceNote = '<span style="color:#f59e0b;font-size:11px;" title="' + escapeHtml(evidenceText) + '">' +
        '⚠ ' + escapeHtml(result.candidateWarning || 'AI 识别候选，原文可能有误') +
        ' · ' + matchText +
        (bindingText ? ' · ' + bindingText : '') +
        (contentClassLabel ? ' · 类型：' + escapeHtml(contentClassLabel) : '') +
        (certaintyText ? ' · ' + certaintyText : '') +
        (stabilityText ? ' · ' + escapeHtml(stabilityText) : '') +
        (result.model ? ' · ' + escapeHtml(result.model) : '') + '</span>';
      if (lowConfidenceWarning) {
        sourceNote += '<span style="color:#f59e0b;font-size:11px;margin-left:8px;">⚠ ' + escapeHtml(lowConfidenceWarning) + '</span>';
      }
    }
    var srcLangSpan = isSTT
      ? '<span id="tc-src-lang-btn" style="color:var(--tc-text);font-weight:600;cursor:pointer;border-bottom:1px dashed var(--tc-text-secondary);" title="识别语言不对？点击切换">' + displaySrcName + ' ⇄</span>'
      : '<span style="color:var(--tc-text);font-weight:600;">' + displaySrcName + '</span>';
    var langBarHtml = '<div id="tc-lang-bar" style="margin-bottom:10px;padding:6px 10px;' +
      'background:var(--tc-surface);border-radius:6px;font-size:12px;' +
      'display:flex;align-items:center;gap:8px;flex-wrap:wrap;">' +
      '<span style="color:var(--tc-text-secondary);">📝 ' + sourceLabel + ':</span>' + srcLangSpan + sourceNote;

    if (needsTranslation) {
      // Build engine label for display
      var engineLabel = usedEngine === 'google' ? 'Google' : (usedEngine === 'deepseek' ? 'DeepSeek' : (usedEngine === 'openai' ? 'GPT' : (usedEngine === 'doubao' ? '豆包' : usedEngine)));
      var cacheTag = fromCache ? ' 🗄' : '';
      langBarHtml += '<span style="color:var(--tc-text-secondary);">→</span>' +
        '<span style="color:var(--tc-accent);font-weight:600;">' + tgtLangName + '</span>' +
        '<span id="tc-lang-status" style="color:' + (translationFailed ? '#f59e0b' : '#22c55e') + ';font-size:11px;margin-left:auto;">' +
        (translationFailed ? '⚠ 翻译失败，仅显示原文' : (candidateTranslation ? '⚠ 参考译文 · ' + engineLabel : '✅ ' + engineLabel + cacheTag)) + '</span>';
    } else {
      var revTargetName = LANG_MAP[reverseTarget] || reverseTarget;
      var revOk = translations.filter(Boolean).length;
      var revTotal = translations.length;
      var engineLabelRev = usedEngine === 'google' ? 'Google' : (usedEngine === 'deepseek' ? 'DeepSeek' : (usedEngine === 'openai' ? 'GPT' : (usedEngine === 'doubao' ? '豆包' : usedEngine)));
      var cacheTagRev = fromCache ? ' 🗄' : '';
      langBarHtml += '<span style="color:var(--tc-text-secondary);">→</span>' +
        '<span style="color:var(--tc-accent);font-weight:600;">' + revTargetName + '</span>' +
        '<span style="color:var(--tc-text-secondary);font-size:10px;">(反译)</span>' +
        '<span style="color:' + (revOk > 0 ? '#22c55e' : '#f59e0b') + ';font-size:11px;margin-left:auto;">' +
        (revOk > 0 ? (candidateTranslation ? '⚠ 参考译文 · ' + engineLabelRev : '✅ ' + engineLabelRev + cacheTagRev) + ' (' + revOk + '/' + revTotal + ')' : '⚠ 反向翻译失败，仅显示原文') +
        '</span>';
    }
    langBarHtml += '</div>';
    if (translationFailed && engine !== 'google') {
      var selectedLabel = { openai: 'GPT', deepseek: 'DeepSeek', doubao: '豆包' }[engine] || engine;
      var failureReasons = { auth: 'API Key 无效或没有权限', config: '请检查 API Key、请求地址、模型配置与主机权限', network: '网络连接失败或超时', rate_limit: '请求限流，请稍后重试', server: '服务端错误', param: '请求参数或模型名称错误', parse: '返回格式无法解析', partial: '返回译文不完整' };
      langBarHtml += '<div class="tc-translation-error" role="alert">⚠ ' + escapeHtml(selectedLabel) + ' 翻译失败：' + escapeHtml(aiFailure && aiFailure.message || failureReasons[aiFailure && aiFailure.type] || '请求未成功') + (aiFailure && aiFailure.status ? '（HTTP ' + aiFailure.status + '）' : '') + '。原文已保留，未自动切换到 Google。请修正配置，或手动选择 Google。</div>';
    }

    var listHtml = '';
    var groupStarts = {};
    if (usedEngine === 'google' && googleGroups) googleGroups.forEach(function (entry) {
      if (entry.indices.length < 2) return;
      groupStarts[entry.indices[0]] = entry;
    });
    for (var i = 0; i < segments.length; i++) {
      var groupedEntry = groupStarts[i] || null;
      var groupedInterior = googleGroups && googleGroups.some(function (entry) {
        return entry.indices.length > 1 && entry.indices.indexOf(i) > 0;
      });
      if (groupedInterior) continue;
      var seg = segments[i];
      var origText, transText;
      if (isReverse) {
        // 反向翻译模式：displayOriginal=原文(用户目标语言), displayTranslation=反译结果(参考)
        origText = displayOriginal[i] || '';
        transText = displayTranslation[i] || '';
        // 安全检查：如果两行内容相同（反译返回了原文，即翻译未生效），隐藏翻译行
        if (origText && transText && origText.trim() === transText.trim()) {
          transText = '';
        }
      } else {
        // 正常翻译模式：displayOriginal=原文, displayTranslation=译文
        origText = displayOriginal[i] || texts[i] || '';
        transText = displayTranslation[i] || '';
      }
      if (groupedEntry) {
        var firstSegment = segments[groupedEntry.indices[0]];
        var lastSegment = segments[groupedEntry.indices[groupedEntry.indices.length - 1]];
        origText = groupedEntry.text;
        transText = displayTranslation[groupedEntry.indices[groupedEntry.indices.length - 1]] || '';
        if (firstSegment.time && lastSegment.time) {
          var firstTime = firstSegment.time.match(/^(.+?)\s*-\s*(.+)$/);
          var lastTime = lastSegment.time.match(/^(.+?)\s*-\s*(.+)$/);
          if (firstTime && lastTime) seg = Object.assign({}, seg, { time: firstTime[1] + ' - ' + lastTime[2] });
        }
        listHtml += '<div class="tc-sentence-group" style="border:1px solid var(--tc-border);border-radius:8px;padding:6px;margin-bottom:8px;"><div style="font-size:11px;color:var(--tc-text-secondary);">整句翻译 · ' + groupedEntry.indices.length + ' 个原文片段</div>';
      }
      listHtml += '<div class="tc-subtitle-segment" data-idx="' + i + '">';
      if (seg.time) listHtml += '<div class="tc-subtitle-time">⏱ ' + escapeHtml(seg.time) + '</div>';
      if (origText) listHtml += '<div class="tc-subtitle-text">' + escapeHtml(origText) + '</div>';
      if (transText) listHtml += '<div class="tc-subtitle-translation">' + escapeHtml(transText) + '</div>';
      if (usedEngine === 'openai' && corrections[i]) {
        listHtml += '<details class="tc-subtitle-correction"><summary>GPT 校对候选（未听音频，不替换原文）</summary>' + escapeHtml(corrections[i]) + '</details>';
      }
      listHtml += '</div>';
      if (groupedEntry) listHtml += '</div>';
    }
    content.innerHTML = langBarHtml + listHtml;
    console.log('[字幕助手] 翻译结果已显示', {
      translationMs: Date.now() - translationStartedAt,
      translated: translations.filter(Boolean).length,
      total: segments.length
    });

    // ── DOM 验证：读取实际渲染内容，定位双中文根因 ──
    var verifyEls = content.querySelectorAll('.tc-subtitle-segment');
    for (var vi = 0; vi < Math.min(3, verifyEls.length); vi++) {
      var vOrig = verifyEls[vi].querySelector('.tc-subtitle-text');
      var vTrans = verifyEls[vi].querySelector('.tc-subtitle-translation');
      console.log('[字幕助手] DOM[' + vi + '] orig="' + (vOrig ? vOrig.textContent.slice(0, 60) : '(missing)') +
        '" trans="' + (vTrans ? vTrans.textContent.slice(0, 60) : '(missing)') + '"');
    }

    // 构建 copy 用的 segments（第一行文本）
    var newSegments = [];
    for (var j = 0; j < segments.length; j++) {
      newSegments.push({
        time: segments[j].time,
        text: displayOriginal[j] || texts[j] || ''
      });
    }
    subtitleSegments = newSegments;

    // 翻译完全失败时释放锁，允许重试
    // 逐句跳过：跳过句（已是目标语言）不算失败——只有「需要翻译的句子 0 成功」才释放锁。
    var translatedCount = translations.filter(Boolean).length;
    var allFailed = translatedCount === 0 && toTranslate.length > 0 && segments.length > 0;
    if (allFailed) {
      unlockContentDOM(); // allow retry
      state.failSubtitleLoad();
      console.log('[字幕助手] Translation all failed (0/' + segments.length + '), lock released for retry');
    } else {
      if (!isCurrentRender()) return;
      if (isSTT && candidateTranslation) {
        unlockContentDOM();
        state.completeSTT(videoId, langBarHtml + listHtml, newSegments, 'candidate');
        console.log('[字幕助手] STT candidate rendered & locked as stt_rendered; translation remains reference-only');
      } else {
        state.completeBilingualRender(videoId, langBarHtml + listHtml, newSegments, binding);
      }
      if (!candidateTranslation) {
        if (videoId) state.cacheRenderResult(videoId, langBarHtml + listHtml, newSegments, binding);
        var api = window.__TikTokCaptionHelper?.apiInterceptor;
        if (videoId && api && api.markVideoRendered) api.markVideoRendered(videoId);
      }
      // DOM 级别锁：MutationObserver 监控 #tc-content，外部覆盖立即恢复
      lockContentDOM();
      console.log('[字幕助手] Bilingual rendered & locked. ' + segments.length + ' segments, ' + translatedCount + ' translated. videoId=' + (videoId || 'none'));
    }
  }

  // ============================================================
  // Speech recognition display
  // ============================================================
  function showSpeechResult(text, label, segments, translations) {
    var content = getContentEl();
    if (!content) return;
    unlockContentDOM(); // allow STT result to overwrite locked bilingual content
    if (state) state.completeSTT();
    label = label || '🎤 识别结果';

    if (segments && segments.length > 0) {
      let html = '<div style="margin-bottom:8px;color:var(--tc-accent);font-weight:600;font-size:13px;">' +
                 escapeHtml(label) + '</div>';
      subtitleSegments = [];
      for (let i = 0; i < segments.length; i++) {
        let seg = segments[i];
        if (!seg.text) continue;
        let timeStr = formatSeconds(seg.start) + ' - ' + formatSeconds(seg.end);
        html += '<div class="tc-subtitle-segment" data-idx="' + i + '">';
        html += '<div class="tc-subtitle-time">⏱ ' + timeStr + '</div>';
        html += '<div class="tc-subtitle-text">' + escapeHtml(seg.text) + '</div>';
        if (translations && translations[i]) {
          html += '<div class="tc-subtitle-translation">' + escapeHtml(translations[i]) + '</div>';
        }
        html += '</div>';
        subtitleSegments.push({ time: timeStr, text: seg.text });
      }
      content.innerHTML = html;
    } else {
      let html =
        '<div class="tc-subtitle-segment" data-idx="0" style="border-left:3px solid var(--tc-accent);">' +
        '  <div class="tc-subtitle-time">' + escapeHtml(label) + '</div>' +
        '  <div class="tc-subtitle-text">' + escapeHtml(text) + '</div>';
      if (translations && translations[0]) {
        html += '  <div class="tc-subtitle-translation">' + escapeHtml(translations[0]) + '</div>';
      }
      html += '</div>';
      content.innerHTML = html;
      subtitleSegments = [{ time: label, text: text }];
    }
  }

  function formatSeconds(sec) {
    let m = Math.floor(sec / 60);
    let s = Math.floor(sec % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
  }

  function showSpeechStatus(status) {
    var content = getContentEl();
    if (!content) return;
    unlockContentDOM(); // allow STT loading to overwrite locked content
    if (state) state.startSTT();
    content.innerHTML =
      '<div class="tc-loading">' +
      '  <span class="tc-spinner"></span>' +
      '  <span>' + escapeHtml(status) + '</span>' +
      '</div>';
  }

  /** Clear STT status spinner without changing state — used by stopWhisper. */
  function clearSpeechStatus(msg) {
    var content = getContentEl();
    if (!content) return;
    unlockContentDOM();
    content.innerHTML =
      '<div class="tc-empty"><p>' + escapeHtml(msg || '识别已取消') + '</p></div>';
  }

  // ============================================================
  // Append translations to existing segments (used by pipeline)
  // ============================================================
  function appendTranslations(translations) {
    let content = getContentEl();
    if (!content) return;
    for (let i = 0; i < translations.length; i++) {
      if (!translations[i]) continue;
      let seg = content.querySelector('.tc-subtitle-segment[data-idx="' + i + '"]');
      if (!seg || seg.querySelector('.tc-subtitle-translation')) continue;
      let el = document.createElement('div');
      el.className = 'tc-subtitle-translation';
      el.textContent = translations[i];
      seg.appendChild(el);
    }
  }

  // ============================================================
  // Auto-trigger Whisper STT when built-in subtitles are only
  // in target language (e.g. Chinese-only tracks on English video)
  // ============================================================
  function autoTriggerWhisper(content, targetLang) {
    if (!content) return;
    var langName = LANG_MAP[targetLang] || targetLang;

    // Check if API key is configured before auto-triggering
    chrome.storage.local.get(['groqKey'], function (stored) {
      if (!stored.groqKey) {
        // No API key — show prompt in language bar instead of silent fail
        console.log('[字幕助手] Auto-Whisper skipped: no Groq API Key');
        var langBar = content.querySelector('#tc-lang-bar');
        if (langBar) {
          var statusEl = langBar.querySelector('#tc-lang-status');
          if (statusEl) {
            statusEl.innerHTML = '⚠ 需设置 Groq API Key 才能自动识别原声';
            statusEl.style.color = '#f59e0b';
            statusEl.style.cursor = 'pointer';
            statusEl.title = '点击设置 API Key';
            statusEl.addEventListener('click', function () {
              chrome.runtime.sendMessage({ action: 'openPopup' });
            });
          }
        }
        if (state) state.reset(null);
        return;
      }

      showAutoWhisperStatus('🔎 正在检查平台字幕...');
      requestVideoTranslation({ isAuto: true }).then(function (outcome) {
        if (outcome && outcome.status === 'missing') {
          showAutoWhisperStatus('🔊 正在自动识别原声...');
        }
      }).catch(function (error) {
        console.warn('[字幕助手] Auto subtitle-first failed:', error.message);
        if (state) state.reset(null);
      });
    });
  }

  // ============================================================
  // Auto-Whisper status bar — shows above subtitles without replacing them
  // ============================================================
  function showAutoWhisperStatus(msg) {
    var content = getContentEl();
    if (!content) return;
    // Update the language bar's status indicator if it exists
    var langBar = content.querySelector('#tc-lang-bar');
    if (langBar) {
      var statusEl = langBar.querySelector('#tc-lang-status');
      if (statusEl) {
        statusEl.innerHTML = '<span style="display:inline-block;width:12px;height:12px;' +
          'border:2px solid var(--tc-accent);border-top-color:transparent;' +
          'border-radius:50%;animation:tc-spin 0.8s linear infinite;vertical-align:middle;' +
          'margin-right:4px;"></span>' + escapeHtml(msg);
        statusEl.style.color = 'var(--tc-accent)';
      }
    }
  }

  function hideAutoWhisperStatus() {
    // Update the language bar status back to default
    var content = getContentEl();
    if (content) {
      var statusEl = content.querySelector('#tc-lang-status');
      if (statusEl) {
        statusEl.innerHTML = '⏳ 等待识别结果...';
        statusEl.style.color = 'var(--tc-text-secondary)';
      }
    }
    if (state) state.reset(null); // Allow subtitle updates after auto-Whisper finishes/fails
  }

  // ============================================================
  // Update original text of a segment (used by garbled-text fix)
  // ============================================================
  function updateOriginalText(idx, newText) {
    let content = getContentEl();
    if (!content) return;
    let seg = content.querySelector('.tc-subtitle-segment[data-idx="' + idx + '"]');
    if (!seg) return;
    let textEl = seg.querySelector('.tc-subtitle-text');
    if (textEl) textEl.textContent = newText;
  }

  // ============================================================
  // Copy all subtitles to clipboard
  // ============================================================
  function copySubtitles() {
    if (subtitleSegments.length === 0) {
      alert('没有可复制的字幕');
      return;
    }
    let text = '';
    for (let i = 0; i < subtitleSegments.length; i++) {
      text += subtitleSegments[i].text + '\n';
    }
    navigator.clipboard.writeText(text).then(function () {
      let btn = getPanelEl()?.querySelector('#tc-btn-copy');
      if (btn) {
        let original = btn.textContent;
        btn.textContent = '✅ 已复制';
        setTimeout(function () { btn.textContent = original; }, 1500);
      }
    }).catch(function () {
      alert('复制失败，请手动选择文本复制');
    });
  }


  // ============================================================
  // Helpers
  // ============================================================
  // ============================================================
  // No-subtitle guide — called when pre-buffer accumulates audio
  // ============================================================
  function updateNoSubtitleGuide(durationSec) {
    if (!noSubtitlesVideo) return;
    var content = getContentEl();
    if (!content) return;
    var guide = content.querySelector('#tc-no-subtitle-guide');
    if (!guide) return; // content already replaced by something else
    var sec = Math.round(durationSec || 0);
    guide.innerHTML =
      '<p style="font-size:16px;">🎬 该视频没有内置字幕</p>' +
      '<p style="font-size:15px;color:#22c55e;margin-top:12px;font-weight:600;">' +
      '🔊 已检测到语音' + (sec > 0 ? '（已缓冲 ' + sec + 's）' : '') + '</p>' +
      '<p style="font-size:14px;margin-top:8px;">' +
      '点击顶部 <span style="color:var(--tc-accent);font-weight:600;font-size:15px;">🍪 识别</span> 开始 AI 语音转文字</p>' +
      '<button class="tc-btn" id="tc-btn-fetch-subtitles" style="margin-top:10px;">🔍 尝试获取字幕</button>';
  }

  function escapeHtml(str) {
    let div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function getPanelEl() {
    return panelRoot?.querySelector('.tc-panel');
  }

  function getContentEl() {
    return panelRoot?.querySelector('#tc-content');
  }

  // ============================================================
  // DOM lock — prevents SSR refresh from overwriting bilingual render
  // ============================================================
  function lockContentDOM() {
    var content = getContentEl();
    if (!content) return;
    // Disconnect any previous observer
    if (contentObserver) contentObserver.disconnect();
    // Save the current state
    lockedHTML = content.innerHTML;
    // Watch for ANY external modification to #tc-content
    contentObserver = new MutationObserver(function () {
      if (content.innerHTML !== lockedHTML) {
        console.log('[字幕助手] 🔒 DOM overwrite detected — restoring bilingual render');
        content.innerHTML = lockedHTML;
      }
    });
    contentObserver.observe(content, { childList: true, characterData: true, subtree: true });
    console.log('[字幕助手] 🔒 DOM locked. ' + lockedHTML.length + ' chars protected.');
  }

  function unlockContentDOM() {
    if (contentObserver) {
      contentObserver.disconnect();
      contentObserver = null;
      lockedHTML = '';
      console.log('[字幕助手] 🔓 DOM unlocked');
    }
  }

  // ============================================================
  // Drag & Resize
  // ============================================================
  function initDrag(panel) {
    const header = panel.querySelector('.tc-header');
    let isDragging = false, startX, startY, startLeft, startTop;

    header.addEventListener('mousedown', function (e) {
      if (e.target.closest('button')) return; // don't drag when clicking buttons
      isDragging = true;
      document.body.classList.add('tc-dragging');
      panel.style.transition = 'none';

      const rect = panel.getBoundingClientRect();
      startX = e.clientX;
      startY = e.clientY;
      startLeft = rect.left;
      startTop = rect.top;

      // Switch from right-based to left-based so drag position works
      panel.style.right = 'auto';
      panel.style.left = startLeft + 'px';
      panel.style.top = startTop + 'px';
    });

    document.addEventListener('mousemove', function (e) {
      if (!isDragging) return;
      let newLeft = startLeft + (e.clientX - startX);
      let newTop = startTop + (e.clientY - startY);
      newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - panel.offsetWidth - 8));
      newTop = Math.max(0, Math.min(newTop, window.innerHeight - 60));
      panel.style.left = newLeft + 'px';
      panel.style.top = newTop + 'px';
    });

    document.addEventListener('mouseup', function () {
      if (!isDragging) return;
      isDragging = false;
      document.body.classList.remove('tc-dragging');
      panel.style.transition = '';
    });
  }

  function initResize(panel) {
    const handle = panel.querySelector('.tc-resize-handle');
    let isResizing = false, startX, startY, startW, startH;

    handle.addEventListener('mousedown', function (e) {
      e.preventDefault();
      e.stopPropagation();
      isResizing = true;
      document.body.classList.add('tc-dragging');
      panel.style.transition = 'none';

      startX = e.clientX;
      startY = e.clientY;
      startW = panel.offsetWidth;
      startH = panel.offsetHeight;
    });

    document.addEventListener('mousemove', function (e) {
      if (!isResizing) return;
      let newW = startW + (e.clientX - startX);
      let newH = startH + (e.clientY - startY);
      newW = Math.max(280, Math.min(newW, 600));
      newH = Math.max(200, Math.min(newH, window.innerHeight - 100));
      panel.style.width = newW + 'px';
      panel.style.height = newH + 'px';
      panel.style.maxHeight = 'none';
    });

    document.addEventListener('mouseup', function () {
      if (!isResizing) return;
      isResizing = false;
      document.body.classList.remove('tc-dragging');
      panel.style.transition = '';
    });
  }

  async function startManualTranslation() {
    const panel = getPanelEl();
    if (panel) {
      panel.classList.remove('tc-collapsed');
      panel.classList.remove('tc-closed');
    }
    if (currentTranslationSource) return retranslateCurrentSource();
    return requestVideoTranslation();
  }

  if (typeof chrome === 'object' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
      if (!message || message.action !== 'startVideoTranslation') return;
      if (!panelRoot) {
        sendResponse({ ok: false });
        return;
      }
      startManualTranslation().then(function () {
        sendResponse({ ok: true });
      }).catch(function (error) {
        console.error('[字幕助手] 翻译失败:', error.message);
        sendResponse({ ok: false });
      });
      return true;
    });
  }

  async function retranslateCurrentSource() {
    var saved = currentTranslationSource;
    if (!saved || !panelRoot || !state || state.isLoadingSTT()) return;
    var currentVideoId = state.getVideoId();
    if (saved.videoId && currentVideoId && String(saved.videoId) !== String(currentVideoId)) return;
    if (saved.result.isMediaBindingCurrent && !saved.result.isMediaBindingCurrent()) return;
    unlockContentDOM();
    state.reset(saved.videoId);
    var requestId = state.startSubtitleLoad(saved.videoId);
    var stored = await new Promise(function (resolve) { chrome.storage.local.get(['targetLang'], resolve); });
    if (currentTranslationSource !== saved || requestId !== state.getRenderReqId()) return;
    await renderBilingualResult(saved.result, stored.targetLang || saved.targetLang, requestId, saved.videoId, saved.binding);
  }

  if (typeof chrome === 'object' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local') return;
      var relevant = Object.keys(changes).some(function (key) {
        return /^(translateEngine|targetLang|aiTranslate(Key|Endpoint|Model|Corrections|AllowInsecure))$/.test(key) && changes[key].oldValue !== changes[key].newValue;
      });
      if (!relevant) return;
      translationSettingsRevision++;
      clearTimeout(retranslationTimer);
      retranslationTimer = setTimeout(function () {
        retranslateCurrentSource().catch(function (error) { console.error('[字幕助手] 重新翻译失败:', error.message); });
      }, 75);
    });
  }

  window.__TikTokCaptionHelper = window.__TikTokCaptionHelper || {};
  window.__TikTokCaptionHelper.panel = {
    mount: mount,
    unmount: unmount,
    reset: function (newVideoId) {
      clearTimeout(retranslationTimer);
      currentTranslationSource = null;
      subtitleTask = null;
      automaticFallbackKey = null;
      if (translationAttempt && translationAttempt.wake) translationAttempt.wake();
      translationAttempt = null;
      noSubtitlesVideo = false;
      unlockContentDOM();
      subtitleSegments = [];
      if (state) state.reset(newVideoId || null);
      var content = getContentEl();
      if (content) content.innerHTML = '<div class="tc-empty"></div>';
    },
    renderSubtitles: renderSubtitles,
    requestVideoTranslation: requestVideoTranslation,
    showSpeechResult: showSpeechResult,
    showSpeechStatus: showSpeechStatus,
    appendTranslations: appendTranslations,
    updateOriginalText: updateOriginalText,
    updateNoSubtitleGuide: updateNoSubtitleGuide,
    renderBilingualResult: renderBilingualResult,
    retranslateCurrentSource: retranslateCurrentSource,
    showAutoWhisperStatus: showAutoWhisperStatus,
    hideAutoWhisperStatus: hideAutoWhisperStatus,
    clearSpeechStatus: clearSpeechStatus,
    get isMounted() { return panelRoot !== null; },
  };

  console.log('[字幕助手] Panel UI loaded');
})();
