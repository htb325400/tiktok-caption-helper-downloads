// content/state.js
// ============================================================
// Centralized state manager — single source of truth for
// rendering state, video tracking, and subtitle cache.
// Replaces scattered boolean flags across panel-ui, index,
// and subtitle-fetcher.
// ============================================================

(function () {
  'use strict';

  // ============================================================
  // State machine
  // ============================================================
  // Valid states:
  //   idle                — no active render, no lock
  //   loading_subs        — subtitle fetch + translation in progress
  //   bilingual_rendered  — bilingual result rendered, panel locked
  //   loading_stt         — speech recognition in progress
  //   stt_rendered        — STT result rendered, panel locked
  //
  // Allowed transitions:
  //   idle → loading_subs, loading_stt
  //   loading_subs → bilingual_rendered, idle (error)
  //   bilingual_rendered → idle (reset/new video only)
  //   loading_stt → stt_rendered, idle (cancel/error)
  //   stt_rendered → idle (reset/new video only)
  // ============================================================

  var STATE = {
    IDLE: 'idle',
    LOADING_SUBS: 'loading_subs',
    BILINGUAL_RENDERED: 'bilingual_rendered',
    LOADING_STT: 'loading_stt',
    STT_RENDERED: 'stt_rendered',
  };

  var ALLOWED = {};
  ALLOWED[STATE.IDLE] = [STATE.LOADING_SUBS, STATE.LOADING_STT];
  ALLOWED[STATE.LOADING_SUBS] = [STATE.BILINGUAL_RENDERED, STATE.IDLE];
  ALLOWED[STATE.BILINGUAL_RENDERED] = [STATE.IDLE]; // only via reset()
  ALLOWED[STATE.LOADING_STT] = [STATE.STT_RENDERED, STATE.IDLE];
  ALLOWED[STATE.STT_RENDERED] = [STATE.IDLE]; // only via reset()

  // Internal state
  var _state = STATE.IDLE;
  var _videoId = null;
  var _renderReqId = 0; // kept for backward compat with existing async chains
  var _lastGoodHtml = ''; // cached successful render HTML
  var _lastGoodSegments = []; // cached successful render segments
  var _lastGoodVideoId = null; // videoId of last successful render
  var _lastGoodRenderCacheable = false;
  var _lastGoodBinding = null;
  var _sttOwnership = null;
  var _transcriptIdentity = null;
  var _transcriptRevision = -1;
  var _transcriptSequence = -1;
  // Render cache: surviving HTML snapshot per videoId.
  // Stored separately from _lastGoodHtml so it survives same-video reset().
  var _renderCache = {}; // videoId → { html, segments }

  var CACHE_TTL = 5 * 60 * 1000;
var _subtitleDataCache = {}; // videoId → subtitle track metadata
  var _vttCache = {}; // URL → raw VTT text (prevent re-fetch on URL expiry)
  var _vttCacheByLang = {}; // langBase → raw VTT text (fallback when exact URL is expired)
  var _translationCache = {}; // videoId+lang → translated texts

  // Segment-level cache: videoId → { tracks, selectedTrack, segments, actualLang, sourceLang }
  // Populated after successful fetch+parse. Subsequent events for same videoId
  // skip subtitle-fetcher entirely and use cached segments.
  var _segmentCache = {};

  // ============================================================
  // Transition — validates and applies state change
  // ============================================================
  function transition(newState) {
    var allowed = ALLOWED[_state];
    if (!allowed || allowed.indexOf(newState) === -1) {
      console.warn('[State] Illegal transition: ' + _state + ' → ' + newState + '. Allowed: ' + (allowed || []).join(', '));
      return false;
    }
    var oldState = _state;
    _state = newState;
    console.log('[State] ' + oldState + ' → ' + newState + ' (videoId=' + (_videoId || 'none') + ')');
    return true;
  }

  // ============================================================
  // Public API
  // ============================================================

  /** Begin subtitle loading for a video. Returns new renderReqId. */
  function startSubtitleLoad(videoId) {
    if (_state === STATE.STT_RENDERED && _sttOwnership === 'candidate' &&
        (!videoId || !_videoId || String(videoId) === String(_videoId))) {
      _state = STATE.IDLE;
      console.log('[State] Candidate STT released ownership for platform subtitles');
    }
    if (!transition(STATE.LOADING_SUBS)) return -1;
    _videoId = videoId || _videoId;
    _renderReqId++;
    return _renderReqId;
  }

  /** Subtitle loading succeeded — lock panel, cache result. */
  function completeBilingualRender(videoId, html, segments, binding) {
    if (_state !== STATE.LOADING_SUBS) {
      console.warn('[State] completeBilingualRender called in state ' + _state + ', forcing transition');
    }
    _state = STATE.BILINGUAL_RENDERED;
    if (videoId) {
      _videoId = videoId;
      _lastGoodVideoId = videoId;
    }
    _lastGoodHtml = html || '';
    _lastGoodSegments = segments || [];
    _lastGoodRenderCacheable = true;
    _lastGoodBinding = normalizeCacheBinding(binding);
    _sttOwnership = null;
    console.log('[State] Bilingual render locked. videoId=' + _videoId + ' segments=' + _lastGoodSegments.length);
  }

  /** Subtitle loading failed — release lock for retry. */
  function failSubtitleLoad() {
    if (_state !== STATE.LOADING_SUBS) {
      console.warn('[State] failSubtitleLoad called in state ' + _state);
      return;
    }
    _state = STATE.IDLE;
    console.log('[State] Subtitle load failed, returned to idle');
  }

  /** Begin speech recognition. */
  function startSTT() {
    if (_state === STATE.LOADING_SUBS || _state === STATE.BILINGUAL_RENDERED || _state === STATE.STT_RENDERED) {
      // Allow STT to interrupt subtitle states (user explicitly requested)
      console.log('[State] STT overriding state ' + _state);
    }
    _state = STATE.LOADING_STT;
    // 让所有 in-flight 字幕渲染失效：STT 开始后，旧字幕请求完成时 reqId 已过期，
    // renderBilingualResult 的 stale 检查会丢弃它，避免旧字幕覆盖 STT 结果。
    // （修复：startSTT 之前只改状态不 bump，STT 音频获取窗口期内旧字幕能通过 reqId 检查。）
    _renderReqId++;
    return true;
  }

  /** STT result shown — lock panel. */
  function completeSTT(videoId, html, segments, ownership) {
    if (_state !== STATE.LOADING_STT) {
      console.warn('[State] completeSTT called in state ' + _state + ', forcing');
    }
    _state = STATE.STT_RENDERED;
    if (videoId) {
      _videoId = videoId;
      _lastGoodVideoId = videoId;
    }
    if (html !== undefined) _lastGoodHtml = html || '';
    if (segments !== undefined) _lastGoodSegments = segments || [];
    _lastGoodRenderCacheable = false;
    _sttOwnership = ownership === 'candidate' ? 'candidate' : 'final';
    console.log('[State] STT render locked ownership=' + _sttOwnership);
  }

  /** Reset everything for new video navigation. */
  function reset(newVideoId) {
    _renderReqId++;
    _state = STATE.IDLE;
    var oldVideoId = _lastGoodVideoId;
    var videoChanged = newVideoId && newVideoId !== oldVideoId;
    _videoId = newVideoId || null;
    _transcriptIdentity = null;
    _transcriptRevision = -1;
    _transcriptSequence = -1;
    _sttOwnership = null;

    // Only clear caches when actually switching to a different video.
    // Same-video reset (e.g. SSR refresh) must preserve the cached bilingual HTML.
    if (videoChanged) {
      _vttCacheByLang = {};
      _lastGoodHtml = '';
      _lastGoodSegments = [];
      _lastGoodVideoId = null;
      _lastGoodRenderCacheable = false;
      _lastGoodBinding = null;
      // Clear segment cache for old video
      if (oldVideoId) delete _segmentCache[oldVideoId];
      console.log('[State] Reset → idle (new video). cleared cache for ' + (oldVideoId || 'unknown'));
    } else {
      // Same video or no videoId change — keep render cache intact
      console.log('[State] Reset → idle (same video ' + (_videoId || 'none') + '), cache preserved');
    }
  }

  // ============================================================
  // Getters — read-only, no side effects
  // ============================================================
  function getState() { return _state; }
  function getVideoId() { return _videoId; }
  function getRenderReqId() { return _renderReqId; }
  function getLastGoodHtml() { return _lastGoodHtml; }
  function getLastGoodSegments() { return _lastGoodSegments; }
  function getLastGoodVideoId() { return _lastGoodVideoId; }

  function acceptTranscriptRevision(contract) {
    if (!contract || typeof contract !== 'object') return true;
    var identity = [contract.sessionId, contract.videoId, contract.routeEpoch]
      .map(function (value) { return value == null ? '' : String(value); }).join('|');
    var revision = Number.isInteger(contract.revision) && contract.revision >= 0 ? contract.revision : 0;
    var sequence = Number.isInteger(contract.sequence) && contract.sequence >= 0 ? contract.sequence : -1;
    if (_transcriptIdentity !== identity) {
      _transcriptIdentity = identity;
      _transcriptRevision = revision;
      _transcriptSequence = sequence;
      return true;
    }
    if (revision < _transcriptRevision) return false;
    if (revision === _transcriptRevision && sequence <= _transcriptSequence) return false;
    _transcriptRevision = revision;
    _transcriptSequence = sequence;
    return true;
  }

  function isIdle() { return _state === STATE.IDLE; }
  function isLoadingSubs() { return _state === STATE.LOADING_SUBS; }
  function isBilingualRendered() { return _state === STATE.BILINGUAL_RENDERED; }
  function isLoadingSTT() { return _state === STATE.LOADING_STT; }
  function isSTTRendered() { return _state === STATE.STT_RENDERED; }
  function isLocked() { return _state === STATE.BILINGUAL_RENDERED || _state === STATE.STT_RENDERED; }
  function isProcessing() { return _state === STATE.LOADING_SUBS || _state === STATE.LOADING_STT; }

  /** Can a new subtitle render be started? Only checks state — render cache handles same-videoId dedup. */
  function canStartSubtitle(videoId) {
    return _state === STATE.IDLE ||
      (_state === STATE.STT_RENDERED && _sttOwnership === 'candidate' &&
       (!videoId || !_videoId || String(videoId) === String(_videoId)));
  }

  // ============================================================
  // Caches
  // ============================================================

  /** Store subtitle track metadata for a video. */
  function cacheSubtitleData(videoId, data) {
    if (videoId && data) _subtitleDataCache[videoId] = { v: data, t: Date.now() };
  }

  /** Get cached subtitle track metadata. */
  function getCachedSubtitleData(videoId) {
    var e = _subtitleDataCache[videoId]; if (!e) return null; if (Date.now() - e.t > CACHE_TTL) { delete _subtitleDataCache[videoId]; return null; } return e.v;
  }

  /** Store VTT content by URL AND by language for fallback lookup. */
  function cacheVtt(url, content, lang) {
    if (url && content) _vttCache[url] = { v: content, t: Date.now() };
    if (lang && content) _vttCacheByLang[lang] = { v: content, t: Date.now() };
  }

  /** Get cached VTT content by URL. Returns null on miss. */
  function getCachedVtt(url) {
    var e2 = _vttCache[url]; if (!e2) return null; if (Date.now() - e2.t > CACHE_TTL) { delete _vttCache[url]; return null; } return e2.v;
  }

  /** Get cached VTT content by language code (fallback when URL expired). */
  function getCachedVttByLang(lang) {
    var e3 = _vttCacheByLang[lang]; if (!e3) return null; if (Date.now() - e3.t > CACHE_TTL) { delete _vttCacheByLang[lang]; return null; } return e3.v;
  }

  function translationSourceKey(sourceTexts) {
    if (!Array.isArray(sourceTexts)) return '';
    var text = sourceTexts.map(function (value) { return String(value || ''); }).join('\u001f');
    var hash = 2166136261;
    for (var i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16) + ':' + text.length + ':' + sourceTexts.length;
  }

  function sameTranslationSource(left, right) {
    if (!Array.isArray(left) || !Array.isArray(right) || left.length !== right.length) return false;
    for (var i = 0; i < left.length; i++) {
      if (String(left[i] || '') !== String(right[i] || '')) return false;
    }
    return true;
  }

  function normalizeCacheBinding(binding) {
    if (!binding || typeof binding !== 'object') return null;
    var normalized = {};
    ['videoId', 'mediaKey', 'routeEpoch', 'wrapperId'].forEach(function (key) {
      if (binding[key] !== undefined && binding[key] !== null && binding[key] !== '') {
        normalized[key] = String(binding[key]);
      }
    });
    return Object.keys(normalized).length ? normalized : null;
  }

  function sameCacheBinding(left, right) {
    var leftBinding = normalizeCacheBinding(left);
    var rightBinding = normalizeCacheBinding(right);
    if (!rightBinding) return !leftBinding;
    if (!leftBinding) return false;
    return ['videoId', 'mediaKey', 'routeEpoch', 'wrapperId'].every(function (key) {
      return String(leftBinding[key] || '') === String(rightBinding[key] || '');
    });
  }

  /** Store translation result. Source text is part of the key to prevent stale reuse. */
  function cacheTranslation(videoId, sourceLang, targetLang, texts, sourceTexts, binding) {
    var normalizedBinding = normalizeCacheBinding(binding);
    var baseKey = (videoId || '') + '|' + sourceLang + '→' + targetLang +
      (normalizedBinding ? '|binding=' + JSON.stringify(normalizedBinding) : '');
    var sourceKey = translationSourceKey(sourceTexts);
    var key = baseKey + (sourceKey ? '|src=' + sourceKey : '');
    _translationCache[key] = { v: texts, source: Array.isArray(sourceTexts) ? sourceTexts.slice() : null, binding: normalizedBinding, t: Date.now() };
  }

  /** Get cached translation. Source text is part of the lookup when supplied. */
  function getCachedTranslation(videoId, sourceLang, targetLang, sourceTexts, binding) {
    var normalizedBinding = normalizeCacheBinding(binding);
    var baseKey = (videoId || '') + '|' + sourceLang + '→' + targetLang +
      (normalizedBinding ? '|binding=' + JSON.stringify(normalizedBinding) : '');
    var sourceKey = translationSourceKey(sourceTexts);
    var key = baseKey + (sourceKey ? '|src=' + sourceKey : '');
    var e4 = _translationCache[key];
    if (!e4) return null;
    if (Date.now() - e4.t > CACHE_TTL) { delete _translationCache[key]; return null; }
    if (Array.isArray(sourceTexts) && !sameTranslationSource(e4.source, sourceTexts)) return null;
    if (normalizedBinding && !sameCacheBinding(e4.binding, normalizedBinding)) return null;
    return e4.v;
  }

  /** Cache parsed subtitle result for a videoId. Avoids re-fetch on SSR refresh. */
  function cacheSubtitleResult(videoId, result, binding) {
    if (!videoId || !result) return;
    _segmentCache[videoId] = {
      tracks: result.tracks || null,
      selectedTrack: result.sourceLang || null,
      segments: result.segments || [],
      actualLang: result.actualLang || 'unknown',
      sourceLang: result.sourceLang || 'unknown',
      binding: normalizeCacheBinding(binding),
      cachedAt: Date.now()
    };
    console.log('[State] Segment cache stored for video ' + videoId + ' (' + result.segments.length + ' segs)');
  }

  /** Get cached subtitle result. Returns null on miss or different videoId. */
  function getCachedSubtitleResult(videoId, binding) {
    if (!videoId) return null;
    var entry = _segmentCache[videoId];
    if (!entry) return null;
    if (!sameCacheBinding(entry.binding, binding)) return null;
    // Check cache freshness (5 minutes max — segments don't change for same video)
    if (Date.now() - entry.cachedAt > CACHE_TTL) {
      delete _segmentCache[videoId];
      return null;
    }
    console.log('[State] Segment cache hit for video ' + videoId + ' (' + entry.segments.length + ' segs, ' + entry.actualLang + ')');
    return entry;
  }

  /** Store rendered HTML for a videoId — allows instant restore on SSR refresh. */
  function cacheRenderResult(videoId, html, segments, binding) {
    if (!videoId) return;
    _lastGoodHtml = html || '';
    _lastGoodSegments = segments || [];
    _lastGoodVideoId = videoId;
    _lastGoodRenderCacheable = true;
    _lastGoodBinding = normalizeCacheBinding(binding);
  }

  /** Get cached render result. Returns null if videoId doesn't match. */
  function getCachedRenderResult(videoId, binding) {
    if (!videoId || videoId !== _lastGoodVideoId) return null;
    if (!_lastGoodRenderCacheable) return null;
    if (!_lastGoodHtml) return null;
    if (!sameCacheBinding(_lastGoodBinding, binding)) return null;
    return { html: _lastGoodHtml, segments: _lastGoodSegments };
  }

  /** Return a debug snapshot of current state. */
  function debugSnapshot() {
    return {
      state: _state,
      sttOwnership: _sttOwnership,
      videoId: _videoId,
      renderReqId: _renderReqId,
      lastGoodVideoId: _lastGoodVideoId,
      transcriptIdentity: _transcriptIdentity,
      transcriptRevision: _transcriptRevision,
      transcriptSequence: _transcriptSequence,
      hasGoodHtml: !!_lastGoodHtml,
      segmentsCached: _lastGoodSegments.length,
      subtitleDataCacheKeys: Object.keys(_subtitleDataCache),
      vttCacheSize: Object.keys(_vttCache).length,
      translationCacheSize: Object.keys(_translationCache).length,
    };
  }

  // ============================================================
  // Export
  // ============================================================
  window.__TikTokCaptionHelper = window.__TikTokCaptionHelper || {};
  window.__TikTokCaptionHelper.state = {
    // Transitions
    startSubtitleLoad: startSubtitleLoad,
    completeBilingualRender: completeBilingualRender,
    failSubtitleLoad: failSubtitleLoad,
    startSTT: startSTT,
    completeSTT: completeSTT,
    reset: reset,
    // Getters
    getState: getState,
    getVideoId: getVideoId,
    getRenderReqId: getRenderReqId,
    getLastGoodHtml: getLastGoodHtml,
    getLastGoodSegments: getLastGoodSegments,
    getLastGoodVideoId: getLastGoodVideoId,
    acceptTranscriptRevision: acceptTranscriptRevision,
    // Segment + render cache
    cacheSubtitleResult: cacheSubtitleResult,
    getCachedSubtitleResult: getCachedSubtitleResult,
    cacheRenderResult: cacheRenderResult,
    getCachedRenderResult: getCachedRenderResult,
    isIdle: isIdle,
    isLoadingSubs: isLoadingSubs,
    isBilingualRendered: isBilingualRendered,
    isLoadingSTT: isLoadingSTT,
    isSTTRendered: isSTTRendered,
    isLocked: isLocked,
    isProcessing: isProcessing,
    canStartSubtitle: canStartSubtitle,
    // Caches
    cacheSubtitleData: cacheSubtitleData,
    getCachedSubtitleData: getCachedSubtitleData,
    cacheVtt: cacheVtt,
    getCachedVtt: getCachedVtt,
    getCachedVttByLang: getCachedVttByLang,
    cacheTranslation: cacheTranslation,
    getCachedTranslation: getCachedTranslation,
    // Debug
    debugSnapshot: debugSnapshot,
  };

  console.log('[字幕助手] State manager loaded');
})();
