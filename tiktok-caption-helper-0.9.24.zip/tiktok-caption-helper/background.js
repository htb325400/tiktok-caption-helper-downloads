// background.js — downloads + Groq Whisper + Translation (Service Worker)
// Audio captured via content script (captureStream), sent as base64.
'use strict';

importScripts('utils/url-guard.js');
importScripts('utils/filename-sanitizer.js');
importScripts('utils/rel-path.js');
importScripts('utils/gpt-text-request.js');

// ============================================================
// 传输边界（A1）
// chrome.runtime.sendMessage 单条消息官方硬上限 64MiB。
// dataURL = base64(blob)，膨胀约 1.333x，再加 "data:video/mp4;base64," 前缀
// 与 JSON 序列化开销 —— 都算在同一条消息里。
// 取 24MiB 原始 blob（≈32MiB dataURL），留 2x 余量。
// 页面侧必须在 FileReader 之前用 blob.size 预检，不能等字符串造出来再判。
// ============================================================
var MAX_BLOB_BYTES = 24 * 1024 * 1024;      // 页面侧预检阈值
var MAX_DATAURL_CHARS = 34 * 1024 * 1024;   // SW 侧兜底（32MiB + 余量）

// 待确认落盘的下载：downloadId → {tabId, itemId, batchId, startedAt, filename}
// 必须持久化：MV3 SW 空闲约 30s 被终止，内存映射会丢。
var PENDING_KEY = 'tiktok_pending_downloads';

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  switch (msg.action) {
    case 'downloadDataUrl':
      handleDownloadDataUrl(msg, sender, sendResponse);
      return true;

    case 'queryDownload':
      handleQueryDownload(msg, sendResponse);
      return true;

    case 'getDownloadLimits':
      sendResponse({ maxBlobBytes: MAX_BLOB_BYTES, maxDataUrlChars: MAX_DATAURL_CHARS });
      return false;

    case 'startWhisper':
      if (msg.engine === 'gemini' && msg.geminiKey) {
        handleGeminiTranscribe(msg, sender, sendResponse);
        return true;
      }
      if (msg.audioUrl) {
        handleWhisperUrl(msg.audioUrl, msg.apiKey, msg.model, msg.language)
          .then(sendResponse)
          .catch(function (e) {
            console.error('[BG] URL Whisper failed:', e.message);
            sendResponse({ error: e.message });
          });
      } else {
        handleWhisperData(msg.audioData, msg.apiKey, msg.model, msg.language)
          .then(sendResponse)
          .catch(function (e) {
            console.error('[BG] Whisper failed:', e.message);
            sendResponse({ error: e.message });
          });
      }
      return true;

    case 'translate':
      translateText(msg.text, msg.apiKey, msg.targetLang)
        .then(function (translated) { sendResponse({ translated: translated }); })
        .catch(function (e) { sendResponse({ error: e.message }); });
      return true;

    case 'translateAIText':
      self.GptTextRequest.request(msg, sender).then(sendResponse);
      return true;
  }
});

// ============================================================
// Download dataURL：content script fetch 视频后转 dataURL，SW 落盘。
// chrome.downloads 直下 CDN 会 403（不带页面 cookie），反盗链需页面 cookie 上下文，
// 所以 content script 先 fetch（带 cookie）拿 blob → dataURL → 交给 SW 落盘。
// ============================================================
function handleDownloadDataUrl(msg, sender, sendResponse) {
  var guard = self.__TikTokCaptionHelper && self.__TikTokCaptionHelper.urlGuard;

  // 1. 来源校验：只接受 www.tiktok.com 页面
  var tabUrl = sender && sender.tab && sender.tab.url;
  if (!tabUrl || !/^https:\/\/www\.tiktok\.com\//.test(tabUrl)) {
    console.warn('[BG] 拒绝 dataURL 下载：非法来源', tabUrl || '(无 tab)');
    sendResponse({ status: 'error', error: '拒绝：非 TikTok 页面来源' });
    return;
  }

  // 2. dataURL 校验：只接受 video 类型
  if (typeof msg.dataUrl !== 'string' || !/^data:video\//.test(msg.dataUrl)) {
    console.warn('[BG] 拒绝 dataURL 下载：非法 dataURL 类型');
    sendResponse({ status: 'error', error: '拒绝：非法 dataURL' });
    return;
  }

  // 3. 尺寸上限（A1）——按 64MiB IPC 硬上限反推，不是拍脑袋的 100MB。
  //    注意：走到这里说明超大消息已经过了一次 IPC，页面侧的 blob.size 预检才是主防线。
  if (msg.dataUrl.length > MAX_DATAURL_CHARS) {
    console.warn('[BG] 拒绝 dataURL 下载：超出传输上限',
      (msg.dataUrl.length / 1024 / 1024).toFixed(1) + 'MB >',
      (MAX_DATAURL_CHARS / 1024 / 1024).toFixed(0) + 'MB');
    sendResponse({
      status: 'error',
      error: '视频过大，超出扩展传输上限（约 ' + Math.floor(MAX_BLOB_BYTES / 1024 / 1024) + 'MB）',
      code: 'TOO_LARGE',
    });
    return;
  }

  // 4. sourceUrl 一致性检查（S-1）—— fail-closed，缺失即拒绝。
  //    诚实说明：dataURL 通道 SW 拿不到真实 CDN URL，无法验证字节来源。
  //    这里校验的是页面「声明」的来源 URL 是否在白名单内 —— 是一致性检查，
  //    不是内容真实性证明。但既然它是唯一能做的来源约束，就不允许缺省绕过。
  if (!guard) {
    console.error('[BG] url-guard 未加载');
    sendResponse({ status: 'error', error: 'url-guard 未加载' });
    return;
  }
  if (typeof msg.sourceUrl !== 'string' || !msg.sourceUrl) {
    console.warn('[BG] 拒绝 dataURL 下载：缺少 sourceUrl');
    sendResponse({ status: 'error', error: '拒绝：缺少来源 URL', code: 'MISSING_SOURCE_URL' });
    return;
  }
  if (!guard.isAllowedDownloadUrl(msg.sourceUrl)) {
    console.warn('[BG] 拒绝 dataURL 下载：声明的 sourceUrl 不在白名单', guard.redactUrl(msg.sourceUrl));
    sendResponse({ status: 'error', error: '拒绝：来源 URL 不在白名单', code: 'SOURCE_URL_NOT_ALLOWED' });
    return;
  }

  // 5. filename 净化（不信页面传的值）
  var sanitizer = self.__TikTokCaptionHelper && self.__TikTokCaptionHelper.filenameSanitizer;
  var relPathHelper = self.__TikTokCaptionHelper && self.__TikTokCaptionHelper.relPath;
  var safeName = sanitizer ? sanitizer.sanitizeFilename(msg.filename) : 'tiktok-video.mp4';
  var relPath = relPathHelper
    ? relPathHelper.buildRelativePath(msg.subdir, safeName, sanitizer)
    : 'tiktok/' + safeName;

  // 6. 落盘 —— 只代表「下载已创建」，不代表已写入磁盘（A2）
  chrome.downloads.download(
    { url: msg.dataUrl, filename: relPath, saveAs: false },
    function (downloadId) {
      var err = chrome.runtime.lastError;
      if (err) {
        console.warn('[BG] dataURL 下载创建失败:', err.message);
        sendResponse({ status: 'error', error: err.message });
        return;
      }
      // 登记待确认，等 onChanged 给终态
      registerPending(downloadId, {
        tabId: sender.tab && sender.tab.id,
        itemId: msg.itemId || null,
        batchId: msg.batchId || null,
        nonce: msg.nonce || null,
        filename: relPath,
        startedAt: Date.now(),
      });
      sendResponse({ status: 'started', downloadId: downloadId });
    }
  );
}

// ============================================================
// 下载终态确认（A2）
//
// chrome.downloads.download 的回调只说明「下载已创建」。之后的 403、
// interrupted、磁盘写失败都不会回到那个回调里 —— 旧实现把 downloadId
// 当成功，失败会被静默报成「下载已开始」。
//
// 真相源是 chrome.downloads.onChanged 的 state=complete/interrupted。
// MV3 SW 会被终止，所以：
//   1) 待确认映射持久化到 storage.local
//   2) onChanged 是顶层监听器，事件会唤醒 SW
//   3) SW 冷启动时用 downloads.search 对账，捞回错过的终态
// ============================================================

// 内存是 SW 存活期间的权威来源；storage 只用于冷启动对账。
// 设计要点（Codex 审出的两个竞态）：
//   1) dataURL 下载几乎瞬时完成，onChanged 可能先于 registerPending 的
//      storage.set 落地 → 用「内存先写 + earlyTerminals 早到缓冲」化解：
//      registerPending 第一步就同步写内存，onChanged 总能从内存读到 meta。
//   2) onChanged 与 reconcilePending 可能并发 resolve 同一个 id →
//      finalizePending 用内存里的 `done` 标记做幂等，保证只发一次终态。
var _pending = {};         // downloadId → meta（内存权威来源，SW 存活期间）
var _earlyTerminals = {};  // downloadId → {state, error}（注册前早到的终态）
var _resolved = {};        // downloadId → true（幂等护栏：每个 id 只终态一次）
var RESOLVED_KEY = 'tiktok_resolved_downloads';

function registerPending(downloadId, meta) {
  var key = String(downloadId);
  // 1) 同步写内存 —— 消除「storage 未落地时 onChanged 读不到」的窗口
  _pending[key] = meta;

  // 2) 持久化（冷启动对账用）。读-改-写，失败不阻塞下载（内存仍在）。
  chrome.storage.local.get(PENDING_KEY, function (data) {
    // 防复活：若这个 downloadId 已经 finalize（内存护栏已置位），
    // 说明终态比这次持久化更早发生 —— 绝不能再把旧 meta 写回 storage，
    // 否则会把已经删除的 pending 复活，导致冷启动重复终态。
    if (_resolved[key]) return;
    var map = data[PENDING_KEY] || {};
    map[key] = meta;
    chrome.storage.local.set({ [PENDING_KEY]: map }, function () {
      // 写后补偿：写入期间终态若已发生（_resolved 置位），立刻把刚写回的
      // 残留 pending 再删掉。check 与 set 之间的窗口由此闭合，不留瞬态脏数据。
      if (_resolved[key]) {
        chrome.storage.local.get(PENDING_KEY, function (d2) {
          var m2 = d2[PENDING_KEY] || {};
          if (m2[key]) {
            delete m2[key];
            chrome.storage.local.set({ [PENDING_KEY]: m2 });
          }
        });
        return;
      }
      // 3) 若 onChanged 早到且被缓冲，此时消费它
      var early = _earlyTerminals[key];
      if (early) {
        delete _earlyTerminals[key];
        finalizePending(downloadId, early.state, early.error);
      }
    });
  });
}

function resolvePending(downloadId, state, error) {
  var key = String(downloadId);
  // 已终态过（内存护栏）—— 不再处理
  if (_resolved[key]) return;

  // 快路径：内存里有（正常情形）
  if (_pending[key]) {
    finalizePending(downloadId, state, error);
    return;
  }

  // 慢路径：内存没有（冷启动 reconcile 尚未装载，或 storage 未落地）
  // 先把终态缓冲起来，同时查 storage 确认是否真是我们的下载、是否已 resolved。
  _earlyTerminals[key] = { state: state, error: error };
  chrome.storage.local.get([PENDING_KEY, RESOLVED_KEY], function (data) {
    var map = data[PENDING_KEY] || {};
    var resolved = data[RESOLVED_KEY] || {};
    // 已终态过（内存护栏或 storage 标记）—— 不再处理，并清理缓冲
    if (_resolved[key] || resolved[key]) { delete _earlyTerminals[key]; return; }
    if (!map[key]) { delete _earlyTerminals[key]; return; } // 不是我们的下载：清理缓冲，不留泄漏
    var meta = map[key];
    _pending[key] = meta;
    delete map[key];
    chrome.storage.local.set({ [PENDING_KEY]: map });
    var early = _earlyTerminals[key];
    delete _earlyTerminals[key];
    finalizePending(downloadId, early ? early.state : state, early ? early.error : error);
  });
}

// 幂等终态：每个 downloadId 只发一次 downloadTerminal。
// 内存护栏 _resolved 挡住 SW 存活期内的重复；跨 SW 重启的重复由
// storage 的 RESOLVED_KEY 挡住（reconcilePending 会跳过已 resolved 的 id）。
function finalizePending(downloadId, state, error) {
  var key = String(downloadId);
  var meta = _pending[key];
  if (!meta) return;
  if (_resolved[key]) return;

  _resolved[key] = true;
  delete _pending[key];

  // 持久化「已终态」标记 + 从 pending 移除。两笔写合并到一次 set。
  chrome.storage.local.get([PENDING_KEY, RESOLVED_KEY], function (data) {
    var map = data[PENDING_KEY] || {};
    var resolved = data[RESOLVED_KEY] || {};
    if (map[key]) delete map[key];
    resolved[key] = true;
    chrome.storage.local.set({ [PENDING_KEY]: map, [RESOLVED_KEY]: resolved });
  });

  chrome.downloads.search({ id: downloadId }, function (items) {
    var it = (items && items[0]) || {};
    var payload = {
      action: 'downloadTerminal',
      downloadId: downloadId,
      nonce: meta.nonce || null,
      state: state,
      error: error || it.error || null,
      bytes: it.fileSize || it.bytesReceived || 0,
      itemId: meta.itemId,
      batchId: meta.batchId,
    };
    console.log('[BG] 下载终态:', downloadId, state, payload.error || '', (payload.bytes / 1024).toFixed(0) + 'KB');
    if (meta.tabId != null) {
      chrome.tabs.sendMessage(meta.tabId, payload, function () {
        void chrome.runtime.lastError; // 标签已关 / 页面已卸载 —— 正常
      });
    }
  });
}

chrome.downloads.onChanged.addListener(function (delta) {
  if (!delta || !delta.state || !delta.state.current) return;
  var cur = delta.state.current;
  if (cur !== 'complete' && cur !== 'interrupted') return;
  resolvePending(delta.id, cur, delta.error && delta.error.current);
});

/** SW 冷启动对账：把 storage 里的 pending 重新装进内存，再查真实终态。 */
function reconcilePending() {
  chrome.storage.local.get([PENDING_KEY, RESOLVED_KEY], function (data) {
    var map = data[PENDING_KEY] || {};
    var resolved = data[RESOLVED_KEY] || {};
    var ids = Object.keys(map);
    if (!ids.length) return;
    console.log('[BG] 对账待确认下载:', ids.length, '条');
    for (var i = 0; i < ids.length; i++) {
      (function (id) {
        var key = id;
        // 已 resolved：只清理残留的 pending，保留 resolved 标记作为幂等护栏。
        // 注意不能删 resolved —— 否则「pending 因读改写竞态被复活」时，
        // 下一次 reconcile 会失去护栏而重复终态。resolved 标记随下次
        // 终态清理由 finalize 的写回自然覆盖（id 不复用，可安全清理）。
        if (resolved[key]) {
          if (map[key]) {
            delete map[key];
            chrome.storage.local.set({ [PENDING_KEY]: map });
          }
          return;
        }
        var meta = map[key];
        _pending[key] = meta; // 装载进内存，使 onChanged 能找到
        chrome.downloads.search({ id: Number(id) }, function (items) {
          var it = items && items[0];
          if (!it) { finalizePending(Number(id), 'interrupted', 'DOWNLOAD_RECORD_GONE'); return; }
          if (it.state === 'complete' || it.state === 'interrupted') {
            finalizePending(Number(id), it.state, it.error);
          }
          // in_progress：留在内存，等 onChanged
        });
      })(ids[i]);
    }
  });
}

chrome.runtime.onStartup.addListener(reconcilePending);
chrome.runtime.onInstalled.addListener(reconcilePending);
reconcilePending(); // SW 每次唤醒也对一次账（空映射时立即返回）

/** 页面侧兜底轮询：终态消息丢了（标签重载等）时主动问一次。 */
function handleQueryDownload(msg, sendResponse) {
  var id = Number(msg.downloadId);
  if (!id) { sendResponse({ status: 'error', error: '无效 downloadId' }); return; }
  chrome.downloads.search({ id: id }, function (items) {
    var it = items && items[0];
    if (!it) { sendResponse({ status: 'unknown' }); return; }
    sendResponse({
      status: it.state,                                   // in_progress | complete | interrupted
      error: it.error || null,
      bytes: it.fileSize || it.bytesReceived || 0,
    });
  });
}

// ============================================================
// Whisper: base64 audio from <video> captureStream
// ============================================================
// Gemini 转写（G2）：fetch audioUrl → base64 → 调 Gemini generateContent。
// 用于中英混合识别（Gemini 多模态对 code-switching 远准于 whisper）。
// 走 SW 的浏览器网络栈（自动走系统代理），x-goog-api-key header 不放 URL。
// ============================================================
var GEMINI_MODEL_DEFAULT = 'gemini-3.6-flash';
var GEMINI_MAX_BLOB = 14 * 1024 * 1024; // blob 14MB → base64 ~18.6MB，留 20MB 余量
// Gemini 是 LLM 多模态推理，处理音频慢（74s 音频实测可能 >15s），超时给足 60s。
// 之前 15s 太短，导致 Gemini 频繁「超时」回退 Groq。
var GEMINI_TIMEOUT_MS = 60000;
var geminiServiceCooldown = null;

function geminiCooldownDuration(error) {
  var message = String(error && error.message || '').toLowerCase();
  if (error && error.status !== undefined && error.status !== null) {
    if (error.status === 429) return 60000;
    if (error.status === 400 && /location is not supported/.test(message)) return 300000;
    return 0;
  }
  return 0;
}

function geminiCooldownReason(error) {
  var duration = geminiCooldownDuration(error);
  if (!duration) return '';
  return duration >= 300000 ? 'Gemini 地区不可用，已暂时跳过' : 'Gemini 配额/限流，已暂时跳过';
}

function shouldBypassGemini(msg, model) {
  if (!geminiServiceCooldown) return false;
  if (geminiServiceCooldown.key !== msg.geminiKey || geminiServiceCooldown.model !== model) {
    geminiServiceCooldown = null;
    return false;
  }
  if (Date.now() >= geminiServiceCooldown.until) {
    geminiServiceCooldown = null;
    return false;
  }
  return !!msg.groqKey;
}

function rememberGeminiCooldown(error, msg, model) {
  var duration = geminiCooldownDuration(error);
  if (!duration) return;
  geminiServiceCooldown = { key: msg.geminiKey, model: model, until: Date.now() + duration, reason: geminiCooldownReason(error) };
}

// Gemini 失败时回退 Groq（若 whisper-stt 带了 groqKey）。
// 用同一 audioUrl 调 handleWhisperUrl，返回带时间戳的 Groq 结果。
async function fallbackToGroq(msg, sendResponse, reason) {
  if (!msg.groqKey) {
    sendResponse({ error: reason + '（且未配置 Groq key，无法回退）' });
    return;
  }
  console.log('[BG] Gemini 失败，回退 Groq:', reason);
  try {
    var r = msg.audioData
      ? await handleWhisperData(msg.audioData, msg.groqKey, msg.model, msg.language)
      : await handleWhisperUrl(msg.audioUrl, msg.groqKey, msg.model, msg.language);
    // 把 Gemini 失败原因带回 content script，让页面 console 能直接看到诊断
    r.geminiFallbackReason = reason;
    sendResponse(r);
  } catch (e) {
    sendResponse({ error: e.message });
  }
}

async function handleGeminiTranscribe(msg, sender, sendResponse) {
  var guard = self.__TikTokCaptionHelper && self.__TikTokCaptionHelper.urlGuard;

  // 1. 来源校验（防任意 URL 代理，Codex P1）
  var tabUrl = sender && sender.tab && sender.tab.url;
  if (!tabUrl || !/^https:\/\/www\.tiktok\.com\//.test(tabUrl)) {
    sendResponse({ error: '拒绝：非 TikTok 页面来源' });
    return;
  }

  var hasAudioData = typeof msg.audioData === 'string' && /^data:audio\/[a-z0-9.+-]+;base64,[a-z0-9+/]*={0,2}$/i.test(msg.audioData);
  var hasVideoData = typeof msg.audioData === 'string' && /^data:video\/[a-z0-9.+-]+;base64,[a-z0-9+/]*={0,2}$/i.test(msg.audioData);
  if (msg.audioData && (!hasAudioData && !hasVideoData || msg.audioData.length > MAX_DATAURL_CHARS)) {
    sendResponse({ error: '拒绝：媒体数据非法或超出传输上限' });
    return;
  }
  if (!hasAudioData && !hasVideoData && (!guard || !guard.isAllowedAudioUrl(msg.audioUrl))) {
    console.warn('[BG] 拒绝 Gemini 转写：audioUrl 不在音频白名单', guard ? guard.redactUrl(msg.audioUrl) : '(无 guard)');
    sendResponse({ error: '拒绝：音频 URL 不在白名单' });
    return;
  }

  var model = msg.geminiModel || GEMINI_MODEL_DEFAULT;
  if (shouldBypassGemini(msg, model)) {
    await fallbackToGroq(msg, sendResponse, 'Gemini 冷却中（' + geminiServiceCooldown.reason + '）');
    return;
  }

  // 3. 下载音频 → blob
  var blob;
  var dlCtrl = new AbortController();
  var dlTimer = setTimeout(function () { dlCtrl.abort(); }, GEMINI_TIMEOUT_MS);
  try {
    if (hasAudioData || hasVideoData) {
      var dataResp = await fetch(msg.audioData, { signal: dlCtrl.signal });
      blob = await dataResp.blob();
    } else {
      var audioResp = await fetch(msg.audioUrl, { signal: dlCtrl.signal });
      if (!audioResp.ok) throw new Error('音频 HTTP ' + audioResp.status);
      blob = await audioResp.blob();
    }
  } catch (e) {
    console.error('[BG] Gemini 音频下载失败:', e.name === 'AbortError' ? '超时' : e.message);
    sendResponse({ error: '音频下载失败: ' + (e.name === 'AbortError' ? '超时' : e.message) });
    return;
  } finally {
    clearTimeout(dlTimer);
  }

  // 4. 尺寸边界：base64 后 + prompt 须 < 20MB（Gemini inline 限制）
  if (!blob || blob.size === 0) { sendResponse({ error: '音频为空' }); return; }
  if (blob.size > GEMINI_MAX_BLOB) {
    console.warn('[BG] Gemini 音频过大:', (blob.size / 1024 / 1024).toFixed(1) + 'MB');
    await fallbackToGroq(msg, sendResponse, '音频过大超出 Gemini 限制');
    return;
  }

  // 5. base64（MIME 用 blob.type 标准值，空则兜底 audio/mpeg）
  var mime = (blob.type && blob.type.indexOf('/') > 0) ? blob.type : 'audio/mpeg';
  var base64 = await blobToBase64(blob);

  var prompt = '请完整转写这段音频里的语音，逐句输出。注意：说话人可能是中国人讲英语、中间夹杂中文，请如实区分英文和中文，不要强行统一成一种语言。每句单独一行，只输出转写文本，不要加序号、Markdown 标记或解释。';
  var requestedLanguage = typeof msg.language === 'string' ? msg.language.trim() : '';
  if (requestedLanguage && requestedLanguage !== 'auto' && /^[a-z]{2,3}(?:-(?:[A-Z]{2}|[A-Z][a-z]{3}))?$/.test(requestedLanguage)) {
    prompt += '识别语言提示：' + requestedLanguage + '。此提示不是目标翻译语言；以实际听到的语音为准，保留混合语言原文，不要翻译。';
  }

  // 6. 调 Gemini（x-goog-api-key header，不放 URL）
  var controller = new AbortController();
  var timer = setTimeout(function () { controller.abort(); }, GEMINI_TIMEOUT_MS);
  var result;
  try {
    var geminiResp = await fetch(
      'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': msg.geminiKey,
        },
        body: JSON.stringify({
          contents: [{
            parts: [
              { inline_data: { mime_type: mime, data: base64 } },
              { text: prompt },
            ],
          }],
        }),
        signal: controller.signal,
      }
    );
    if (!geminiResp.ok) {
      var errTxt = '';
      try { errTxt = await geminiResp.text(); } catch (_) {}
      var httpError = new Error('Gemini HTTP ' + geminiResp.status + ': ' + errTxt.slice(0, 200));
      httpError.status = geminiResp.status;
      throw httpError;
    }
    result = await geminiResp.json();
  } catch (e) {
    rememberGeminiCooldown(e, msg, model);
    var cooldownReason = geminiCooldownReason(e);
    console.error('[BG] Gemini 转写失败:', e.name === 'AbortError' ? '超时' : e.message);
    await fallbackToGroq(msg, sendResponse, 'Gemini 转写失败(' + (e.name === 'AbortError' ? '超时' : e.message) + ')' + (cooldownReason ? '；' + cooldownReason : ''));
    return;
  } finally {
    clearTimeout(timer);
  }

  // 7. 解析逐句文本
  var rawText = '';
  try { rawText = result.candidates[0].content.parts[0].text || ''; } catch (e) {}
  if (!rawText) { await fallbackToGroq(msg, sendResponse, 'Gemini 返回空文本'); return; }

  var lines = parseGeminiLines(rawText);
  if (!lines.length) { await fallbackToGroq(msg, sendResponse, 'Gemini 输出无法解析'); return; }

  var segments = lines.map(function (line) { return { text: line, time: '' }; });
  sendResponse({ text: lines.join('\n'), language: 'auto', segments: segments, source: 'gemini', inputSource: msg.audioData ? 'data' : 'url', model: model, provider: 'gemini' });
}

function blobToBase64(blob) {
  return new Promise(function (resolve, reject) {
    var fr = new FileReader();
    fr.onload = function () { resolve(fr.result.split(',')[1] || ''); }; // 去 data: 前缀
    fr.onerror = function () { reject(new Error('FileReader 失败')); };
    fr.readAsDataURL(blob);
  });
}

// 解析 Gemini 输出：去 Markdown 围栏、去编号前缀、过滤空行、无换行时标点切分。
function parseGeminiLines(rawText) {
  var t = String(rawText).trim();
  // 去 Markdown 代码围栏
  t = t.replace(/^```[a-zA-Z]*\s*/m, '').replace(/```\s*$/m, '').trim();
  var lines = t.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
  // 去编号/项目符号前缀（"1. " / "- " / "1、" 等）
  lines = lines.map(function (s) { return s.replace(/^(\d+[\.、\)]|\-|\*|\•)\s*/, '').trim(); }).filter(Boolean);
  if (!lines.length) return [];
  // 若只有 1 行且很长，按标点有限切分
  if (lines.length === 1 && lines[0].length > 80) {
    lines = lines[0].split(/(?<=[。！？.!?])\s*/).map(function (s) { return s.trim(); }).filter(Boolean);
  }
  return lines;
}

// ============================================================
// F5：从 dataURL 的 MIME 前缀推导音频文件名，避免把视频 mp4 硬标成 webm。
// dataURL 形如 'data:video/mp4;base64,...' 或 'data:audio/webm;base64,...'。
function deriveAudioFilename(dataUrl) {
  var ext = 'webm';
  var m = typeof dataUrl === 'string' ? dataUrl.match(/^data:([^;,]+)/) : null;
  if (m && m[1]) {
    var mime = m[1].toLowerCase();
    // 修 P2：mpeg/mp3/mpga 应归 mp3，m4a 应归 m4a，只有 mp4 归 mp4。
    if (/mp4/.test(mime)) ext = 'mp4';
    else if (/m4a/.test(mime)) ext = 'm4a';
    else if (/mp3|mpeg|mpga/.test(mime)) ext = 'mp3';
    else if (/wav|wave/.test(mime)) ext = 'wav';
    else if (/ogg|opus/.test(mime)) ext = 'ogg';
    else if (/webm/.test(mime)) ext = 'webm';
    else if (/flac/.test(mime)) ext = 'flac';
  }
  return 'audio.' + ext;
}

function normalizeWhisperSegment(segment) {
  var normalized = { start: segment.start, end: segment.end, text: (segment.text || '').trim() };
  ['temperature', 'avg_logprob', 'compression_ratio', 'no_speech_prob'].forEach(function (field) {
    if (typeof segment[field] === 'number' && Number.isFinite(segment[field])) {
      normalized[field] = segment[field];
    }
  });
  return normalized;
}

async function handleWhisperData(dataUrl, apiKey, model, language) {
  console.log('[BG] Decoding captured audio...');
  let resp = await fetch(dataUrl);
  let blob = await resp.blob();
  console.log('[BG] Capture size:', (blob.size / 1024).toFixed(0), 'KB');

  if (blob.size > 25 * 1024 * 1024) throw new Error('文件过大(' + (blob.size / 1024 / 1024).toFixed(1) + 'MB)，超过25MB限制');

  model = model || 'whisper-large-v3-turbo';
  let formData = new FormData();
  // F5：文件名按 dataURL 的真实 MIME 推导，而不是硬编码 audio.webm。
  // PATH S 会传视频 mp4（含视频轨），Groq 后端 ffmpeg 自动抽音频；
  // 旧录制路径仍是 audio.webm。硬编码 webm 会误导 Groq 把 mp4 当 webm 解析。
  formData.append('file', blob, deriveAudioFilename(dataUrl));
  formData.append('model', model);
  formData.append('response_format', 'verbose_json');
  // 用户可在 popup 指定源语言，避免自动检测误判（音乐/伴奏干扰大）
  if (language && language !== 'auto') formData.append('language', language);

  console.log('[BG] Model:', model, '| Calling Groq...');
  let result = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + apiKey },
    body: formData,
  });

  if (!result.ok) {
    let errText = '';
    try { errText = await result.text(); } catch (_) {}
    if (result.status === 401) throw new Error('Groq API Key 无效。\n\n请重新设置: 点击扩展图标 → 粘贴新 Key → 保存。');
    if (result.status === 429) throw new Error('请求过于频繁，请稍后重试。');
    throw new Error('Groq API ' + result.status + ': ' + errText.slice(0, 200));
  }

  let data = await result.json();
  // L3：记录请求语言 vs Groq 返回语言，供语言复检 A/B 验证（收集假设 H 证据）
  console.log('[BG] Done:', data.language, '| 请求语言:', (language || 'auto'), '|', (data.text || '').slice(0, 100));

  if (!data.text) throw new Error('未识别到语音内容。');

  let segments = [];
  if (data.segments) {
    for (let i = 0; i < data.segments.length; i++) {
      let s = data.segments[i];
      segments.push(normalizeWhisperSegment(s));
    }
  }
  return { text: data.text, language: data.language || 'auto', segments: segments, duration: data.duration || 0, source: 'capture', inputSource: 'data', model: model, provider: 'groq' };
}

// ============================================================
// Whisper: direct URL download (parallel Range requests for speed)
// TikTok CDN throttles single-connection downloads to ~playback speed.
// Parallel Range requests (4 chunks) bypass this, giving 3-5x speedup.
// ============================================================
async function handleWhisperUrl(url, apiKey, model, language) {
  var PARALLEL_CHUNKS = 4;
  var DOWNLOAD_TIMEOUT = 25000;
  var MIN_SIZE_FOR_PARALLEL = 1024 * 1024; // 1MB

  console.log('[BG] URL:', url.slice(0, 80) + '...');

  // ── Probe with HEAD to determine download strategy ──
  var contentLength = 0;
  var supportsRange = false;
  try {
    var probeController = new AbortController();
    var probeTimer = setTimeout(function () { probeController.abort(); }, 5000);
    var headResp = await fetch(url, { method: 'HEAD', signal: probeController.signal });
    clearTimeout(probeTimer);
    var cl = headResp.headers.get('Content-Length');
    var ar = headResp.headers.get('Accept-Ranges');
    if (cl) contentLength = parseInt(cl, 10);
    if (ar && ar.indexOf('bytes') !== -1) supportsRange = true;
  } catch (_) {
    // HEAD probe failed — CDN might not support HEAD. Fall through to single download.
    console.log('[BG] HEAD probe failed, will use single download');
  }

  console.log('[BG] Size:', contentLength ? (contentLength / 1024).toFixed(0) + 'KB' : 'unknown',
    '| Range:', supportsRange ? 'yes' : 'no',
    '| Strategy:', (supportsRange && contentLength > MIN_SIZE_FOR_PARALLEL) ? 'parallel(' + PARALLEL_CHUNKS + ')' : 'single');

  // ── Download ──
  var blob;
  var downloadStart = Date.now();

  if (supportsRange && contentLength > MIN_SIZE_FOR_PARALLEL) {
    // === Parallel download ===
    var chunkSize = Math.ceil(contentLength / PARALLEL_CHUNKS);
    var chunks = new Array(PARALLEL_CHUNKS);
    var parallelFailed = false;

    try {
      var downloadPromises = [];
      for (var ci = 0; ci < PARALLEL_CHUNKS; ci++) {
        (function (idx) {
          var start = idx * chunkSize;
          var end = (idx === PARALLEL_CHUNKS - 1) ? (contentLength - 1) : (start + chunkSize - 1);
          if (start >= contentLength) { chunks[idx] = new Uint8Array(0); return; }

          var chunkCtrl = new AbortController();
          var chunkTimer = setTimeout(function () { chunkCtrl.abort(); }, DOWNLOAD_TIMEOUT);
          downloadPromises.push(
            fetch(url, {
              headers: { 'Range': 'bytes=' + start + '-' + end },
              signal: chunkCtrl.signal,
            }).then(function (r) {
              clearTimeout(chunkTimer);
              if (!r.ok) throw new Error('Chunk ' + idx + ' HTTP ' + r.status);
              return r.arrayBuffer();
            }).then(function (buf) {
              if (buf.byteLength === 0) throw new Error('Chunk ' + idx + ' returned empty');
              // A：分片完整性校验。CDN 若「声称支持 Range 但实现错误」
              // （返回完整 body 或截断），重装出的音频会被污染 → Whisper 拿损坏音频。
              // 校验实际字节数 == 请求的 end-start+1，不符则整片丢弃走单路兜底。
              var expectedLen = end - start + 1;
              if (buf.byteLength !== expectedLen) {
                throw new Error('Chunk ' + idx + ' size mismatch: got ' + buf.byteLength + ' expected ' + expectedLen);
              }
              chunks[idx] = new Uint8Array(buf);
            })
          );
        })(ci);
      }

      await Promise.all(downloadPromises);

      // Reassemble
      var totalLen = 0;
      for (var ri = 0; ri < chunks.length; ri++) {
        if (chunks[ri]) totalLen += chunks[ri].length;
      }
      if (totalLen === 0) throw new Error('All chunks empty');

      var merged = new Uint8Array(totalLen);
      var offset = 0;
      for (var ri2 = 0; ri2 < chunks.length; ri2++) {
        if (chunks[ri2]) {
          merged.set(chunks[ri2], offset);
          offset += chunks[ri2].length;
        }
      }
      blob = new Blob([merged]);

      var elapsed = ((Date.now() - downloadStart) / 1000).toFixed(1);
      console.log('[BG] Parallel done:', (blob.size / 1024).toFixed(0), 'KB in', elapsed + 's');
    } catch (e) {
      parallelFailed = true;
      console.warn('[BG] Parallel download failed (' + e.message + '), falling back to single download');
    }
  }

  if (!blob || (supportsRange && contentLength > MIN_SIZE_FOR_PARALLEL && parallelFailed)) {
    // === Single download (fallback or no Range support) ===
    try {
      var resp = await fetch(url, { signal: AbortSignal.timeout(DOWNLOAD_TIMEOUT) });
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      blob = await resp.blob();
      var elapsed2 = ((Date.now() - downloadStart) / 1000).toFixed(1);
      console.log('[BG] Single done:', (blob.size / 1024).toFixed(0), 'KB in', elapsed2 + 's');
    } catch (e) {
      if (e.name === 'TimeoutError' || e.name === 'AbortError') {
        throw new Error('下载超时，URL 可能已过期，将使用录制方式重试。');
      }
      throw e;
    }
  }

  if (blob.size > 25 * 1024 * 1024) throw new Error('文件过大(' + (blob.size / 1024 / 1024).toFixed(1) + 'MB)');

  // ── Groq Whisper ──
  model = model || 'whisper-large-v3-turbo';
  var formData = new FormData();
  formData.append('file', blob, 'audio.mp4');
  formData.append('model', model);
  formData.append('response_format', 'verbose_json');
  if (language && language !== 'auto') formData.append('language', language);

  var groqStart = Date.now();
  console.log('[BG] Model:', model, '| Calling Groq...');
  var result = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + apiKey },
    body: formData,
  });

  if (!result.ok) {
    var errText = '';
    try { errText = await result.text(); } catch (_) {}
    if (result.status === 401) throw new Error('Groq API Key 无效。');
    if (result.status === 429) throw new Error('请求过于频繁，请稍后重试。');
    throw new Error('Groq API ' + result.status + ': ' + errText.slice(0, 200));
  }

  var data = await result.json();
  var groqElapsed = ((Date.now() - groqStart) / 1000).toFixed(1);
  var totalElapsed = ((Date.now() - downloadStart) / 1000).toFixed(1);
  console.log('[BG] Done:', data.language, '| 请求语言:', (language || 'auto'), '|', (data.text || '').slice(0, 100),
    '| Groq:', groqElapsed + 's', '| Total:', totalElapsed + 's');

  if (!data.text) throw new Error('未识别到语音内容。');

  var segments = [];
  if (data.segments) {
    for (var i = 0; i < data.segments.length; i++) {
      var s = data.segments[i];
      segments.push(normalizeWhisperSegment(s));
    }
  }
  return { text: data.text, language: data.language || 'auto', segments: segments, duration: data.duration || 0, source: 'url', inputSource: 'url', model: model, provider: 'groq' };
}

// ============================================================
// Translation: Google Translate (free, no rate limit)
// ============================================================
async function translateText(text, apiKey, targetLang) {
  let lines = Array.isArray(text) ? text : [text];
  let langCode = targetLang || 'zh';
  console.log('[BG] Google Translate → ' + langCode + ' ' + lines.length + ' segments:', (lines[0] || '').slice(0, 40) + '...');

  let results = [];
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i];
    if (!line || !line.trim()) { results.push(''); continue; }
    try {
      let url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=' + langCode + '&dt=t&q=' + encodeURIComponent(line);
      let resp = await fetch(url);
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      let data = await resp.json();
      let translated = '';
      if (data && data[0]) {
        for (let j = 0; j < data[0].length; j++) {
          if (data[0][j] && data[0][j][0]) translated += data[0][j][0];
        }
      }
      results.push(translated || line);
    } catch (e) {
      console.warn('[BG] Translate failed for line', i, ':', e.message);
      results.push(line); // fallback to original
    }
  }
  console.log('[BG] Translated:', results.length + ' segments');
  return Array.isArray(text) ? results : (results[0] || lines[0]);
}
