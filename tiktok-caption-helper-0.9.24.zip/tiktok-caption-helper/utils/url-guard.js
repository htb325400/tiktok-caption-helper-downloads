// utils/url-guard.js
// ============================================================
// URL 白名单守卫 — 下载/CDN URL 校验，防任意 URL 代理 + 域名绕过
//
// UMD-lite：node 可 require 单测；浏览器/SW 挂 window.__TikTokCaptionHelper.urlGuard
//
// 三类合法 kind（域名体系两套，实测 2026-08-24）：
//   audio-cdn      音频 CDN（STT 用）  v*.tiktokcdn.com / -us / -eu / tiktokv.com
//   video-cdn      视频 CDN（下载用）  v*.us.tiktok.com
//   play-redirect  落盘首选重定向     www.tiktok.com/aweme/v1/play/
//
// 防绕过关键：host 必须以 v数字 开头（evil-xxx.us.tiktok.com 被拒），
// 而不是简单 endsWith 后缀匹配。
// ============================================================

(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.__TikTokCaptionHelper = root.__TikTokCaptionHelper || {};
    root.__TikTokCaptionHelper.urlGuard = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // ── 主机名正则 ──
  // v 开头 + 数字 + 可选字母（如 v16m）+ 可选 -label（如 -webapp-prime）
  var CDN_HOST_PREFIX = /^v\d[a-z0-9]*(?:-[a-z0-9]+)*\./i;

  // 音频 CDN：tiktokcdn.com / tiktokcdn-us.com / tiktokcdn-eu.com / tiktokv.com
  // 实测真实样例：v16m.tiktokcdn-us.com（注意是 -us 不是裸 .com）
  var AUDIO_CDN_HOST_RE = /^v\d[a-z0-9]*(?:-[a-z0-9]+)*\.(?:tiktokcdn|tiktokcdn-us|tiktokcdn-eu|tiktokv)\.com$/i;

  // 视频 CDN：区域 us host 与 webapp-prime global host。
  var VIDEO_CDN_HOST_RE = /^(?:v\d[a-z0-9]*(?:-[a-z0-9]+)*\.us\.tiktok\.com|v\d+-webapp-prime\.tiktok\.com)$/i;

  // play 重定向路径
  var PLAY_REDIRECT_HOST = 'www.tiktok.com';
  var PLAY_REDIRECT_PATH = '/aweme/v1/play/';

  /**
   * 解析并分类 URL。
   * @param {*} value
   * @returns {{host: string, kind: string, url: URL}|null}
   *   kind: 'audio-cdn' | 'video-cdn' | 'play-redirect'
   */
  function classifyUrl(value) {
    if (typeof value !== 'string') return null;
    var u;
    try { u = new URL(value); } catch (e) { return null; }

    // 只允许 https
    if (u.protocol !== 'https:') return null;
    // 拒绝用户名/密码、非默认端口
    if (u.username || u.password) return null;
    if (u.port && u.port !== '443') return null;

    var host = u.hostname.toLowerCase().replace(/\.$/, '');

    // ── 已知边界（A7，如实记录，不夸大）──
    // 这里只校验 scheme + host + 端口 + 基本 path 形状，**不校验 MIME /
    // 内容**，也不校验 video-cdn 的具体 path 语义（TikTok CDN path 不透明）。
    // 所以这是一个「域名白名单」，不是「内容白名单」。上游若拿这个结果
    // 当作「字节可信」的证明，是误用 —— 内容真实性只能靠后续的
    // Content-Type / body 特征检测，不是这里。
    var path = u.pathname || '';

    if (AUDIO_CDN_HOST_RE.test(host)) {
      return { host: host, kind: 'audio-cdn', url: u };
    }
    if (VIDEO_CDN_HOST_RE.test(host)) {
      if (/^v\d+-webapp-prime\.tiktok\.com$/i.test(host) && !/^\/video\/tos\/.+/.test(path)) return null;
      // 视频 CDN 至少要有一条非空路径（真实 URL 形如 /video/tos/...）
      if (!path || path === '/') return null;
      return { host: host, kind: 'video-cdn', url: u };
    }
    if (host === PLAY_REDIRECT_HOST && u.pathname === PLAY_REDIRECT_PATH) {
      return { host: host, kind: 'play-redirect', url: u };
    }
    return null;
  }

  /**
   * 是否允许作为「视频下载」URL —— 只接受 video-cdn 或 play-redirect。
   * 音频 CDN 不能被当成视频下载源。
   * @param {*} value
   * @returns {boolean}
   */
  function isAllowedDownloadUrl(value) {
    var c = classifyUrl(value);
    return !!c && (c.kind === 'video-cdn' || c.kind === 'play-redirect');
  }

  /**
   * 是否允许作为「音频 CDN」URL（STT 提取用）。
   * @param {*} value
   * @returns {boolean}
   */
  function isAllowedAudioUrl(value) {
    var c = classifyUrl(value);
    return !!c && c.kind === 'audio-cdn';
  }

  /**
   * 是否允许作为「视频原声轨」URL（STT 用，content script 带 cookie fetch 能过反盗链）。
   * 与 isAllowedAudioUrl 的区别：这里接受 video-cdn（v*.us.tiktok.com）和
   * play-redirect（www.tiktok.com/aweme/v1/play/），因为这两类需要页面 cookie，
   * 只有 content script 的 fetch(credentials:'include') 能拿到。
   * 注意：不改 isAllowedAudioUrl 的语义，避免影响其它调用方。
   * @param {*} value
   * @returns {boolean}
   */
  function isAllowedSpeechUrl(value) {
    var c = classifyUrl(value);
    return !!c && (c.kind === 'video-cdn' || c.kind === 'play-redirect');
  }

  /**
   * 脱敏 URL 用于日志：去掉 query（签名/过期参数），只留 host + path 前 60 字符。
   * @param {*} value
   * @returns {string}
   */
  function redactUrl(value) {
    if (typeof value !== 'string') return '';
    try {
      var u = new URL(value);
      return (u.host + u.pathname).slice(0, 60);
    } catch (e) {
      return String(value).slice(0, 60);
    }
  }

  return {
    classifyUrl: classifyUrl,
    isAllowedDownloadUrl: isAllowedDownloadUrl,
    isAllowedAudioUrl: isAllowedAudioUrl,
    isAllowedSpeechUrl: isAllowedSpeechUrl,
    redactUrl: redactUrl,
    AUDIO_CDN_HOST_RE: AUDIO_CDN_HOST_RE,
    VIDEO_CDN_HOST_RE: VIDEO_CDN_HOST_RE,
  };
});
