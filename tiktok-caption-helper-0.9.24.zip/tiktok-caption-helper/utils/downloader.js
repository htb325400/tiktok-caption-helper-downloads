// utils/downloader.js
// ============================================================
// TikTok Video Downloader — 无水印下载
//
// 数据源：详情页 SSR 的 video.bitrateInfo[]（最高清无水印档位）。
// 选档位走 format-selector 模块；不复用 STT 的 currentVideoUrl（那是音频 URL）。
// 无水印失败时不静默回退 video.src（带水印），需用户显式确认。
// ============================================================

(function () {
  'use strict';

  /**
   * 从详情页 SSR 读 video.bitrateInfo（无水印档位）。
   * 路径同 main-world.js：__DEFAULT_SCOPE__['webapp.video-detail'].itemInfo.itemStruct.video
   * @returns {Array|null}
   */
  function extractBitrateInfo() {
    try {
      const el = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
      if (!el || !el.textContent) return null;
      const json = JSON.parse(el.textContent);
      const data = json.__DEFAULT_SCOPE__ || json;
      let item = data && (data.aweme_detail || (data.itemInfo && data.itemInfo.itemStruct));
      if (!item) {
        const vd = data && (data['webapp.video-detail'] || data['webapp.videoDetail']);
        if (vd) item = vd.itemInfo && vd.itemInfo.itemStruct;
      }
      if (!item || !item.video) return null;
      return item.video.bitrateInfo || item.video.bitRateInfo || null;
    } catch (e) { return null; }
  }

  /**
   * <video> 元素 src（兜底，可能带水印）。
   * @returns {string|null}
   */
  function findVideoUrl() {
    const video = document.querySelector('video');
    if (!video) return null;
    if (video.src && video.src.startsWith('http')) return video.src;
    return null;
  }

  function getVideoId() {
    const match = window.location.pathname.match(/\/video\/(\d+)/);
    return match ? match[1] : null;
  }

  function getVideoTitle() {
    const descEl = document.querySelector('[data-e2e="video-desc"], [data-e2e="browse-video-desc"]');
    if (descEl && descEl.textContent) {
      return descEl.textContent.trim().slice(0, 50).replace(/[\\/:*?"<>|]/g, '');
    }
    return getVideoId() || 'tiktok-video';
  }

  // ============================================================
  // 传输边界（A1）—— 与 background.js 保持一致，启动后向 SW 拉一次真值
  // ============================================================
  var MAX_BLOB_BYTES = 24 * 1024 * 1024;
  var TERMINAL_TIMEOUT_MS = 90000;
  var TERMINAL_POLL_MS = 3000;

  try {
    chrome.runtime.sendMessage({ action: 'getDownloadLimits' }, function (r) {
      if (chrome.runtime.lastError || !r || !r.maxBlobBytes) return;
      MAX_BLOB_BYTES = r.maxBlobBytes;
    });
  } catch (e) { /* SW 未就绪，用默认值 */ }

  // fetch 视频 → blob（content script 有页面 cookie，能绕过 CDN 反盗链）
  // 返回结构化结果，不再用 null 抹掉失败原因。
  async function fetchVideoBlob(url) {
    var r;
    try {
      r = await fetch(url, { credentials: 'include', redirect: 'follow' });
    } catch (e) {
      return { ok: false, code: 'NETWORK', error: e.message };
    }
    if (!r.ok) {
      return { ok: false, code: 'HTTP_' + r.status, error: 'HTTP ' + r.status };
    }
    // 200 但不是视频：风控挑战页 / 错误 JSON
    var ct = (r.headers.get('Content-Type') || '').toLowerCase();
    if (ct && ct.indexOf('video') === -1 && ct.indexOf('octet-stream') === -1) {
      return { ok: false, code: 'BAD_CONTENT', error: '响应不是视频 (' + ct.slice(0, 40) + ')' };
    }
    var blob;
    try {
      blob = await r.blob();
    } catch (e) {
      return { ok: false, code: 'NETWORK', error: e.message };
    }
    if (!blob || blob.size === 0) {
      return { ok: false, code: 'EMPTY_BODY', error: '响应体为空' };
    }
    // 即使 Content-Type 谎称 video，也可能是风控挑战页 / 错误 JSON。
    // 看响应体前几个字节，识别 HTML / JSON 特征（P2-10）。
    var head = '';
    try {
      head = (await blob.slice(0, 512).text()).trim().toLowerCase();
    } catch (e) { /* 读不出来就放过，靠 Content-Type 兜底 */ }
    if (head && (head.indexOf('<html') === 0 || head.indexOf('<!doctype') === 0 || head.indexOf('{') === 0 || head.indexOf('[') === 0)) {
      return { ok: false, code: 'CHALLENGE', error: '响应体不是视频（疑似风控/错误页）' };
    }
    return { ok: true, blob: blob };
  }

  function blobToDataUrl(blob) {
    return new Promise(function (resolve, reject) {
      const fr = new FileReader();
      fr.onload = function () { resolve(fr.result); };
      fr.onerror = function () { reject(new Error('FileReader 失败')); };
      fr.readAsDataURL(blob);
    });
  }

  // ============================================================
  // 下载终态等待（A2）
  // downloadId 只代表「下载已创建」。真正的成败要等 SW 转发的
  // chrome.downloads.onChanged 终态。消息可能丢（SW 被杀 + 标签重载），
  // 所以并行做一路兜底轮询。
  // ============================================================
  // 终态关联键：页面生成 nonce，随 downloadDataUrl 传给 SW，SW 在
  // downloadTerminal 里回传。这样 waiter 能在「downloadId 还没拿到」的
  // 消息发送之前就注册好，从根上消除「终态早于 resolver 就位」的竞态。
  var _pendingTerminals = {};   // nonce → finish(res)

  try {
    chrome.runtime.onMessage.addListener(function (msg) {
      if (!msg || msg.action !== 'downloadTerminal') return;
      var fn = msg.nonce ? _pendingTerminals[String(msg.nonce)] : null;
      if (fn) fn(msg);
    });
  } catch (e) { /* 非扩展环境 */ }

  // 提前创建 waiter（在 sendMessage 之前）。downloadId 在回调里才知道，
  // 所以主关联用 nonce；downloadId 只用于兜底轮询（拿到后 setDownloadId）。
  function createTerminalWaiter(nonce) {
    var key = String(nonce);
    var downloadId = null;
    var settled = false;
    var poll, timer;

    var promise = new Promise(function (resolve) {
      function finish(res) {
        if (settled) return;
        settled = true;
        delete _pendingTerminals[key];
        clearInterval(poll);
        clearTimeout(timer);
        resolve(res);
      }

      function queryOnce() {
        if (downloadId == null) return; // downloadId 还没拿到，跳过
        chrome.runtime.sendMessage({ action: 'queryDownload', downloadId: downloadId }, function (r) {
          if (chrome.runtime.lastError || !r) return;
          if (r.status === 'complete' || r.status === 'interrupted') {
            finish({ state: r.status, error: r.error, bytes: r.bytes });
          } else if (r.status === 'unknown') {
            finish({ state: 'interrupted', error: 'DOWNLOAD_RECORD_GONE' });
          }
        });
      }

      _pendingTerminals[key] = function (msg) {
        finish({ state: msg.state, error: msg.error, bytes: msg.bytes });
      };

      poll = setInterval(queryOnce, TERMINAL_POLL_MS);

      timer = setTimeout(function () {
        finish({ state: 'timeout', error: 'NO_TERMINAL_STATE' });
      }, TERMINAL_TIMEOUT_MS);
    });

    return {
      promise: promise,
      setDownloadId: function (id) {
        downloadId = id;
        // 拿到 id 立即补一次查询，捕获「终态已发生但消息还没被消费」的情形
        // —— 但这里轮询的 queryOnce 在 interval 里，补一次直接查询更稳
        if (downloadId != null) {
          chrome.runtime.sendMessage({ action: 'queryDownload', downloadId: downloadId }, function (r) {
            if (chrome.runtime.lastError || !r) return;
            if (r.status === 'complete' || r.status === 'interrupted') {
              if (_pendingTerminals[key]) _pendingTerminals[key]({ state: r.status, error: r.error, bytes: r.bytes });
            }
          });
        }
      },
      // 消息发送失败时手动终止，避免留 90s 空等待
      resolve: function (res) {
        if (_pendingTerminals[key]) _pendingTerminals[key](res);
      },
    };
  }

  /**
   * 下载链路：尺寸预检 → fetch（带 cookie 绕反盗链）→ blob → dataURL → SW 落盘 → 等终态
   * @returns {Promise<{ok:boolean, code?:string, error?:string, bytes?:number, downloadId?:number}>}
   */
  async function downloadVideo(url, filename, opts) {
    opts = opts || {};

    const fetched = await fetchVideoBlob(url);
    if (!fetched.ok) {
      console.error('[字幕助手] fetch 视频失败:', fetched.code, fetched.error);
      return { ok: false, code: fetched.code, error: fetched.error };
    }
    const blob = fetched.blob;

    // A1：必须在 FileReader 之前判，否则先造出一个几十 MB 的字符串再拒绝
    if (blob.size > MAX_BLOB_BYTES) {
      return {
        ok: false,
        code: 'TOO_LARGE',
        error: '视频 ' + (blob.size / 1024 / 1024).toFixed(1) + 'MB，超出传输上限 '
          + Math.floor(MAX_BLOB_BYTES / 1024 / 1024) + 'MB',
        bytes: blob.size,
      };
    }

    let dataUrl;
    try {
      dataUrl = await blobToDataUrl(blob);
    } catch (e) {
      return { ok: false, code: 'ENCODE', error: e.message };
    }

    // waiter 先于 sendMessage 创建，保证终态消息不会在 resolver 就位前到达
    const nonce = 'dl_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
    const waiter = createTerminalWaiter(nonce);

    const started = await new Promise(function (resolve) {
      chrome.runtime.sendMessage({
        action: 'downloadDataUrl',
        dataUrl: dataUrl,
        filename: filename + '.mp4',
        sourceUrl: url,
        subdir: opts.subdir || null,
        itemId: opts.itemId || null,
        batchId: opts.batchId || null,
        nonce: nonce,
      }, function (response) {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, code: 'SINK_ERROR', error: chrome.runtime.lastError.message });
        } else if (!response || response.status === 'error') {
          resolve({ ok: false, code: (response && response.code) || 'SINK_REJECTED', error: (response && response.error) || '未知错误' });
        } else {
          resolve({ ok: true, downloadId: response.downloadId });
        }
      });
    });

    dataUrl = null; // 允许 GC（不是立即释放）

    if (!started.ok) {
      console.error('[字幕助手] 落盘请求被拒:', started.code, started.error);
      waiter.resolve({ state: 'error', error: started.error });
      return started;
    }

    waiter.setDownloadId(started.downloadId);

    // 等真正写盘（A2）—— 不再拿到 downloadId 就报成功
    const terminal = await waiter.promise;
    if (terminal.state === 'complete') {
      console.log('[字幕助手] ✅ 下载完成:', (terminal.bytes / 1024).toFixed(0) + 'KB');
      return { ok: true, downloadId: started.downloadId, bytes: terminal.bytes };
    }
    console.error('[字幕助手] ❌ 下载未完成:', terminal.state, terminal.error || '');
    return {
      ok: false,
      code: terminal.state === 'timeout' ? 'NO_TERMINAL_STATE' : 'SINK_INTERRUPTED',
      error: terminal.error || terminal.state,
      downloadId: started.downloadId,
    };
  }

  /**
   * 主入口：只从 bitrateInfo 取无水印地址；失败时显式确认才回退 video.src（带水印）。
   * @returns {{ok:boolean, source?:string, url?:string, kind?:string, code?:string, message?:string}}
   */
  // 拿当前 bitrateInfo：优先 API 拦截的实时数据（SPA 导航后 SSR 会 stale），fallback 到 SSR
  function getCurrentBitrateInfo() {
    const helper = window.__TikTokCaptionHelper;
    const cachedBi = helper && helper.apiInterceptor ? helper.apiInterceptor.currentBitrateInfo : null;
    return cachedBi || extractBitrateInfo();
  }

  // 从 SSR 读带水印的 downloadAddr（字符串，仅 SSR 有，API 拦截没存）
  function extractDownloadAddr() {
    try {
      const el = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
      if (!el || !el.textContent) return null;
      const json = JSON.parse(el.textContent);
      const data = json.__DEFAULT_SCOPE__ || json;
      let item = data && (data.aweme_detail || (data.itemInfo && data.itemInfo.itemStruct));
      if (!item) {
        const vd = data && (data['webapp.video-detail'] || data['webapp.videoDetail']);
        if (vd) item = vd.itemInfo && vd.itemInfo.itemStruct;
      }
      if (!item || !item.video) return null;
      const dl = item.video.downloadAddr;
      return (typeof dl === 'string' && dl) ? dl : null;
    } catch (e) { return null; }
  }

  // 列出所有可用档位（无水印档位 + 带水印 downloadAddr）
  function listFormats() {
    const helper = window.__TikTokCaptionHelper;
    const fs = helper && helper.formatSelector;
    const guard = helper && helper.urlGuard;
    if (!fs) return [];
    const formats = fs.listFormats(getCurrentBitrateInfo(), guard);
    // 追加带水印的 downloadAddr（决策 4：带水印需显式提示，不静默回退）
    const dlAddr = extractDownloadAddr();
    if (dlAddr && (!guard || guard.isAllowedDownloadUrl(dlAddr))) {
      formats.push({
        url: dlAddr,
        kind: 'video-cdn',
        width: 0,
        height: 0,
        bitrate: 0,
        codecType: '',
        gearName: 'download-addr',
        dataSize: 0,
        watermarked: true,
      });
    }
    return formats;
  }

  // 下载指定档位
  async function downloadFormat(format, opts) {
    if (!format || !format.url) return { ok: false, code: 'BAD_FORMAT', error: '无效档位' };
    const guard = window.__TikTokCaptionHelper && window.__TikTokCaptionHelper.urlGuard;
    if (guard && !guard.isAllowedDownloadUrl(format.url)) {
      return { ok: false, code: 'BAD_URL', error: 'URL 不在白名单' };
    }
    console.log('[字幕助手] Download format:', format.gearName, '(' + format.kind + ')');
    return await downloadVideo(format.url, getVideoTitle(), opts);
  }

  // 这些失败「换档位也救不了」，立即停止（不继续探测下一个档位）：
  //   - CHALLENGE / HTTP_429：风控，继续换档 = 连续探测，放大风险
  //   - SINK_ERROR / SINK_REJECTED / ENCODE / BAD_URL：不是 URL 的问题
  // 其余（HTTP_403/404、NETWORK、EMPTY_BODY、TOO_LARGE）都可能是「这个档位
  // 的 URL/表示」问题，允许换下一个档位。
  // 注意 TOO_LARGE 允许继续：大档位超 24MiB，不代表低清晰度档位也超。
  const STOP_CODES = {
    CHALLENGE: 1, HTTP_429: 1,
    SINK_ERROR: 1, SINK_REJECTED: 1, ENCODE: 1, BAD_URL: 1, NO_TERMINAL_STATE: 1,
  };

  /**
   * 主入口：下载最高清晰度档位；首选失败时按档位顺序重试（最多 3 档）。
   * 全部失败后才提示带水印回退，且需用户显式确认。
   *
   * 注意：这是 async —— 调用方要 await 才能知道真实结果。
   * 旧版同步返回 {ok:true} 是假成功（A2）。
   *
   * @param {(s:{phase:string,detail?:string})=>void} [onProgress]
   * @returns {Promise<{ok:boolean, source?:string, kind?:string, code?:string, message?:string, bytes?:number}>}
   */
  async function triggerDownload(onProgress) {
    const notify = typeof onProgress === 'function' ? onProgress : function () {};

    // 1) bitrateInfo 档位，按清晰度降序依次尝试
    const formats = listFormats().filter(function (f) { return f && f.url && !f.watermarked; });
    const attempts = Math.min(formats.length, 3);
    let last = null;

    for (let i = 0; i < attempts; i++) {
      notify({ phase: 'downloading', detail: formats[i].gearName || ('档位' + (i + 1)) });
      last = await downloadFormat(formats[i]);
      if (last.ok) {
        return { ok: true, source: 'bitrateInfo', kind: formats[i].kind, bytes: last.bytes };
      }
      console.warn('[字幕助手] 档位 ' + (formats[i].gearName || i) + ' 失败:', last.code, last.error);
      if (STOP_CODES[last.code]) break; // 风控/非 URL 问题，别再探测
    }

    // 2) 无水印全失败 → 带水印回退需显式确认（决策 4，不静默回退）
    const fallback = findVideoUrl();
    if (fallback) {
      const reason = last ? ('（' + (last.error || last.code) + '）') : '';
      const confirmed = confirm('无水印地址下载失败' + reason + '。\n是否尝试当前播放地址？可能带水印。');
      if (confirmed) {
        notify({ phase: 'downloading', detail: '带水印回退' });
        const r = await downloadVideo(fallback, getVideoTitle());
        return r.ok
          ? { ok: true, source: 'video-src', watermark: true, bytes: r.bytes }
          : { ok: false, code: r.code, message: r.error };
      }
      return { ok: false, code: 'USER_CANCELLED', message: '已取消：未使用带水印地址' };
    }

    // 3) 结构化失败
    if (last) return { ok: false, code: last.code, message: last.error };
    return { ok: false, code: 'NO_WATERMARK_FREE_URL', message: '未找到视频地址，请确保 TikTok 视频正在播放' };
  }

  // ============================================================
  // Public API
  // ============================================================
  window.__TikTokCaptionHelper = window.__TikTokCaptionHelper || {};
  window.__TikTokCaptionHelper.downloader = {
    triggerDownload,
    listFormats,
    downloadFormat,
    getCurrentBitrateInfo,
    findVideoUrl,
    getVideoId,
    getVideoTitle,
    extractBitrateInfo,
  };

  console.log('[字幕助手] Downloader loaded');
})();
