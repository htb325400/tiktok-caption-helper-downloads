// utils/rel-path.js
// ============================================================
// 下载落盘相对路径拼装 —— 子目录必须「分段」净化，不能整串丢进
// sanitizeFilename（它会把 '/' 换成 '_'，目录结构会被吃掉）。
//
// UMD-lite：node 可 require 单测；SW 通过 importScripts 挂 self。
// ============================================================

(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.__TikTokCaptionHelper = root.__TikTokCaptionHelper || {};
    root.__TikTokCaptionHelper.relPath = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /**
   * 拼出安全的相对路径。
   *
   * 契约：
   *   - subdir 是**相对目录**，不含前导/尾随 '/'；空 → 回退 'tiktok'
   *   - 分段用 '/' 拆；每段过滤空串、'.'、'..'；绝对路径/盘符段直接丢弃
   *   - 每段再过 sanitizeFilename（去控制字符/保留字符/Windows 保留名）
   *   - 段数上限 maxSeg（默认 2），超出截断（宁可少，不可越）
   *   - safeName 若未净化，也会补一次 sanitizeFilename
   *
   * @param {string|null|undefined} subdir
   * @param {string} safeName
   * @param {object|null} sanitizer  提供 sanitizeFilename；缺省用弱替换
   * @param {object} [opts] { maxSeg }
   * @returns {string}
   */
  function buildRelativePath(subdir, safeName, sanitizer, opts) {
    var maxSeg = (opts && opts.maxSeg) || 2;
    var san = function (s) {
      if (sanitizer && typeof sanitizer.sanitizeFilename === 'function') {
        return sanitizer.sanitizeFilename(s);
      }
      return String(s).replace(/[^\w.-]/g, '_');
    };

    var name = san(safeName || '');
    if (!name) name = 'tiktok-video.mp4';

    var out = [];
    if (subdir && typeof subdir === 'string') {
      var segs = subdir.split('/');
      for (var i = 0; i < segs.length && out.length < maxSeg; i++) {
        var s = segs[i];
        // 空段、'.'、'..'、绝对路径锚点、盘符 —— 全丢
        if (!s || s === '.' || s === '..') continue;
        if (/^[a-zA-Z]:$/.test(s)) continue;               // 'C:' 盘符
        if (s.charAt(0) === '\\' || s.charAt(0) === '/') continue;
        var clean = san(s);
        if (clean && clean !== '.' && clean !== '..' && clean !== '') out.push(clean);
      }
    }

    var dir = out.join('/');
    return (dir ? dir : 'tiktok') + '/' + name;
  }

  return { buildRelativePath: buildRelativePath };
});
