(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.MediaEvidence = factory();
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function clone(value) {
    if (value === undefined) return undefined;
    return JSON.parse(JSON.stringify(value));
  }

  function sanitizeUrl(value) {
    if (typeof value !== 'string' || !value) return null;
    try {
      const parsed = new URL(value);
      if (!['http:', 'https:', 'blob:'].includes(parsed.protocol)) return null;
      return parsed.protocol === 'blob:'
        ? `blob:${parsed.origin}`
        : `${parsed.origin}${parsed.pathname || '/'}`.slice(0, 512);
    } catch (_) {
      return value.split('?')[0].slice(0, 512);
    }
  }

  function fingerprint(value) {
    let hash = 2166136261;
    const text = String(value);
    for (let index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return `mk_${(hash >>> 0).toString(16).padStart(8, '0')}`;
  }

  function sanitizeBinding(binding) {
    if (!binding || typeof binding !== 'object') return null;
    const rawMediaKey = typeof binding.mediaKey === 'string' ? binding.mediaKey : '';
    return {
      videoId: binding.videoId || null,
      wrapperId: binding.wrapperId || null,
      sessionId: binding.sessionId || null,
      mediaSrc: sanitizeUrl(binding.mediaSrc),
      mediaKey: rawMediaKey ? fingerprint(rawMediaKey.split(/[?#]/)[0]) : null,
      sourceRoute: binding.sourceRoute || 'unknown',
      ownership: binding.ownership || 'unverified',
      audioRole: binding.audioRole || 'unknown',
      evidenceStatus: binding.evidenceStatus || 'unknown'
    };
  }

  function sanitizeCandidate(candidate) {
    if (!candidate || typeof candidate !== 'object') return null;
    return {
      binding: sanitizeBinding(candidate.binding),
      textState: candidate.textState || 'partial',
      contentClass: candidate.contentClass || 'unknown',
      segments: Array.isArray(candidate.segments) ? candidate.segments.map(segment => ({
        start: Number.isFinite(segment.start) ? segment.start : null,
        end: Number.isFinite(segment.end) ? segment.end : null,
        text: typeof segment.text === 'string' ? segment.text.slice(0, 4000) : '',
        role: segment.role || 'unknown',
        translate: segment.translate === true,
        warning: typeof segment.warning === 'string' ? segment.warning.slice(0, 500) : null
      })) : [],
      model: candidate.model || null,
      language: candidate.language || null,
      timing: candidate.timing ? clone(candidate.timing) : {}
    };
  }

  function createEvidenceStore(options) {
    options = options || {};
    const maxSamples = Number.isInteger(options.maxSamples) && options.maxSamples > 0
      ? options.maxSamples : 50;
    const now = typeof options.now === 'function' ? options.now : Date.now;
    const samples = [];

    function record(input) {
      const value = clone(input || {});
      value.recordedAt = now();
      if (value.candidate) value.candidate = sanitizeCandidate(value.candidate);
      samples.push(value);
      while (samples.length > maxSamples) samples.shift();
      return clone(value);
    }

    return {
      record,
      clear: () => { samples.length = 0; },
      snapshot: () => clone(samples)
    };
  }

  return { createEvidenceStore, sanitizeCandidate };
}));
