(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else {
    root.__TikTokCaptionHelper = root.__TikTokCaptionHelper || {};
    root.__TikTokCaptionHelper.sentenceGroups = factory();
  }
})(typeof self === 'object' ? self : globalThis, function () {
  'use strict';

  function clean(value) { return String(value || '').replace(/\s+/g, ' ').trim(); }
  function endsSentence(text) { return /[.!?。！？…](?:["'”’)]*)$/.test(clean(text)); }
  function startsNewSentence(text) { return /^[A-Z][a-z]/.test(clean(text)); }
  function times(segment) {
    if (Number.isFinite(segment.start) && Number.isFinite(segment.end)) return [segment.start, segment.end];
    var match = String(segment.time || '').match(/^(\d+):(\d+(?:\.\d+)?)\s*-\s*(\d+):(\d+(?:\.\d+)?)$/);
    return match ? [Number(match[1]) * 60 + Number(match[2]), Number(match[3]) * 60 + Number(match[4])] : null;
  }
  function closeInTime(previous, current) {
    var previousTimes = times(previous);
    var currentTimes = times(current);
    return previousTimes && currentTimes && currentTimes[0] >= previousTimes[0] && currentTimes[0] - previousTimes[1] <= 2.5;
  }
  function speakerChanged(previous, current) {
    return previous.speaker != null && current.speaker != null && String(previous.speaker) !== String(current.speaker);
  }

  function group(segments, indices) {
    var groups = [];
    var current = null;
    var maxParts = 4;
    (indices || segments.map(function (_, index) { return index; })).forEach(function (index) {
      var segment = segments[index] || {};
      var text = clean(segment.text);
      if (!text) return;
      var previous = current && segments[current.indices[current.indices.length - 1]];
      var canJoin = current && index === current.indices[current.indices.length - 1] + 1 && current.indices.length < maxParts && current.text.length + text.length < 500 &&
        !endsSentence(previous.text) && closeInTime(previous, segment) && !speakerChanged(previous, segment) &&
        !startsNewSentence(text);
      if (!canJoin) {
        current = { indices: [index], text: text };
        groups.push(current);
      } else {
        current.indices.push(index);
        current.text += ' ' + text;
      }
    });
    return groups;
  }

  return { group: group };
});
