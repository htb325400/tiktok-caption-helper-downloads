// content/translate-google.js
// ============================================================
// Google 翻译模块 — 调 Google Translate REST API。
// 输入: { texts: string[], from?: string, to: string }
// 输出: string[]（和 texts 一一对应）
// ============================================================
(function () {
  'use strict';

  /**
   * 翻译文本数组
   * @param {string[]} texts
   * @param {string} targetLang - ISO 639-1 码，如 'zh', 'en', 'fr'
   * @param {string} [sourceLang] - 源语言，不传则 auto
   * @returns {Promise<string[]>}
   */
  async function translate(texts, targetLang, sourceLang, options) {
    if (!texts || !texts.length) return [];
    sourceLang = sourceLang || 'auto';
    targetLang = targetLang || 'zh';
    options = options && typeof options === 'object' ? options : {};
    console.log('[Translate] ' + texts.length + ' segments: ' + sourceLang + '→' + targetLang);

    const results = new Array(texts.length).fill('');
    let nextIndex = 0;
    async function worker() {
      while (nextIndex < texts.length) {
        const index = nextIndex++;
        const line = texts[index];
        if (!line || !line.trim()) continue;
        const controller = new AbortController();
        const timer = setTimeout(function () { controller.abort(); }, 10000);
        try {
          const params = new URLSearchParams({ client: 'gtx', sl: sourceLang, tl: targetLang, dt: 't', q: line });
          const url = 'https://translate.googleapis.com/translate_a/single?' + params;
          let resp;
          for (let attempt = 0; attempt < 2; attempt++) {
            resp = await fetch(url, { signal: controller.signal });
            if (resp.ok || attempt === 1 || ![500, 502, 503, 504].includes(resp.status) || controller.signal.aborted) break;
            if (resp.body && typeof resp.body.cancel === 'function') {
              try { await resp.body.cancel(); } catch (_) {}
            }
          }
          if (!resp.ok) throw new Error('HTTP ' + resp.status);
          const data = await resp.json();
          let translated = '';
          if (data && data[0]) {
            for (const part of data[0]) {
              if (part && part[0]) translated += part[0];
            }
          }
          if (translated) {
            results[index] = translated;
            console.log('[Translate] result[' + index + '] input="' + line.slice(0, 160) + '" output="' + translated.slice(0, 160) + '"');
            if (typeof options.onProgress === 'function') {
              try { options.onProgress(index, translated); } catch (callbackError) {
                console.warn('[Translate] Progress callback failed for line ' + index + ':', callbackError?.message);
              }
            }
          } else {
            console.warn('[Translate] Empty result for line ' + index + ': "' + line.slice(0, 40) + '". URL=' + url.slice(0, 120));
          }
        } catch (error) {
          console.warn('[Translate] Failed for line ' + index + ':', error.message);
        } finally {
          clearTimeout(timer);
        }
      }
    }
    await Promise.all(Array.from({ length: Math.min(4, texts.length) }, worker));
    return results;
  }

  // Public API
  window.__TikTokCaptionHelper = window.__TikTokCaptionHelper || {};
  window.__TikTokCaptionHelper.googleTranslate = { translate: translate };
  console.log('[字幕助手] Google Translate loaded');
})();
