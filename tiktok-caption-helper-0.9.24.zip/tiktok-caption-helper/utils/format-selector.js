// utils/format-selector.js
// ============================================================
// 从 video.bitrateInfo[] 选最高清晰度档位（无水印下载）。
//
// UMD-lite：node 可 require 单测；浏览器挂 window.__TikTokCaptionHelper.formatSelector
//
// 字段 PascalCase（实测）：bitrateInfo[].PlayAddr.UrlList / Width / Height / Bitrate / GearName
// UrlList 结构：[0]=v16 CDN, [1]=v19 CDN, [2]=play redirect
//
// ⚠️ A3 修正（2026-08-25）：旧注释说 play redirect「落盘首选，不被 403」是错的。
// 「关键发现 2」已证实：反盗链验的是页面 cookie 上下文，不是直链 vs redirect 的选择；
// yt-dlp 还会过滤掉 www.tiktok.com 的 play redirect。当前单视频走
// fetch(credentials:'include') 时 play redirect 与 CDN 直链**都能过**（都带页面 cookie），
// 所以暂不盲改选序 —— 但「redirect 更可靠」这个说法必须从注释里拿掉。
// 真实可靠性留待真机对比（P2 待验证）；download.js 已对档位失败做跨档重试兜底。
// ============================================================

(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.__TikTokCaptionHelper = root.__TikTokCaptionHelper || {};
    root.__TikTokCaptionHelper.formatSelector = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /**
   * 列出 bitrateInfo 的所有可用档位（降序：分辨率优先，其次码率）。
   * 每个档位优先 play-redirect（UrlList[2]），其次 video-cdn；绝不接受音频 CDN。
   * @param {Array} bitrateInfo
   * @param {object|null} guard url-guard 模块（含 classifyUrl），不传则用粗判
   * @returns {Array<{url:string, kind:string, width:number, height:number, bitrate:number, codecType:string, gearName:string}>}
   */
  function listFormats(bitrateInfo, guard) {
    if (!Array.isArray(bitrateInfo) || !bitrateInfo.length) return [];

    function classify(u) {
      if (guard && guard.classifyUrl) {
        var c = guard.classifyUrl(u);
        return c ? c.kind : null;
      }
      // 无 guard 时粗判
      if (/\/aweme\/v1\/play\//.test(u)) return 'play-redirect';
      if (/tiktokcdn|tiktokv|\.us\.tiktok\.com/.test(u)) return 'video-cdn';
      return null;
    }

    var formats = [];
    for (var i = 0; i < bitrateInfo.length; i++) {
      var fmt = bitrateInfo[i];
      var addr = fmt.PlayAddr || fmt.playAddr;
      if (!addr || !Array.isArray(addr.UrlList) || !addr.UrlList.length) continue;

      var chosenUrl = null, chosenKind = null;
      for (var j = 0; j < addr.UrlList.length; j++) {
        var kind = classify(addr.UrlList[j]);
        if (kind === 'play-redirect') { chosenUrl = addr.UrlList[j]; chosenKind = kind; break; }
        if (kind === 'video-cdn' && !chosenUrl) { chosenUrl = addr.UrlList[j]; chosenKind = kind; }
      }
      if (!chosenUrl) continue;

      formats.push({
        url: chosenUrl,
        kind: chosenKind,
        width: Number(addr.Width) || 0,
        height: Number(addr.Height) || 0,
        bitrate: Number(fmt.Bitrate) || 0,
        codecType: fmt.CodecType || '',
        gearName: fmt.GearName || '',
        dataSize: Number(addr.DataSize) || 0,
        watermarked: false,
      });
    }

    // 最高分辨率优先，其次码率（h264 码率可能高于 h265 但分辨率低，不能只看码率）
    formats.sort(function (a, b) {
      return ((b.width * b.height) - (a.width * a.height)) || (b.bitrate - a.bitrate);
    });
    return formats;
  }

  /**
   * 选最优档位（listFormats 的第一个）。
   * @returns {{url:string, kind:string, width:number, height:number, bitrate:number, codecType:string, gearName:string}|null}
   */
  function selectBestFormat(bitrateInfo, guard) {
    var formats = listFormats(bitrateInfo, guard);
    return formats.length ? formats[0] : null;
  }

  return { selectBestFormat: selectBestFormat, listFormats: listFormats };
});
