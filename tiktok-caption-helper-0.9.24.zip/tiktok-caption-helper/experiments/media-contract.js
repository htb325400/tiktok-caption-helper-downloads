(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.MediaContract = factory();
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const OWNERSHIPS = new Set([
    'exact_player', 'exact_tab', 'video_id_only', 'unverified', 'mismatch'
  ]);
  const EVIDENCE_STATUSES = new Set([
    'unknown', 'identity_bound', 'media_bound', 'content_verified'
  ]);
  const CONTENT_CLASSES = new Set([
    'speech', 'lyric', 'dialogue_plus_bgm', 'music_only', 'overlap',
    'label_only', 'mixed', 'empty', 'unknown'
  ]);
  const TEXT_STATES = new Set(['partial', 'stable', 'final']);
  const DIALOGUE_ROLES = new Set(['dialogue', 'overlap']);

  function asNullableString(value) {
    return value === undefined || value === null || value === '' ? null : String(value);
  }

  function enumOrDefault(value, values, fallback) {
    return values.has(value) ? value : fallback;
  }

  function deriveMediaKey(input) {
    if (input.mediaKey) return String(input.mediaKey);
    const source = asNullableString(input.mediaSrc);
    if (source) {
      try {
        const url = new URL(source);
        return `${url.origin}${url.pathname}`;
      } catch (_) {
        return source.slice(0, 256);
      }
    }
    return [asNullableString(input.videoId), asNullableString(input.wrapperId)]
      .filter(Boolean).join('|') || null;
  }

  function createMediaBinding(input) {
    input = input || {};
    const videoId = asNullableString(input.videoId);
    const wrapperId = asNullableString(input.wrapperId);
    const sessionId = asNullableString(input.sessionId);
    if (!sessionId) throw new TypeError('MediaBinding requires sessionId');
    return Object.freeze({
      videoId, wrapperId, sessionId,
      mediaSrc: asNullableString(input.mediaSrc),
      mediaKey: deriveMediaKey(input),
      sourceRoute: asNullableString(input.sourceRoute) || 'unknown',
      ownership: enumOrDefault(input.ownership, OWNERSHIPS, 'unverified'),
      audioRole: asNullableString(input.audioRole) || 'unknown',
      evidenceStatus: enumOrDefault(input.evidenceStatus, EVIDENCE_STATUSES, 'unknown')
    });
  }

  function normalizeSegment(segment) {
    segment = segment || {};
    return Object.freeze({
      start: Number.isFinite(segment.start) ? segment.start : null,
      end: Number.isFinite(segment.end) ? segment.end : null,
      text: typeof segment.text === 'string' ? segment.text : '',
      role: ['dialogue', 'singing', 'bgm', 'overlap', 'unknown'].includes(segment.role)
        ? segment.role : 'unknown',
      translate: segment.translate === true,
      warning: asNullableString(segment.warning)
    });
  }

  function createCandidate(input) {
    input = input || {};
    if (!input.binding || typeof input.binding !== 'object') {
      throw new TypeError('Candidate requires binding');
    }
    const segments = Array.isArray(input.segments) ? input.segments.map(normalizeSegment) : [];
    const timing = input.timing || {};
    return Object.freeze({
      binding: input.binding,
      textState: enumOrDefault(input.textState, TEXT_STATES, 'partial'),
      contentClass: enumOrDefault(input.contentClass, CONTENT_CLASSES, 'unknown'),
      segments: Object.freeze(segments),
      model: asNullableString(input.model),
      language: asNullableString(input.language),
      timing: Object.freeze({
        requestStartedMs: Number.isFinite(timing.requestStartedMs) ? timing.requestStartedMs : null,
        firstPartialMs: Number.isFinite(timing.firstPartialMs) ? timing.firstPartialMs : null,
        firstStableMs: Number.isFinite(timing.firstStableMs) ? timing.firstStableMs : null,
        finalMs: Number.isFinite(timing.finalMs) ? timing.finalMs : null,
        firstTranslationMs: Number.isFinite(timing.firstTranslationMs) ? timing.firstTranslationMs : null
      })
    });
  }

  function isDialogueCandidate(candidate) {
    if (!candidate || !candidate.binding || !['speech', 'dialogue_plus_bgm', 'overlap'].includes(candidate.contentClass)) return false;
    if (!['exact_player', 'exact_tab'].includes(candidate.binding.ownership)) return false;
    return candidate.segments.some(segment => DIALOGUE_ROLES.has(segment.role) && segment.text.trim());
  }

  function isTranslationEligible(candidate) {
    if (!candidate || !candidate.binding) return false;
    if (candidate.textState === 'partial') return false;
    if (!['exact_player', 'exact_tab'].includes(candidate.binding.ownership)) return false;
    if (!['media_bound', 'content_verified'].includes(candidate.binding.evidenceStatus)) return false;
    if (candidate.contentClass === 'label_only' || candidate.contentClass === 'empty') return false;
    return candidate.segments.some(segment => segment.translate && segment.text.trim());
  }

  return { createMediaBinding, createCandidate, isDialogueCandidate, isTranslationEligible };
}));
