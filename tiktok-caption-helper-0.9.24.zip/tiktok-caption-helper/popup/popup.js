// popup/popup.js
'use strict';

var GPT_NET_DEFAULT_MODEL = 'gpt-6.1-sol';

function parseGptNetConfig(text) {
  var lines = String(text || '').split(/\r?\n/).map(function (line) { return line.trim(); }).filter(Boolean);
  if (lines.length !== 2) throw new Error('GPT.net 文件必须包含两行：Key 和网关地址');
  var validated = validateGatewayConfig(lines[0], lines[1], GPT_NET_DEFAULT_MODEL);
  return { key: validated.key, endpoint: validated.endpoint, model: validated.model };
}

function validateGatewayConfig(key, base, model) {
  var normalizedKey = String(key || '').trim();
  var normalizedModel = String(model || '').trim();
  if (!normalizedKey) throw new Error('请提供 API Key');
  if (!normalizedModel) throw new Error('请提供模型名称');
  var url;
  try { url = new URL(String(base || '').trim()); } catch (e) { throw new Error('网关地址不是有效 URL'); }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new Error('网关地址必须使用 HTTP 或 HTTPS');
  if (url.username || url.password || /[?#]/.test(String(base))) throw new Error('网关地址不得包含凭据、查询参数或片段');
  var path = url.pathname.replace(/\/+$/, '');
  if (/\/chat\/completions$/.test(path)) path = path.slice(0, -'/chat/completions'.length);
  url.pathname = (path || '') + '/chat/completions';
  url.search = '';
  url.hash = '';
  return { key: normalizedKey, endpoint: url.toString(), model: normalizedModel };
}

function chromeStorageGet(keys) {
  return new Promise(function (resolve, reject) {
    chrome.storage.local.get(keys, function (result) {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(result || {});
    });
  });
}

function chromeStorageSet(values) {
  return new Promise(function (resolve, reject) {
    chrome.storage.local.set(values, function () {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

function requestHostPermission(origins) {
  return new Promise(function (resolve, reject) {
    if (!chrome.permissions || !chrome.permissions.request) return reject(new Error('无法请求网关主机权限'));
    chrome.permissions.request({ origins: origins }, function (granted) {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(Boolean(granted));
    });
  });
}

async function persistGptConfig(input, deps) {
  deps = deps || {};
  var config = validateGatewayConfig(input.key || 'saved-key-pending', input.endpoint, input.model);
  var origin = new URL(config.endpoint).origin;
  var isInsecure = new URL(config.endpoint).protocol === 'http:';
  if (isInsecure) {
    var confirmed = deps.confirm ? deps.confirm('此网关使用不安全的 HTTP 连接，仍要保存吗？') : window.confirm('此网关使用不安全的 HTTP 连接，仍要保存吗？');
    if (!confirmed) throw new Error('HTTP 网关未确认，配置未保存');
  }
  var granted = await (deps.requestPermission ? deps.requestPermission([origin + '/*']) : requestHostPermission([origin + '/*']));
  if (!granted) throw new Error('未获得网关主机权限，配置未保存');
  if (!input.key) {
    var current = deps.get ? await deps.get() : await chromeStorageGet(['aiTranslateKey']);
    config = validateGatewayConfig(current.aiTranslateKey, input.endpoint, input.model);
  }
  var values = {
    aiTranslateKey: config.key,
    aiTranslateEndpoint: config.endpoint,
    aiTranslateModel: config.model,
    aiTranslateCorrections: Boolean(input.corrections),
    aiTranslateAllowInsecure: isInsecure,
    translateEngine: 'openai',
    sttEngine: 'groq',
  };
  if (deps.set) await deps.set(values); else await chromeStorageSet(values);
  return config;
}

function toggleAiKeySection(engine) {
  var section = document.getElementById('ai-key-section');
  var hints = document.querySelectorAll('.engine-hint');
  if (!section) return;
  section.style.display = engine === 'google' ? 'none' : 'block';
  for (var i = 0; i < hints.length; i++) hints[i].style.display = hints[i].dataset.engine === engine ? '' : 'none';
}

function setMaskedPlaceholder(id, value) {
  if (value) document.getElementById(id).placeholder = '已设置 (••••' + value.slice(-4) + ')';
}

function loadAiConfig() {
  chrome.storage.local.get(['aiTranslateKey', 'aiTranslateEndpoint', 'aiTranslateModel', 'aiTranslateCorrections', 'sttEngine', 'geminiSttKey'], function (r) {
    setMaskedPlaceholder('ai-translate-key', r.aiTranslateKey);
    if (r.aiTranslateEndpoint) document.getElementById('ai-translate-endpoint').value = r.aiTranslateEndpoint;
    document.getElementById('ai-translate-model').value = r.aiTranslateModel || GPT_NET_DEFAULT_MODEL;
    document.getElementById('ai-translate-corrections').checked = Boolean(r.aiTranslateCorrections);
    if (r.sttEngine === 'gemini' || (!r.sttEngine && r.geminiSttKey)) {
      chrome.storage.local.set({ sttEngine: 'groq' });
    }
  });
}



document.addEventListener('DOMContentLoaded', function () {
  checkTabStatus();
  loadApiKey();
  loadModel();
  loadSttLang();
  loadTargetLang();
  loadTranslateEngine();
  loadAiConfig();

  document.getElementById('btn-translate').addEventListener('click', function () {
    const button = this;
    button.disabled = true;
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (chrome.runtime.lastError || !tabs[0]) {
        button.disabled = false;
        alert('无法获取当前页面，请打开 TikTok 视频页面');
        return;
      }
      chrome.tabs.sendMessage(tabs[0].id, { action: 'startVideoTranslation' }, function (response) {
        button.disabled = false;
        if (chrome.runtime.lastError) {
          alert('翻译面板未连接，请重新加载扩展并刷新视频页面');
        } else if (!response || !response.ok) {
          alert('无法启动翻译，请检查页面和识别配置');
        }
      });
    });
  });

  document.getElementById('btn-capture').addEventListener('click', function () {
    chrome.tabs.captureVisibleTab(function (dataUrl) {
      if (chrome.runtime.lastError) { alert('截图失败: ' + chrome.runtime.lastError.message); return; }
      let timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      chrome.downloads.download({ url: dataUrl, filename: 'tiktok/screenshot-' + timestamp + '.png' });
    });
  });

  document.getElementById('btn-shortcuts').addEventListener('click', function () {
    chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
  });

  document.getElementById('btn-save-key').addEventListener('click', function () {
    let key = document.getElementById('api-key').value.trim();
    if (!key) { alert('请输入 Groq API Key'); return; }
    chrome.storage.local.set({ groqKey: key }, function () {
      if (chrome.runtime.lastError) {
        alert('保存失败: ' + chrome.runtime.lastError.message);
      } else {
        document.getElementById('api-key').value = '';
        document.getElementById('api-key').placeholder = '已保存 (••••' + key.slice(-4) + ')';
        alert('✅ API Key 已保存！');
      }
    });
  });

  document.getElementById('model-select').addEventListener('change', function () {
    let model = this.value;
    chrome.storage.local.set({ groqModel: model }, function () {
      if (chrome.runtime.lastError) alert('模型保存失败: ' + chrome.runtime.lastError.message);
    });
  });

  document.getElementById('stt-lang-select').addEventListener('change', function () {
    let sttLang = this.value;
    chrome.storage.local.set({ sttLang: sttLang }, function () {
      if (chrome.runtime.lastError) alert('识别语言保存失败: ' + chrome.runtime.lastError.message);
    });
  });

  document.getElementById('target-lang-select').addEventListener('change', function () {
    let targetLang = this.value;
    chrome.storage.local.set({ targetLang: targetLang }, function () {
      if (chrome.runtime.lastError) alert('目标语言保存失败: ' + chrome.runtime.lastError.message);
    });
  });

  // ── 翻译引擎 ──
  document.getElementById('translate-engine-select').addEventListener('change', function () {
    var engine = this.value;
    chrome.storage.local.set({ translateEngine: engine }, function () {
      if (chrome.runtime.lastError) alert('翻译引擎保存失败: ' + chrome.runtime.lastError.message);
    });
    toggleAiKeySection(engine);
  });

  document.getElementById('btn-save-ai-key').addEventListener('click', function () {
    var key = document.getElementById('ai-translate-key').value.trim();
    if (!key) { alert('请输入 AI 翻译 API Key'); return; }
    chrome.storage.local.set({ aiTranslateKey: key }, function () {
      if (chrome.runtime.lastError) {
        alert('保存失败: ' + chrome.runtime.lastError.message);
      } else {
        document.getElementById('ai-translate-key').value = '';
        document.getElementById('ai-translate-key').placeholder = '已保存 (••••' + key.slice(-4) + ')';
        alert('✅ AI 翻译 Key 已保存！');
      }
    });
  });

  document.getElementById('btn-choose-gpt-net').addEventListener('click', function () {
    document.getElementById('gpt-net-file').click();
  });

  document.getElementById('gpt-net-file').addEventListener('change', function () {
    var file = this.files && this.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var config = parseGptNetConfig(reader.result);
        document.getElementById('ai-translate-key').value = config.key;
        document.getElementById('ai-translate-endpoint').value = config.endpoint;
        document.getElementById('ai-translate-model').value = config.model;
        document.getElementById('ai-translate-corrections').checked = true;
        document.getElementById('gpt-net-status').textContent = '已加载 GPT.net，请点击“保存 GPT.net 配置”';
      } catch (error) {
        alert('GPT.net 导入失败: ' + error.message);
      }
    };
    reader.onerror = function () { alert('GPT.net 文件读取失败'); };
    reader.readAsText(file);
  });

  document.getElementById('btn-save-gpt-net').addEventListener('click', async function () {
    var keyInput = document.getElementById('ai-translate-key');
    try {
      var config = await persistGptConfig({
        key: keyInput.value.trim(),
        endpoint: document.getElementById('ai-translate-endpoint').value.trim(),
        model: document.getElementById('ai-translate-model').value.trim(),
        corrections: document.getElementById('ai-translate-corrections').checked,
      });
      keyInput.value = '';
      setMaskedPlaceholder('ai-translate-key', config.key);
      document.getElementById('ai-translate-endpoint').value = config.endpoint;
      document.getElementById('translate-engine-select').value = 'openai';
      toggleAiKeySection('openai');
      document.getElementById('gpt-net-status').textContent = 'GPT.net 配置已保存';
      alert('✅ GPT.net 配置已保存！');
    } catch (error) {
      alert('保存失败: ' + error.message);
    }
  });
});

function loadApiKey() {
  chrome.storage.local.get(['groqKey'], function(r) {
    if (r.groqKey) {
      document.getElementById('api-key').placeholder = '已设置 (••••' + r.groqKey.slice(-4) + ')';
    }
  });
}

function loadModel() {
  chrome.storage.local.get(['groqModel'], function(r) {
    if (r.groqModel) {
      document.getElementById('model-select').value = r.groqModel;
    }
  });
}

function loadSttLang() {
  chrome.storage.local.get(['sttLang'], function(r) {
    if (r.sttLang) {
      document.getElementById('stt-lang-select').value = r.sttLang;
    }
  });
}

function loadTargetLang() {
  chrome.storage.local.get(['targetLang'], function(r) {
    if (r.targetLang) {
      document.getElementById('target-lang-select').value = r.targetLang;
    }
  });
}

function loadTranslateEngine() {
  chrome.storage.local.get(['translateEngine'], function(r) {
    if (r.translateEngine) {
      document.getElementById('translate-engine-select').value = r.translateEngine;
    }
    toggleAiKeySection(r.translateEngine || 'google');
  });
}

function loadAiTranslateKey() {
  chrome.storage.local.get(['aiTranslateKey'], function(r) {
    if (r.aiTranslateKey) {
      document.getElementById('ai-translate-key').placeholder = '已设置 (••••' + r.aiTranslateKey.slice(-4) + ')';
    }
  });
}

function checkTabStatus() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    let tab = tabs[0];
    let dot = document.getElementById('status-dot');
    let title = document.getElementById('status-title');
    let desc = document.getElementById('status-desc');
    if (!tab || !tab.url) return;
    if (tab.url.includes('tiktok.com')) {
      dot.classList.add('active');
      title.textContent = '✅ 已连接到 TikTok';
      desc.textContent = tab.url.includes('/video/') ? '视频页面 — 字幕功能已激活' : '打开视频页面以使用字幕功能';
    } else {
      dot.classList.remove('active');
      title.textContent = '⏳ 非 TikTok 页面';
      desc.textContent = '请打开 TikTok (tiktok.com) 以使用字幕功能';
    }
  });
}
