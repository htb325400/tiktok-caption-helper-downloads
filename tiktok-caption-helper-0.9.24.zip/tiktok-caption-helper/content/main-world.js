// content/main-world.js
// MAIN WORLD interceptor — runs via manifest "world": "MAIN" (Chrome 119+).
// Hooks fetch/XHR to intercept TikTok API responses.
// Reads SSR data for subtitles and audio URL.
(function () {
  'use strict';

  function emit(subtitles, audioUrl, videoUrl, videoId, bitrateInfo, speechUrl, audioRole, discovery) {
    window.dispatchEvent(new CustomEvent('tc-subtitle-data', {
      detail: { type: 'api-intercept', subtitles: subtitles, audioUrl: audioUrl || null, videoUrl: videoUrl || null, videoId: videoId || null, bitrateInfo: bitrateInfo || null, speechUrl: speechUrl || null, audioRole: audioRole || 'unknown', subtitleStatus: discovery ? discovery.status : 'unknown', subtitleReason: discovery ? discovery.reason : 'subtitle-field-unavailable' }
    }));
  }

  // 日志脱敏：完整 CDN URL 带签名 query，不能原样进 console（A5/B-04）。
  // 优先用 url-guard 的 redactUrl（去掉 query，只留 host+path 前 60 字符）。
  function redact(u) {
    if (!u) return '';
    var guard = window.__TikTokCaptionHelper && window.__TikTokCaptionHelper.urlGuard;
    if (guard && guard.redactUrl) return guard.redactUrl(u);
    try { var p = new URL(u); return p.host + p.pathname; } catch (e) { return String(u).slice(0, 40); }
  }

  // ============================================================
  // Helpers
  // ============================================================
  // 只取 CDN URL（音频：tiktokcdn.com / -us / -eu / tiktokv.com），过滤需要认证的 tiktok.com
  // 优先用 url-guard 严格校验（v数字前缀 + https + 无凭据），未加载时退回正则
  function firstUrl(val) {
    if (!val) return null;
    var guard = window.__TikTokCaptionHelper && window.__TikTokCaptionHelper.urlGuard;
    function ok(u) {
      if (guard) return guard.isAllowedAudioUrl(u);
      return /tiktokcdn(?:-us|-eu)?\.com|tiktokv\.com/i.test(u);
    }
    if (typeof val === 'string') {
      return ok(val) ? val : null;
    }
    if (Array.isArray(val)) {
      for (let i = 0; i < val.length; i++) {
        if (val[i] && ok(val[i])) return val[i];
      }
      return null;
    }
    return null;
  }

  // 取「视频原声轨」URL（video-cdn：us.tiktok.com / play-redirect）。
  // 与 firstUrl（音频 CDN）相反：这是真正的视频音频（含人声），
  // 但 us.tiktok.com 反盗链需页面 cookie，只能 content script fetch 拿到。
  // F1：STT 优先用这条轨，避免落到 music.play_url（背景音乐轨）。
  function firstSpeechUrl(val) {
    if (!val) return null;
    var guard = window.__TikTokCaptionHelper && window.__TikTokCaptionHelper.urlGuard;
    function ok(u) {
      if (guard && guard.isAllowedSpeechUrl) return guard.isAllowedSpeechUrl(u);
      // 无 guard 时的 fallback：与 url-guard 的 path 契约一致 ——
      // video-cdn 需 v数字 前缀 + 非根路径；play redirect 需 www.tiktok.com + 精确 /aweme/v1/play/。
      if (/^https:\/\/v\d[a-z0-9]*(?:-[a-z0-9]+)*\.us\.tiktok\.com\/[^?#]/i.test(u)) return true;
      try {
        var parsed = new URL(u);
        if (parsed.protocol === 'https:' && !parsed.username && !parsed.password &&
            (!parsed.port || parsed.port === '443') && /^v\d+-webapp-prime\.tiktok\.com$/i.test(parsed.hostname) &&
            /^\/video\/tos\/.+/.test(parsed.pathname)) return true;
      } catch (e) {}
      if (/^https:\/\/www\.tiktok\.com\/aweme\/v1\/play\/(?:\?|$)/i.test(u)) return true;
      return false;
    }
    if (typeof val === 'string') {
      return ok(val) ? val : null;
    }
    if (Array.isArray(val)) {
      for (let i = 0; i < val.length; i++) {
        if (val[i] && ok(val[i])) return val[i];
      }
      return null;
    }
    return null;
  }

  // ============================================================
  // Subtitle extraction
  // ============================================================
  function parseSubtitleEntry(raw) {
    let result = [];
    if (!Array.isArray(raw)) return result;
    for (let i = 0; i < raw.length; i++) {
      let entry = raw[i];
      if (!entry || typeof entry !== 'object') continue;
      let url = entry.Url || entry.url || entry.subtitleUrl || entry.subtitle_url || '';
      let langCode = entry.LanguageCodeName || entry.languageCodeName || entry.LanguageCode || entry.languageCode || entry.language_code || entry.lang || 'unknown';
      if (url) {
        result.push({ lang: langCode, langName: entry.LanguageName || entry.languageName || langCode, id: entry.SubtitleID || entry.subtitleId || entry.LanguageID || '', url: url, format: entry.Format || entry.format || 'vtt', source: entry.Source || entry.source || '' });
      }
    }
    return result;
  }

  function extractSubtitlesFromItem(item) {
    try {
      if (!item || typeof item !== 'object') return null;
      let video = item.video;
      let raw = video && (video.subtitles || video.subtitleInfos || video.subtitle_infos || video.subtitleData);
      if (!Array.isArray(raw) || !raw.length) return null;
      let result = parseSubtitleEntry(raw);
      return result.length > 0 ? result : null;
    } catch (e) { return null; }
  }

  function subtitleDiscovery(item, subtitles) {
    if (subtitles && subtitles.length) return { status: 'ready', reason: 'tracks' };
    let video = item && item.video;
    if (!video) return { status: 'unknown', reason: 'video-metadata-unavailable' };
    let fields = ['subtitles', 'subtitleInfos', 'subtitle_infos', 'subtitleData'];
    let field = fields.find(function (key) { return Object.prototype.hasOwnProperty.call(video, key); });
    if (!field) return { status: 'unknown', reason: 'subtitle-field-unavailable' };
    let raw = video[field];
    if (!Array.isArray(raw) || raw.length) return { status: 'error', reason: 'invalid-subtitle-tracks' };
    let hasMedia = !!(firstUrl(video.playAddr) || firstSpeechUrl(video.playAddr) ||
      firstUrl(video.play_addr && video.play_addr.url_list) || firstSpeechUrl(video.play_addr && video.play_addr.url_list) ||
      firstUrl(video.downloadAddr) || firstSpeechUrl(video.downloadAddr) ||
      firstUrl(video.download_addr && video.download_addr.url_list) || firstSpeechUrl(video.download_addr && video.download_addr.url_list) ||
      (Array.isArray(video.bitrateInfo) && video.bitrateInfo.length));
    if (!(Number(video.duration) > 0) || !hasMedia) return { status: 'unknown', reason: 'incomplete-video-metadata' };
    return { status: 'missing', reason: 'explicit-empty-tracks' };
  }

  function extractSubtitles(json) {
    try {
      let video = json?.itemInfo?.itemStruct?.video;
      if (!video) video = json?.aweme_detail?.video;
      if (!video) {
        let vd = json['webapp.video-detail'] || json['webapp.videoDetail'];
        if (vd) video = vd?.itemInfo?.itemStruct?.video;
      }
      if (!video && json.itemList?.[0]) return extractSubtitlesFromItem(json.itemList[0]);
      if (!video) return null;
      let raw = video.subtitles || video.subtitleInfos || video.subtitle_infos || video.subtitleData;
      if (!raw || !Array.isArray(raw) || !raw.length) return null;
      let result = parseSubtitleEntry(raw);
      return result.length > 0 ? result : null;
    } catch (e) { return null; }
  }

  // ============================================================
  // Resolve the inner item from various TikTok API response wrappers.
  // detail: json.aweme_detail / json.itemInfo.itemStruct
  // feed:   json.itemList[i] — caller iterates externally
  // SSR:    json.itemList[0] as last-resort fallback
  // ============================================================
  function resolveItem(json) {
    if (!json || typeof json !== 'object') return null;
    var item = json.aweme_detail || (json.itemInfo && json.itemInfo.itemStruct);
    if (!item) {
      var vd = json['webapp.video-detail'] || json['webapp.videoDetail'];
      if (vd) item = vd.itemInfo && vd.itemInfo.itemStruct;
    }
    // NOTE: only use itemList[0] as a fallback for SSR. API responses
    // with itemList are feeds — all items are processed in the caller.
    if (!item && Array.isArray(json.itemList) && json.itemList[0]) {
      item = json.itemList[0];
    }
    // SIGI_STATE: ItemModule is a videoId → item struct map
    if (!item && json.ItemModule && typeof json.ItemModule === 'object') {
      var keys = Object.keys(json.ItemModule);
      if (keys.length > 0) item = json.ItemModule[keys[0]];
    }
    return item || null;
  }

  // ============================================================
  // Audio URL extraction from a raw item object.
  // ============================================================
  function extractAudioUrlFromItem(item) {
    try {
      if (!item) return { audioUrl: null, videoUrl: null, videoId: null, bitrateInfo: null, speechUrl: null };
      var audioUrl = null, videoUrl = null, speechUrl = null, audioRole = 'unknown';
      var music = item.music, vid = item.video;

      // ── speechUrl：视频原声轨（video-cdn / us.tiktok.com，含人声）──
      // F1：STT 优先用这条，避免落到 music.play_url（背景音乐轨）。
      // 用 firstSpeechUrl 而非 firstUrl（后者只认 audio-cdn，会拒绝 video-cdn）。
      if (vid) {
        speechUrl = firstSpeechUrl(vid.download_addr && vid.download_addr.url_list)
                 || firstSpeechUrl(vid.play_addr && vid.play_addr.url_list)
                 || firstSpeechUrl(vid.playAddr);
      }
      if (!speechUrl) speechUrl = firstSpeechUrl(item.playAddr) || firstSpeechUrl(item.play_addr && item.play_addr.url_list);

      // v0.6.0 extraction order (known working): download_addr → play_addr → music
      // 这条仍是「音乐轨」fallback（audio-cdn），保留给原声视频 / speechUrl 失败时用。
      if (vid) {
        audioUrl = firstUrl(vid.download_addr && vid.download_addr.url_list)
                || firstUrl(vid.play_addr && vid.play_addr.url_list)
                || firstUrl(vid.playAddr);
        videoUrl = audioUrl;
        if (audioUrl) audioRole = 'video_media';
      }
      if (!audioUrl && music) {
        audioUrl = firstUrl(music.play_url && music.play_url.url_list)
                || firstUrl(music.playUrl)
                || (music.play_url && music.play_url.uri);
        if (audioUrl) audioRole = 'music';
      }
      if (!audioUrl) {
        audioUrl = firstUrl(item.musicUrl) || firstUrl(item.music_url && item.music_url.url_list);
        if (audioUrl) audioRole = 'music';
      }
      if (!audioUrl) {
        audioUrl = firstUrl(item.playAddr) || firstUrl(item.play_addr && item.play_addr.url_list);
        if (audioUrl) { videoUrl = audioUrl; audioRole = 'video_media'; }
      }

      var videoId = item.id || item.aweme_id || item.videoId || null;
      // 顺带提取视频档位（无水印下载用），字段 PascalCase
      var bitrateInfo = (vid && vid.bitrateInfo) ? vid.bitrateInfo : null;
      return { audioUrl: audioUrl, videoUrl: videoUrl, videoId: videoId, bitrateInfo: bitrateInfo, speechUrl: speechUrl, audioRole: audioRole };
    } catch (e) { return { audioUrl: null, videoUrl: null, videoId: null, bitrateInfo: null, speechUrl: null }; }
  }

  // ============================================================
  // Audio URL extraction from a full API JSON response.
  // ============================================================
  function extractAudioUrl(json) {
    try {
      return extractAudioUrlFromItem(resolveItem(json));
    } catch (e) { return { audioUrl: null, videoUrl: null, videoId: null, bitrateInfo: null }; }
  }

  // ============================================================
  // Response processing
  // ============================================================
  function processResponse(source, json) {
    if (!json || typeof json !== 'object') return;
    let subtitles = extractSubtitles(json);

    // FYP feed API returns itemList with 4-5 preloaded videos.
    // Process ALL items so urlCache has audio URLs for every video,
    // not just itemList[0]. Combined with xgplayer wrapper ID lookup,
    // this lets us find the exact audio URL for the current playing video.
    let itemList = Array.isArray(json.itemList) && json.itemList.length
      ? json.itemList : json['webapp.updated-items'];
    if (itemList && Array.isArray(itemList) && itemList.length > 0) {
      if (subtitles) console.log('[字幕助手] ✅ Subtitles:', subtitles.length + ' (feed, ' + itemList.length + ' items)');
      for (var i = 0; i < itemList.length; i++) {
        var itemSubtitles = extractSubtitlesFromItem(itemList[i]);
        var av = extractAudioUrlFromItem(itemList[i]);
        if (av.audioUrl) {
          console.log('[字幕助手] 🎤 URL[' + i + ']: vid=' + (av.videoId || '?') + ' ' + redact(av.audioUrl));
        }
        // bitrateInfo / speechUrl 独立于 audioUrl：音频拿不到时也要传（下载/STT 原声轨用）
        emit(itemSubtitles, av.audioUrl, av.videoUrl, av.videoId, av.bitrateInfo, av.speechUrl, av.audioRole, subtitleDiscovery(itemList[i], itemSubtitles));
      }
    } else {
      var av = extractAudioUrl(json);
      if (subtitles) console.log('[字幕助手] ✅ Subtitles:', subtitles.length);
      if (av.audioUrl) console.log('[字幕助手] 🎤 URL:', redact(av.audioUrl));
      if (av.speechUrl) console.log('[字幕助手] 🗣 speech:', redact(av.speechUrl));
      emit(subtitles, av.audioUrl, av.videoUrl, av.videoId, av.bitrateInfo, av.speechUrl, av.audioRole, subtitleDiscovery(resolveItem(json), subtitles));
    }
  }

  // ============================================================
  // fetch hook
  // ============================================================
  var _unmatchedUrls = {}; // diagnostic: track unmatched TikTok API URLs
  var _unmatchedLogTimer = 0;
  let _fetch = window.fetch;
  window.fetch = function (input, init) {
    let url = typeof input === 'string' ? input : (input && input.url ? input.url : '');
    let promise = _fetch.apply(this, arguments);
    if (url.indexOf('tiktok.com') !== -1 && /api|detail|aweme/i.test(url)) {
      promise.then(function (response) {
        if (response && response.clone) {
          response.clone().text().then(function (text) {
            try { let json = JSON.parse(text); processResponse(url, json); } catch (e) {}
          }).catch(function () {});
        }
      }).catch(function () {});
    } else if (url.indexOf('tiktok.com') !== -1 && /api|recommend|feed|list|page/i.test(url)) {
      // Diagnostic: log TikTok API URLs that are NOT matched by the main regex.
      // Helps identify scroll-load feed API patterns that should be intercepted.
      var short = url.replace(/https?:\/\/[^\/]+/, '').slice(0, 80);
      if (!_unmatchedUrls[short]) {
        _unmatchedUrls[short] = true;
        clearTimeout(_unmatchedLogTimer);
        _unmatchedLogTimer = setTimeout(function () {
          console.log('[字幕助手] DIAG: Unmatched TikTok API URLs:', Object.keys(_unmatchedUrls).join(', '));
        }, 3000);
      }
    }
    return promise;
  };

  // ============================================================
  // XHR hook
  // ============================================================
  let XHR = XMLHttpRequest.prototype, _open = XHR.open, _send = XHR.send;
  XHR.open = function (method, url) { this._tcUrl = url; return _open.apply(this, arguments); };
  XHR.send = function (body) {
    let url = this._tcUrl, self = this;
    if (url && url.indexOf('tiktok.com') !== -1 && /api|detail|aweme/i.test(url)) {
      this.addEventListener('load', function () {
        try { let json = JSON.parse(self.responseText); processResponse(url, json); } catch (e) {}
      });
    } else if (url && url.indexOf('tiktok.com') !== -1 && /api|recommend|feed|list|page/i.test(url)) {
      var short = url.replace(/https?:\/\/[^\/]+/, '').slice(0, 80);
      if (!_unmatchedUrls[short]) {
        _unmatchedUrls[short] = true;
        clearTimeout(_unmatchedLogTimer);
        _unmatchedLogTimer = setTimeout(function () {
          console.log('[字幕助手] DIAG: Unmatched TikTok API URLs (XHR):', Object.keys(_unmatchedUrls).join(', '));
        }, 3000);
      }
    }
    return _send.apply(this, arguments);
  };

  // ============================================================
  // SSR data
  // ============================================================
  function checkSSR() {
    let el = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
    if (el && el.textContent) {
      try {
        let json = JSON.parse(el.textContent);
        if (json && typeof json === 'object') {
          let data = json;
          if (json.__DEFAULT_SCOPE__ && typeof json.__DEFAULT_SCOPE__ === 'object') {
            data = json.__DEFAULT_SCOPE__;
          }
          processResponse('SSR', data);
        }
      } catch (e) {}
    }
  }
  setTimeout(checkSSR, 500);
  setTimeout(checkSSR, 2000);
  window.addEventListener('load', checkSSR);

  // ============================================================
  // SPA refresh: re-fetch page HTML to get fresh CDN URLs
  // SSR data in DOM stays stale after SPA navigation.
  // ============================================================
  window.addEventListener('tc-refresh-data', function () {
    fetch(location.href, { cache: 'no-store' })
      .then(function (r) { return r.text(); })
      .then(function (html) {
        let match = html.match(/id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([\s\S]*?)<\/script>/);
        if (!match) return;
        try {
          let json = JSON.parse(match[1]);
          if (json.__DEFAULT_SCOPE__) json = json.__DEFAULT_SCOPE__;
          processResponse('SSR-refresh', json);
        } catch (e) {}
      }).catch(function () {});
  });

  // ============================================================
  // FYP subtitle fetch: call TikTok item detail API to get audio URL.
  //
  // v0.9.6: Replaced iframe with fetch().
  //   Problem: iframe → 403 for many videos (TikTok anti-framing).
  // v0.9.6.1: Replaced HTML page fetch with API call.
  //   Problem: @a/video/ID → 1485B soft-redirect page, no SSR JSON.
  //   Fix: directly call TikTok's item detail API (same-origin, has cookies).
  //   API returns JSON with itemInfo.itemStruct → same format as existing intercepts.
  // ============================================================
  window.addEventListener('tc-fetch-subtitles', function (e) {
    var videoId = e.detail && e.detail.videoId;
    if (!videoId) return;
    console.log('[字幕助手] Fetching detail for video', videoId);

    var ABORT_TIMEOUT = 12000;
    var done = false;

    function finish(result) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      window.dispatchEvent(new CustomEvent('tc-fetch-detail-done', { detail: result }));
    }

    var timer = setTimeout(function () {
      console.warn('[字幕助手] Detail fetch timeout (' + (ABORT_TIMEOUT/1000) + 's)');
      finish({ videoId: videoId, success: false, audioUrl: null, error: 'Fetch timeout (' + (ABORT_TIMEOUT/1000) + 's)' });
    }, ABORT_TIMEOUT);

    // Layer 1: TikTok item detail API (same-origin, no auth issues)
    var apiUrl = 'https://www.tiktok.com/api/item/detail/?itemId=' + videoId + '&aid=1988';
    fetch(apiUrl, { cache: 'no-store', credentials: 'include' })
      .then(function tryJson(resp) {
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        // Read as text first — JSON can fail if body is empty
        return resp.text();
      })
      .then(function (text) {
        if (done) return;
        if (!text || text.trim().length < 10) {
          throw new Error('Empty API response');
        }
        var json;
        try { json = JSON.parse(text); } catch (pe) {
          throw new Error('API JSON parse: ' + pe.message);
        }
        processResponse('fyp-detail-api', json);
        var av = extractAudioUrl(json);
        // 修 P1：success 判据从「有 audioUrl（音乐轨）」放宽到「有 audioUrl 或 speechUrl（原声轨）」。
        // 纯原声条目只有 speechUrl，之前会被误判为「无音频」而走 SSR fallback 甚至失败。
        if (av.audioUrl || av.speechUrl) {
          console.log('[字幕助手] Detail API success: ' + (av.audioUrl ? 'audio' : 'speech') + ' found');
          finish({ videoId: videoId, success: true, audioUrl: av.audioUrl, speechUrl: av.speechUrl });
        } else {
          console.warn('[字幕助手] Detail API: no audio/speech URL in response');
          throw new Error('API returned but no audio URL');
        }
      })
      .catch(function (err) {
        if (done) return;
        console.warn('[字幕助手] Detail API failed (' + err.message + '), falling back to SSR...');

        // Layer 2: Fetch the video page HTML and extract SSR data.
        // TikTok sometimes returns empty API responses but the SSR __UNIVERSAL_DATA
        // in the page HTML has the full item struct including audio URLs.
        var pageUrl = 'https://www.tiktok.com/video/' + videoId;
        fetch(pageUrl, { cache: 'no-store', credentials: 'include' })
          .then(function (r) {
            if (done) return; // timer fired while waiting for response
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.text();
          })
          .then(function (html) {
            if (done) return;

            // ── Extract JSON from any known SSR container ──
            // TikTok uses different containers depending on page type and deploy:
            //   __UNIVERSAL_DATA_FOR_REHYDRATION__ — main SSR data
            //   SIGI_STATE — alternate SSR data (profile/search pages, sometimes video)
            //   <script type="application/json"> — generic embedding
            var json = null;
            var source = 'unknown';
            var CONTAINER_IDS = [
              '__UNIVERSAL_DATA_FOR_REHYDRATION__',
              'SIGI_STATE',
            ];

            for (var ci = 0; ci < CONTAINER_IDS.length; ci++) {
              var cid = CONTAINER_IDS[ci];
              // Try both quote styles + whitespace variants
              var patterns = [
                new RegExp('id="' + cid + '"[^>]*>([\\s\\S]*?)<\\/script>'),
                new RegExp("id='" + cid + "'[^>]*>([\\s\\S]*?)<\\/script>"),
                new RegExp("<script[^>]*id\\s*=\\s*[\"']" + cid + "[\"'][^>]*>([\\s\\S]*?)<\\/script>"),
              ];
              for (var pj = 0; pj < patterns.length; pj++) {
                var m = html.match(patterns[pj]);
                if (m) {
                  try { json = JSON.parse(m[1]); source = cid; } catch (_) {}
                  if (json) break;
                }
              }
              if (json) break;
            }

            // ── Container fallback: find any <script type="application/json"> block
            //     that contains item struct data with audio URLs ──
            if (!json) {
              var jsonScripts = html.match(/<script[^>]*type\s*=\s*["']application\/json["'][^>]*>([\s\S]*?)<\/script>/gi);
              if (jsonScripts) {
                for (var sk = 0; sk < jsonScripts.length; sk++) {
                  var inner = jsonScripts[sk].match(/<script[^>]*>([\s\S]*?)<\/script>/i);
                  if (inner && inner[1] && (inner[1].indexOf('"play_addr"') !== -1 || inner[1].indexOf('"video"') !== -1)) {
                    try { json = JSON.parse(inner[1]); source = 'application/json'; } catch (_) {}
                    if (json) break;
                  }
                }
              }
            }

            // ── Last resort: scan ALL <script> blocks for item/video struct ──
            if (!json) {
              var allScripts = html.match(/<script[^>]*>([\s\S]*?)<\/script>/gi);
              if (allScripts) {
                for (var ak = 0; ak < allScripts.length; ak++) {
                  var ai = allScripts[ak].match(/<script[^>]*>([\s\S]*?)<\/script>/i);
                  if (!ai || !ai[1]) continue;
                  var raw = ai[1];
                  // Quick check: does this block look like JSON with audio data?
                  if (raw.indexOf('"play_addr"') === -1 && raw.indexOf('"download_addr"') === -1 && raw.indexOf('"bit_rate"') === -1) continue;
                  // Try to find a JSON object boundary that contains the audio data
                  var objMatch = raw.match(/\{[\s\S]*"play_addr"[\s\S]*\}/);
                  if (!objMatch) objMatch = raw.match(/\{[\s\S]*"download_addr"[\s\S]*\}/);
                  if (!objMatch) objMatch = raw.match(/\{[\s\S]*"bit_rate"[\s\S]*\}/);
                  if (objMatch) {
                    try { json = JSON.parse(objMatch[0]); source = 'script-block'; } catch (_) {}
                    if (json) break;
                  }
                }
              }
            }

            // ── Last resort: scan raw HTML for TikTok CDN URLs ──
            // These URLs appear as plain text in the page, NOT inside any JSON
            // container. Pattern: https://v[0-9]+.tiktokcdn.com/[hash]/video/...
            if (!json) {
              var cdnMatches = html.match(/https?:\/\/v\d+[a-z0-9-]*\.tiktokcdn(?:-us|-eu)?\.com\/[a-f0-9]+\/[a-f0-9]+\/video\/tos\/[^"'\\s<]+/gi);
              if (cdnMatches) {
                // De-duplicate and pick the first valid URL
                var seen = {};
                var cdnUrls = [];
                for (var cm = 0; cm < cdnMatches.length; cm++) {
                  var u = cdnMatches[cm].replace(/["'\\s<>].*$/, '');
                  if (!seen[u]) { seen[u] = true; cdnUrls.push(u); }
                }
                if (cdnUrls.length > 0) {
                  console.log('[字幕助手] SSR raw CDN scan: found ' + cdnUrls.length + ' URLs');
                  source = 'cdn-scan';
                  // Build a minimal fake JSON so extractAudioUrlFromItem still works
                  json = {
                    video: {
                      play_addr: { url_list: cdnUrls },
                    },
                    id: videoId,
                  };
                }
              }
            }

            // ── Layer 6: JS 变量赋值扫描 ──
            // 第 4 层(raw CDN scan)要求 v\d+.tiktokcdn.com + /video/tos/ 路径，
            // 且 URL 以明文出现。部分页面把 CDN URL 藏在 JS 变量赋值里
            // (var/window.KEY = "...")，host/路径不同、斜杠还可能被 JSON 转义成 \/。
            // 先反转义斜杠，再扫变量赋值，最后过滤掉明显是静态资源(字体/图片/JS)的 URL。
            if (!json) {
              var html6 = html.replace(/\\\//g, '/');
              var jsVars = [];
              var jsSeen = {};
              var varPatterns = [
                /(?:var|let|const)\s+\w+\s*=\s*["']([^"'\s]*?(?:tiktokcdn(?:-us|-eu)?\.com|tiktokv\.com)[^"'\s]*)["']/gi,
                /window\.\w+\s*=\s*["']([^"'\s]*?(?:tiktokcdn(?:-us|-eu)?\.com|tiktokv\.com)[^"'\s]*)["']/gi,
                /\w+\s*:\s*["']([^"'\s]*?(?:tiktokcdn(?:-us|-eu)?\.com|tiktokv\.com)[^"'\s]*)["']/gi,
              ];
              var STATIC_RE = /(?:webfont|font|image|avatar|webapp|static|\.js|\.css|\.woff|\.ttf|\.png|\.jpe?g|\.svg|\.webp)/i;
              for (var vpi = 0; vpi < varPatterns.length; vpi++) {
                var vm;
                while ((vm = varPatterns[vpi].exec(html6)) !== null) {
                  var vu = vm[1];
                  if (vu.indexOf('http') !== 0) continue;
                  if (STATIC_RE.test(vu)) continue; // 跳过明显静态资源
                  if (!jsSeen[vu]) { jsSeen[vu] = true; jsVars.push(vu); }
                }
              }
              if (jsVars.length > 0) {
                console.log('[字幕助手] SSR JS-var scan (layer 6): found ' + jsVars.length + ' CDN URLs');
                source = 'js-var-scan';
                json = { video: { play_addr: { url_list: jsVars } }, id: videoId };
              }
            }

            if (!json) {
              // 诊断：dump 候选 CDN 片段，帮助定位 URL 真实形态
              var diagHtml = html.replace(/\\\//g, '/');
              var diagUrls = diagHtml.match(/https?:\/\/[^"'\s<>]*?(?:tiktokcdn(?:-us|-eu)?\.com|tiktokv\.com|musical\.ly|akamaized\.net)[^"'\s<>]*/gi) || [];
              if (diagUrls.length) {
                console.warn('[字幕助手] 候选 CDN URL 片段(' + diagUrls.length + '): ' + diagUrls.slice(0, 10).map(redact).join(' | '));
              } else {
                console.warn('[字幕助手] 无候选 CDN URL 片段 — 页面不含任何 tiktokcdn/tiktokv/musical.ly/akamaized URL');
              }
              finish({ videoId: videoId, success: false, audioUrl: null,
                error: 'SSR fallback: no data container found. Tried: ' + CONTAINER_IDS.join(', ') + ', application/json, script-block scan, raw CDN scan, js-var scan. Page: ' + html.length + ' bytes' });
              return;
            }

            if (json.__DEFAULT_SCOPE__) json = json.__DEFAULT_SCOPE__;
            processResponse('fyp-ssr-fallback', json);
            var av = extractAudioUrl(json);
            if (av.audioUrl || av.speechUrl) {
              console.log('[字幕助手] SSR fallback success: ' + (av.audioUrl ? 'audio' : 'speech') + ' found in ' + source);
              finish({ videoId: videoId, success: true, audioUrl: av.audioUrl, speechUrl: av.speechUrl });
            } else {
              console.warn('[字幕助手] SSR fallback: found ' + source + ' but no audio/speech URL in data');
              finish({ videoId: videoId, success: false, audioUrl: null, error: 'SSR fallback: found ' + source + ' data but no audio URL' });
            }
          })
          .catch(function (err2) {
            if (done) return;
            console.warn('[字幕助手] SSR fallback failed:', err2.message);
            finish({ videoId: videoId, success: false, audioUrl: null, error: err.message + '; SSR fallback: ' + err2.message });
          });
      });
  });

  console.log('[字幕助手] MAIN-WORLD active');
})();
