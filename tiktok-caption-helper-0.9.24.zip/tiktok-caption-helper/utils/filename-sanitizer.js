// utils/filename-sanitizer.js
// ============================================================
// 文件名净化 — 去路径穿越 / 控制字符 / Windows 保留名 / 超长
//
// UMD-lite：node 可 require 单测；浏览器/SW 挂 window.__TikTokCaptionHelper.filenameSanitizer
// ============================================================

(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.__TikTokCaptionHelper = root.__TikTokCaptionHelper || {};
    root.__TikTokCaptionHelper.filenameSanitizer = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var MAX_LEN = 100;

  // Windows 保留设备名：不能作为文件/目录名（Windows 在 FAT/NTFS 上拒收）
  // 含上标形式：COM¹/COM²/COM³、LPT¹/LPT²/LPT³ 在 Windows 里也映射为保留名。
  var WIN_RESERVED = /^(con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])$/i;

  /**
   * 净化文件名，返回安全文件名（保留扩展名）。
   * @param {*} name
   * @returns {string}
   */
  function sanitizeFilename(name) {
    var s = String(name == null ? '' : name);
    s = s.replace(/[\\/]+/g, '_');                 // 路径分隔符
    s = s.replace(/\.\./g, '_');                   // 路径穿越
    s = s.replace(/[:*?"<>|\x00-\x1f]/g, '_');     // Windows 保留字符 + 控制字符
    if (s.length > MAX_LEN) {
      var ext = s.match(/\.[a-z0-9]{2,5}$/i);
      var keep = MAX_LEN - (ext ? ext[0].length : 0);
      s = s.slice(0, keep) + (ext ? ext[0] : '');
    }
    s = s.replace(/^[.\s]+|[.\s]+$/g, '');         // 去首尾空格/点
    if (!s) return 'tiktok-video.mp4';

    // Windows 保留设备名（CON/PRN/AUX/NUL/COM1-9/LPT1-9，含带扩展名形式 CON.mp4）
    // 此前文件头声称已做此防护，实际没有 —— 补上（B-06 / A4）
    var stem = s.split('.')[0] || s;
    if (WIN_RESERVED.test(stem)) {
      s = '_' + s;
    }
    return s;
  }

  return { sanitizeFilename: sanitizeFilename, MAX_LEN: MAX_LEN };
});
