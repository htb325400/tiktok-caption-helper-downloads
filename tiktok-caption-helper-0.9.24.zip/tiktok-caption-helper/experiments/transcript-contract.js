'use strict';

(function attachTranscriptContract(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.TranscriptContract = api;
})(typeof globalThis === 'object' ? globalThis : this, function createApi() {
  const CONTENT_TYPES = new Set(['dialogue', 'singing', 'music', 'overlap', 'unknown']);

  function finiteOrNull(value) {
    if (value === null || value === undefined || value === '') return null;
    return Number.isFinite(value) ? value : null;
  }

  function normalizeContentType(value) {
    return CONTENT_TYPES.has(value) ? value : 'unknown';
  }

  function normalizeStability(value) {
    return value === 'partial' || value === 'stable' || value === 'final' ? value : 'final';
  }

  function normalizeRevision(value) {
    return Number.isInteger(value) && value >= 0 ? value : 0;
  }

  function normalizeSequence(value) {
    return Number.isInteger(value) && value >= 0 ? value : null;
  }

  function roleClass(labels) {
    const values = Array.isArray(labels) ? labels : [];
    if (values.includes('overlap')) return { contentType: 'overlap', warning: '存在重叠人声，识别可能不完整' };
    if (values.includes('dialogue') && values.includes('bgm')) {
      return { contentType: 'dialogue', warning: '人物对白伴有背景音乐，识别可能受影响' };
    }
    if (values.includes('dialogue')) return { contentType: 'dialogue', warning: null };
    if (values.includes('singing')) return { contentType: 'singing', warning: '歌曲/演唱内容，歌词识别与翻译可能不准确' };
    if (values.includes('bgm')) return { contentType: 'music', warning: '当前片段可能只有背景音乐，没有可靠人物对白' };
    return { contentType: 'unknown', warning: '音频内容类型未确认' };
  }

  function annotateSegments(input, options = {}) {
    if (!Array.isArray(input)) return [];
    const contentType = normalizeContentType(options.contentType);
    const contentTypeSource = typeof options.contentTypeSource === 'string'
      ? options.contentTypeSource
      : 'unknown';
    return input
      .filter(segment => segment && typeof segment.text === 'string' && segment.text.trim())
      .map(segment => {
        const start = finiteOrNull(segment.start);
        const end = finiteOrNull(segment.end);
        const validRange = start !== null && end !== null && start >= 0 && end >= start;
        return {
          start: validRange ? start : null,
          end: validRange ? end : null,
          text: segment.text,
          contentType: normalizeContentType(segment.contentType || contentType),
          contentTypeSource: segment.contentTypeSource || contentTypeSource,
          translate: segment.translate !== false
        };
      });
  }

  function normalizeTranscript(result, context = {}) {
    const rawSegments = Array.isArray(result && result.segments) && result.segments.length
      ? result.segments
      : [{ start: null, end: null, text: result && typeof result.text === 'string' ? result.text : '' }];
    const contentType = context.contentClass === 'lyric' ? 'singing' : 'unknown';
    const contentTypeSource = context.contentTypeSource || (context.contentClass === 'lyric' ? 'stt_label' : 'unknown');
    return {
      schemaVersion: 1,
      kind: 'transcript',
      stability: normalizeStability(context.stability),
      revision: normalizeRevision(context.revision),
      sequence: normalizeSequence(context.sequence),
      sessionId: context.sessionId || null,
      videoId: context.videoId || null,
      routeEpoch: Number.isInteger(context.routeEpoch) ? context.routeEpoch : null,
      requestId: Number.isInteger(context.requestId) ? context.requestId : null,
      sourceRoute: context.sourceRoute || 'unknown',
      language: result && result.language || null,
      text: result && typeof result.text === 'string' ? result.text : '',
      segments: annotateSegments(rawSegments, { contentType, contentTypeSource })
    };
  }

  function compareTranscriptRevision(current, incoming) {
    if (!current || !incoming) return null;
    for (const key of ['sessionId', 'videoId', 'routeEpoch']) {
      const left = current[key] == null ? null : String(current[key]);
      const right = incoming[key] == null ? null : String(incoming[key]);
      if (left !== right) return null;
    }
    const leftRevision = normalizeRevision(current.revision);
    const rightRevision = normalizeRevision(incoming.revision);
    if (rightRevision > leftRevision) return 1;
    if (rightRevision < leftRevision) return -1;
    const leftSequence = normalizeSequence(current.sequence);
    const rightSequence = normalizeSequence(incoming.sequence);
    if (leftSequence !== null && rightSequence !== null) {
      if (rightSequence > leftSequence) return 1;
      if (rightSequence < leftSequence) return -1;
    }
    return 0;
  }

  function annotateTranscriptIntervals(result, roleIntervals) {
    const source = result && Array.isArray(result.segments) ? result.segments : [];
    const intervals = Array.isArray(roleIntervals) ? roleIntervals : [];
    const mapped = source.map(segment => {
      const start = finiteOrNull(segment.start);
      const end = finiteOrNull(segment.end);
      if (start === null || end === null || end <= start) {
        return { ...segment, contentType: 'unknown', contentTypeSource: 'unknown', warning: null };
      }
      let best = null;
      let bestOverlap = 0;
      for (const interval of intervals) {
        if (!interval || !Number.isFinite(interval.start) || !Number.isFinite(interval.end)) continue;
        const overlap = Math.max(0, Math.min(end, interval.end) - Math.max(start, interval.start));
        if (overlap > bestOverlap) {
          bestOverlap = overlap;
          best = interval;
        }
      }
      if (!best) return { ...segment, contentType: 'unknown', contentTypeSource: 'unknown', warning: null };
      const role = roleClass(best.labels);
      return { ...segment, contentType: role.contentType, contentTypeSource: 'role_interval', warning: role.warning };
    });
    return {
      ...result,
      segments: mapped,
      warnings: mapped.filter(segment => segment.warning).map(segment => segment.warning)
        .filter((warning, index, values) => values.indexOf(warning) === index)
    };
  }

  return { normalizeTranscript, annotateSegments, annotateTranscriptIntervals, compareTranscriptRevision };
});
