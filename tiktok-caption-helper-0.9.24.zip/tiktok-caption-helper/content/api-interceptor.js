// content/api-interceptor.js
// ============================================================
// TikTok API Interceptor (Isolated World)
//
// Receives data from main-world.js via CustomEvent.
// main-world.js now runs via manifest "world": "MAIN" —
// no more <script> injection needed.
// ============================================================

(function () {
  'use strict';

  // State
  let currentSubtitles = null;
  let currentSubtitlePacket = null;
  let currentAudioUrl = null;
  let currentVideoUrl = null;
  let currentBitrateInfo = null; // 当前视频档位（无水印下载用）
  let currentSpeechUrl = null;   // 当前视频原声轨（STT 用，video-cdn/us.tiktok.com）
  let subtitleListeners = [];
  let audioListeners = [];
  let videoChangeListeners = [];
  let lastVideoId = null;  // 最近一次拦截到的 videoId（FYP专用）
  let fypRouteEpoch = 0;
  let fypRouteKey = null;
  let fypVideoTimeSamples = typeof WeakMap === 'function' ? new WeakMap() : null;
  const FYP_TIME_SAMPLE_GRACE_MS = 500;

  // FYP auto-subtitle: track which videoId we've requested
  var _fypRequestedId = null;
  var _fypSubtitleTimer = null;

  // Cache: videoId → {audioUrl, videoUrl, audioRole} for feeds (FYP, profile)
  // Allows instant lookup when user clicks a video from a list.
  let urlCache = {};

  // Rendered videoIds — once bilingual subtitles are rendered for a videoId,
  // block all future subtitle notifications for that video. Prevents SSR
  // refresh from overwriting a correct bilingual render with double-Chinese.
  let renderedVideoIds = new Set();

  function onSubtitles(fn) {
    if (typeof fn !== 'function') throw new TypeError('subtitle listener must be a function');
    if (subtitleListeners.indexOf(fn) !== -1) return function () {};
    subtitleListeners.push(fn);
    // Only replay current data if it hasn't been flushed by resetRendered().
    // Prevents stale subtitle tracks from a previous video from being pushed
    // to a newly subscribed render pipeline on SPA navigation.
    if (currentSubtitlePacket && currentSubtitlePacket.videoId === getCurrentRouteVideoId() &&
        currentSubtitlePacket.epoch === getCurrentSubtitleEpoch()) {
      console.log('[字幕助手] Replaying cached subtitles to new subscriber (' +
        (currentSubtitles ? currentSubtitles.length : 0) + ' tracks)');
      fn(currentSubtitlePacket);
    }
    let subscribed = true;
    return function () {
      if (!subscribed) return;
      subscribed = false;
      var index = subtitleListeners.indexOf(fn);
      if (index !== -1) subtitleListeners.splice(index, 1);
    };
  }

  function getCurrentSubtitlePacket() {
    var route = getCurrentRouteState();
    var packet = currentSubtitlePacket;
    if (!packet || !route.videoId || String(packet.videoId) !== String(route.videoId)) return null;
    if (!getCurrentVideoId() && (packet.epoch !== route.epoch ||
        packet.mediaKey !== route.mediaKey || packet.wrapperId !== route.wrapperId)) return null;
    var snapshot = Object.assign({}, packet);
    if (Array.isArray(packet.subtitles)) snapshot.subtitles = Object.freeze(packet.subtitles.slice());
    return Object.freeze(snapshot);
  }

  function onVideoChange(fn) {
    if (typeof fn !== 'function') throw new TypeError('video change listener must be a function');
    if (videoChangeListeners.indexOf(fn) !== -1) return function () {};
    videoChangeListeners.push(fn);
    let subscribed = true;
    return function () {
      if (!subscribed) return;
      subscribed = false;
      var index = videoChangeListeners.indexOf(fn);
      if (index !== -1) videoChangeListeners.splice(index, 1);
    };
  }

  function onAudioUrl(fn) {
    observeFypRoute();
    audioListeners.push(fn);
    if (currentAudioUrl) fn(currentAudioUrl, currentVideoUrl);
  }

  function notifySubtitles(subtitles, videoId, subtitleStatus, subtitleReason) {
    observeFypRoute();
    var route = getCurrentRouteState();
    var status = ['ready', 'missing', 'error', 'unknown'].indexOf(subtitleStatus) !== -1
      ? subtitleStatus
      : (Array.isArray(subtitles) && subtitles.length ? 'ready' : 'missing');
    currentSubtitles = subtitles;
    currentSubtitlePacket = {
      subtitles: subtitles,
      videoId: videoId,
      subtitleStatus: status,
      subtitleReason: subtitleReason,
      epoch: route.epoch,
      routeEpoch: route.epoch,
      wrapperId: route.wrapperId,
      mediaKey: route.mediaKey
    };
    for (let i = 0; i < subtitleListeners.length; i++) {
      subtitleListeners[i](currentSubtitlePacket);
    }
  }

  function notifyAudio(audioUrl, videoUrl, videoId, bitrateInfo, speechUrl, audioRole) {
    observeFypRoute();
    var detailId = getCurrentVideoId();
    var fypRoute = detailId ? null : getCurrentFypRoute();
    var isCurrentDetailItem = !!detailId && !!videoId && String(detailId) === String(videoId);
    var isActiveFypItem = !!detailId || !!(fypRoute && fypRoute.videoId &&
      String(fypRoute.videoId) === String(videoId));
    if (videoId) {
      var entry = urlCache[videoId] || {};
      if (audioUrl) { entry.audioUrl = audioUrl; entry.videoUrl = videoUrl; entry.audioRole = audioRole === 'music' || audioRole === 'video_media' ? audioRole : 'unknown'; }
      if (bitrateInfo) entry.bitrateInfo = bitrateInfo;
      if (speechUrl) entry.speechUrl = speechUrl;
      urlCache[videoId] = entry;

      if (detailId ? !isCurrentDetailItem : !isActiveFypItem) return false;
      lastVideoId = videoId;
    }
    if (detailId ? !isCurrentDetailItem : !isActiveFypItem) return false;
    if (speechUrl) {
      currentSpeechUrl = speechUrl;
    }
    if (bitrateInfo) {
      currentBitrateInfo = bitrateInfo; // 独立于 audioUrl：音频拿不到时档位也能更新
    }
    if (audioUrl) {
      currentAudioUrl = audioUrl;
      currentVideoUrl = videoUrl;
    }
    for (let i = 0; i < audioListeners.length; i++) {
      audioListeners[i](audioUrl, videoUrl);
    }

    // ── FYP auto-subtitle: when on FYP and a new videoId arrives,
    //     auto-fetch subtitle data in background (N4) ──
    var currentId = getCurrentVideoId();
    if (!currentId && videoId && videoId !== _fypRequestedId) {
      _fypRequestedId = videoId;
      clearTimeout(_fypSubtitleTimer);
      // Debounce 300ms: don't fire on rapid scroll, wait for video to settle.
      // Shorter than before (was 800ms) so urlCache is populated before user clicks STT.
      _fypSubtitleTimer = setTimeout(function () {
        console.log('[字幕助手] 🤖 FYP auto-fetching subtitles for video ' + videoId);
        window.dispatchEvent(new CustomEvent('tc-fetch-subtitles', { detail: { videoId: videoId } }));
      }, 300);
    }
    return true;
  }

  // Look up cached URL when navigating to a video page
  function lookupCachedUrl(videoId) {
    let cached = urlCache[videoId];
    if (cached && (cached.audioUrl || cached.speechUrl)) {
      console.log('[字幕助手] 📋 Cache hit for video', videoId);
      var applied = notifyAudio(cached.audioUrl, cached.videoUrl, videoId, cached.bitrateInfo, cached.speechUrl, cached.audioRole);
      if (applied && cached.audioUrl) updateButtonState(true);
    }
  }

  // ============================================================
  // Listen for data from main-world interceptor
  // ============================================================
  // ============================================================
  // Listen for data from main-world interceptor
  // ============================================================
  function getCurrentVideoId() {
    let match = location.pathname.match(/\/video\/(\d+)/);
    return match ? match[1] : null;
  }

  function getCurrentRouteVideoId() {
    return getCurrentVideoId() || getCurrentFypVideoId();
  }

  function getCurrentSubtitleEpoch() {
    return getCurrentVideoId() ? 0 : fypRouteEpoch;
  }

  function getCurrentRouteState() {
    if (getCurrentVideoId()) {
      return { videoId: getCurrentVideoId(), wrapperId: null, mediaKey: null, epoch: 0 };
    }
    observeFypRoute();
    var route = getCurrentFypRoute();
    return {
      videoId: route.videoId || null,
      wrapperId: route.wrapperId || null,
      mediaKey: route.mediaKey || null,
      epoch: fypRouteEpoch
    };
  }

  function observeFypRoute() {
    if (getCurrentVideoId()) return;
    var route = getCurrentFypRoute();
    var key = String(route.wrapperId || '') + '/' + String(route.videoId || '') + '/' + String(route.mediaKey || '');
    if (key === fypRouteKey) return;
    var previousKey = fypRouteKey;
    var previousVideoId = lastVideoId;
    fypRouteKey = key;
    currentAudioUrl = null;
    currentVideoUrl = null;
    currentBitrateInfo = null;
    currentSpeechUrl = null;
    lastVideoId = previousKey === null ? null : route.videoId;
    if (previousKey !== null) {
      clearTimeout(_fypSubtitleTimer);
      _fypRequestedId = null;
      renderedVideoIds.delete(previousVideoId);
      var stt = window.__TikTokCaptionHelper?.whisperSTT;
      if (stt && stt.stopWhisper && (typeof stt.isProcessing === 'function' ? stt.isProcessing() : stt.isProcessing)) {
        stt.stopWhisper();
      }
    }
    fypRouteEpoch += 1;
    var change = { videoId: route.videoId, wrapperId: route.wrapperId, mediaKey: route.mediaKey, epoch: fypRouteEpoch };
    for (var i = 0; i < videoChangeListeners.length; i++) {
      videoChangeListeners[i](change);
    }
  }

  function getCurrentFypRoute() {
    var videos = document.querySelectorAll('video');
    var cy = window.innerHeight / 2;
    var best = null, bestDist = Infinity;
    for (var vi = 0; vi < videos.length; vi++) {
      var v = videos[vi];
      var rect = v.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;
      if (!isFypVideoActive(v)) continue;
      var dist = Math.abs(rect.top + rect.height / 2 - cy);
      if (dist >= bestDist) continue;
      var p = v.parentElement;
      for (var depth = 0; depth < 6 && p; depth++) {
        var m = p.id && p.id.match(/^xgwrapper-\d+-(\d+)$/);
        if (m) {
          best = { videoId: m[1], wrapperId: p.id, mediaKey: v.currentSrc || v.src || null };
          bestDist = dist;
          break;
        }
        p = p.parentElement;
      }
    }
    return best || { videoId: null, wrapperId: null, mediaKey: null };
  }

  function getFypVideoTimeDelta(video) {
    var currentTime = Number(video.currentTime);
    if (!isFinite(currentTime)) return null;

    // Tests can provide lastTime directly; browsers do not expose this field.
    if (typeof video.lastTime === 'number' && isFinite(video.lastTime)) {
      return currentTime - video.lastTime;
    }

    if (!fypVideoTimeSamples) return null;
    var now = Date.now();
    var previous = fypVideoTimeSamples.get(video);
    if (!previous) {
      fypVideoTimeSamples.set(video, { time: currentTime, observedAt: now });
      return null;
    }
    if (currentTime === previous.time) return 0;
    fypVideoTimeSamples.set(video, { time: currentTime, observedAt: now });
    return currentTime - previous.time;
  }

  function isFypVideoActive(video) {
    if (!video || video.paused !== false || Number(video.readyState) < 2) return false;
    var currentTime = Number(video.currentTime);
    if (!isFinite(currentTime)) return false;
    if (currentTime === 0) return true;
    var delta = getFypVideoTimeDelta(video);
    // The first observation has no prior frame to compare against. Keep a
    // playing, ready video as a provisional candidate; subsequent reads must
    // show forward progress. Paused preload videos are rejected above.
    if (delta === null || delta > 0) return true;
    if (delta === 0 && fypVideoTimeSamples) {
      var sample = fypVideoTimeSamples.get(video);
      return !!sample && Date.now() - sample.observedAt <= FYP_TIME_SAMPLE_GRACE_MS;
    }
    return false;
  }

  // FYP 精确取当前播放视频的 videoId。
  // 替代 Object.keys(urlCache).pop() —— 后者对 19 位数字 ID 按数值排序，
  // pop() 取的是数值最大、而非最新插入的 videoId（FYP 预加载会累积多个）。
  // 与 whisper-stt.js 的 getFypVideoId 的 xgplayer 部分保持一致，改动需同步。
  function getCurrentFypVideoId() {
    return getCurrentFypRoute().videoId;
  }

  window.addEventListener('tc-subtitle-data', function (e) {
    let data = e.detail;
    let currentId = getCurrentVideoId();
    let dataId = data.videoId;
    observeFypRoute();

    // ── Source-level block: if this videoId already has a successful
    //     bilingual render, drop ALL future subtitle events for it.
    //     This is the first and strongest line of defense against
    //     SSR-refresh → expired eng-US URL → cmn-Hans-CN fallback → double Chinese.
    if (currentId && renderedVideoIds.has(currentId)) {
      console.log('[字幕助手] ⏭ Subtitle data dropped: videoId ' + currentId + ' already rendered. ' +
        '(tracks=' + (data.subtitles ? data.subtitles.length : 0) + ')');
      return;
    }

    // Detail page: guard against data from other videos.
    // Cache mismatched data for SPA navigation, don't overwrite display.
    if (currentId && String(dataId || '') !== String(currentId)) {
      if ((data.audioUrl || data.speechUrl || data.bitrateInfo) && dataId) {
        var cross = urlCache[dataId] || {};
        if (data.audioUrl) { cross.audioUrl = data.audioUrl; cross.videoUrl = data.videoUrl; cross.audioRole = data.audioRole === 'music' || data.audioRole === 'video_media' ? data.audioRole : 'unknown'; }
        if (data.speechUrl) cross.speechUrl = data.speechUrl;
        if (data.bitrateInfo) cross.bitrateInfo = data.bitrateInfo;
        urlCache[dataId] = cross;
        console.log('[字幕助手] 💾 Cached URL for video', dataId);
      }
      console.log('[字幕助手] ⏭ Skipping data for video', dataId || 'unknown', '(current:', currentId, ')');
      return;
    }

    // FYP mode: skip background preload responses (no videoId, no useful data).
    // These are feed-list prefetches, not the active playing video.
    if (!currentId && !dataId && !data.subtitles && !data.audioUrl && !data.speechUrl) {
      return;
    }

    console.log('[字幕助手] 📡 Intercepted:', (currentId ? 'detail' : 'fyp'), '|',
      (data.subtitles ? data.subtitles.length + ' subtitle entries' : 'no subtitles'),
      '| audio:', data.audioUrl ? 'yes' : '', '| videoId:', dataId || 'none');

    // FYP: don't auto-apply subtitle data — can't verify it matches current video.
    // Subtitle data only applied via explicit "获取字幕" button (tc-fetch-subtitles event).
    // Exception (N4): auto-fetch subtitle data from background detail API calls.
    if (currentId) {
      notifySubtitles(data.subtitles || null, dataId, data.subtitleStatus, data.subtitleReason);
    } else if (dataId && dataId === _fypRequestedId && dataId === getCurrentFypRoute().videoId) {
      // FYP auto-subtitle (N4): apply subtitle data when it matches the
      // most recently auto-fetched videoId.
      console.log('[字幕助手] 🎯 FYP auto-subtitle: applying ' + (data.subtitles ? data.subtitles.length : 0) + ' tracks for video ' + dataId);
      notifySubtitles(data.subtitles || null, dataId, data.subtitleStatus, data.subtitleReason);
    }

    if (data.audioUrl || data.videoUrl || data.bitrateInfo || data.speechUrl) {
      var applied = notifyAudio(data.audioUrl, data.videoUrl, dataId, data.bitrateInfo, data.speechUrl, data.audioRole);
      if (applied && data.audioUrl) updateButtonState(true);
    }
  });

  function updateButtonState(hasAudio) {
    let host = document.getElementById('tc-caption-panel-host');
    if (!host || !host.shadowRoot) return;
    let btn = host.shadowRoot.querySelector('#tc-btn-speech');
    if (!btn) return;
    if (hasAudio) {
      btn.style.background = '#22c55e';
      btn.title = '音频已就绪，点击识别';
    }
  }

  // ============================================================
  // FYP: translate panel "获取字幕" click → main-world detail fetch
  // ============================================================
  window.addEventListener('tc-request-fyp-subtitles', function () {
    // 精确取当前播放视频（xgplayer wrapper），不用 Object.keys(urlCache).pop()
    // 的数值排序结果（会取到数值最大、而非当前播放的视频）。
    let videoId = getCurrentFypVideoId();
    if (videoId) {
      // Mark this videoId as requested so subtitle data passes through the FYP gate
      _fypRequestedId = videoId;
      console.log('[字幕助手] Requesting subtitle fetch for FYP video:', videoId);
      window.dispatchEvent(new CustomEvent('tc-fetch-subtitles', { detail: { videoId: videoId } }));
    }
  });

  // ============================================================
  // Public API
  // ============================================================
  window.__TikTokCaptionHelper = window.__TikTokCaptionHelper || {};
  window.__TikTokCaptionHelper.apiInterceptor = {
    getCachedUrl: function (videoId) {
      let cached = urlCache[videoId];
      return cached ? cached.audioUrl : null;
    },
    getCachedAudioRole: function (videoId) {
      let cached = urlCache[videoId];
      return cached ? (cached.audioRole || 'unknown') : 'unknown';
    },
    // STT 原声轨：按 videoId 取 speechUrl（video-cdn/us.tiktok.com）
    getSpeechUrl: function (videoId) {
      let cached = urlCache[videoId];
      return cached ? cached.speechUrl : null;
    },
    getCurrentRouteState: function () {
      return getCurrentRouteState();
    },
    getCurrentSubtitlePacket: getCurrentSubtitlePacket,
    onSubtitles: onSubtitles,
    onVideoChange: onVideoChange,
    onAudioUrl: onAudioUrl,
    lookupCachedUrl: lookupCachedUrl,
    get currentSubtitles() { return currentSubtitles; },
    get currentAudioUrl() { observeFypRoute(); return currentAudioUrl; },
    get currentVideoUrl() { observeFypRoute(); return currentVideoUrl; },
    get currentBitrateInfo() { observeFypRoute(); return currentBitrateInfo; },
    get currentSpeechUrl() { observeFypRoute(); return currentSpeechUrl; },
    get lastVideoId() { observeFypRoute(); return lastVideoId; },
    // ── Rendered video tracking (v0.9.3) ──
    markVideoRendered: function (videoId) {
      if (videoId) {
        renderedVideoIds.add(videoId);
        console.log('[字幕助手] 🔒 Video ' + videoId + ' marked rendered. Future subtitle events blocked.');
      }
    },
    isVideoRendered: function (videoId) { return videoId ? renderedVideoIds.has(videoId) : false; },
    resetRendered: function () {
      var count = renderedVideoIds.size;
      renderedVideoIds.clear();
      // Clear current data to prevent stale replay on next onSubtitles subscription
      currentSubtitles = null;
      currentSubtitlePacket = null;
      currentAudioUrl = null;
      currentVideoUrl = null;
      currentBitrateInfo = null;
      currentSpeechUrl = null;
      // Clear FYP auto-subtitle state
      _fypRequestedId = null;
      clearTimeout(_fypSubtitleTimer);
      if (!getCurrentVideoId()) {
        fypRouteKey = null;
        fypRouteEpoch += 1;
      }
      if (count > 0) console.log('[字幕助手] 🔓 Rendered video set cleared (' + count + ' entries), stale data flushed');
    },
  };

  if (typeof document.addEventListener === 'function') {
    document.addEventListener('visibilitychange', observeFypRoute);
    ['play', 'pause', 'ended', 'emptied', 'loadstart', 'loadedmetadata'].forEach(function (type) {
      document.addEventListener(type, observeFypRoute, true);
    });
  }
  if (typeof window.addEventListener === 'function') {
    ['pageshow', 'popstate'].forEach(function (type) {
      window.addEventListener(type, observeFypRoute, true);
    });
  }

  // Signal main-world that we're ready to receive events
  window.dispatchEvent(new CustomEvent('tc-content-ready'));
  console.log('[字幕助手] API Interceptor loaded (world:MAIN native)');
})();
